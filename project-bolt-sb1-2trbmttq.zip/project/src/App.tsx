import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './components/layout/Header';
import Footer from './components/layout/Footer';
import Home from './pages/Home';
import Sheds from './pages/Sheds';
import Garages from './pages/Garages';
import OtherStructures from './pages/OtherStructures';
import StructureList from './pages/StructureList';
import StructureDetail from './pages/StructureDetail';
import StockStructures from './pages/StockStructures';
import StockStructureDetail from './pages/StockStructureDetail';
import Colors from './pages/Colors';
import ProposalGenerator from './pages/ProposalGenerator';
import Gallery from './pages/Gallery';
import About from './pages/About';
import Contact from './pages/Contact';

// Legal Pages
import PrivacyPolicy from './pages/legal/PrivacyPolicy';
import TermsOfService from './pages/legal/TermsOfService';

// Resource Pages
import Warranty from './pages/resources/Warranty';
import DeliveryInstallation from './pages/resources/DeliveryInstallation';
import FAQ from './pages/resources/FAQ';
import MaintenanceGuide from './pages/resources/MaintenanceGuide';
import SitePreparation from './pages/resources/SitePreparation';
import BuildingPermits from './pages/resources/BuildingPermits';
import Blog from './pages/resources/Blog';
import Financing from './pages/resources/Financing';
import DeliveryAreas from './pages/resources/DeliveryAreas';
import InstallationServices from './pages/resources/InstallationServices';
import SitePreparationServices from './pages/resources/SitePreparationServices';

function App() {
  return (
    <Router>
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/sheds" element={<Sheds />} />
            <Route path="/garages" element={<Garages />} />
            <Route path="/other-structures" element={<OtherStructures />} />
            <Route path="/all-structures" element={<StructureList type="all" />} />
            <Route path="/structures/:id" element={<StructureDetail />} />
            <Route path="/stock-structures" element={<StockStructures />} />
            <Route path="/stock-structures/:id" element={<StockStructureDetail />} />
            <Route path="/colors" element={<Colors />} />
            <Route path="/proposal-generator" element={<ProposalGenerator />} />
            <Route path="/gallery" element={<Gallery />} />
            <Route path="/about" element={<About />} />
            <Route path="/contact" element={<Contact />} />

            {/* Legal Pages */}
            <Route path="/privacy-policy" element={<PrivacyPolicy />} />
            <Route path="/terms-of-service" element={<TermsOfService />} />

            {/* Resource Pages */}
            <Route path="/warranty" element={<Warranty />} />
            <Route path="/delivery-installation" element={<DeliveryInstallation />} />
            <Route path="/faq" element={<FAQ />} />
            <Route path="/maintenance-guide" element={<MaintenanceGuide />} />
            <Route path="/site-preparation" element={<SitePreparation />} />
            <Route path="/building-permits" element={<BuildingPermits />} />
            <Route path="/blog" element={<Blog />} />
            <Route path="/financing" element={<Financing />} />
            <Route path="/delivery-areas" element={<DeliveryAreas />} />
            <Route path="/installation-services" element={<InstallationServices />} />
            <Route path="/site-preparation-services" element={<SitePreparationServices />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </Router>
  );
}

export default App;