import { Structure, StructureOption } from '../types';

interface SizePrice {
  size: string;
  price: number;
}

interface PricingResult {
  basePrice: number;
  optionsTotal: number;
  total: number;
  breakdown: {
    description: string;
    amount: number;
  }[];
}

// Size-based pricing adjustments
const sizePricing: Record<string, SizePrice[]> = {
  'mini-barn': [
    { size: '8x8', price: 2999 },
    { size: '8x10', price: 3299 },
    { size: '10x12', price: 3799 },
    { size: '10x16', price: 4299 },
    { size: '12x16', price: 4799 },
    { size: '12x20', price: 5299 },
    { size: '14x20', price: 5799 },
    { size: '14x24', price: 6299 },
    { size: '14x32', price: 7299 },
    { size: '14x40', price: 8299 }
  ],
  'hi-wall-barn': [
    { size: '8x10', price: 3499 },
    { size: '10x12', price: 3999 },
    { size: '10x16', price: 4499 },
    { size: '12x16', price: 4999 },
    { size: '12x20', price: 5499 },
    { size: '14x20', price: 5999 },
    { size: '14x24', price: 6499 },
    { size: '14x32', price: 7499 },
    { size: '14x40', price: 8499 }
  ],
  // Add other model size pricing...
};

export const calculateStructurePrice = (
  structure: Structure,
  selectedSize: string,
  selectedOptions: StructureOption[]
): PricingResult => {
  // Get base price for selected size
  const sizePrice = sizePricing[structure.id]?.find(sp => sp.size === selectedSize);
  const basePrice = sizePrice?.price || structure.basePrice;
  
  // Calculate options total
  const optionsBreakdown = selectedOptions.map(option => ({
    description: option.name,
    amount: typeof option.priceModifier === 'function' 
      ? option.priceModifier(basePrice)
      : option.priceModifier
  }));
  
  const optionsTotal = optionsBreakdown.reduce((sum, option) => sum + option.amount, 0);
  
  // Create price breakdown
  const breakdown = [
    { description: `Base Price (${selectedSize})`, amount: basePrice },
    ...optionsBreakdown
  ];
  
  return {
    basePrice,
    optionsTotal,
    total: basePrice + optionsTotal,
    breakdown
  };
};

export const formatPrice = (amount: number): string => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  }).format(amount);
};