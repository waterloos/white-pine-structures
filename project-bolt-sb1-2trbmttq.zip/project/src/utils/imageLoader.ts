import { ImageLoaderOptions } from '../types/images';

const BUNNY_BASE_URL = 'https://structures.b-cdn.net';

export const getImageUrl = (path: string, options: ImageLoaderOptions = {}): string => {
  const {
    width,
    height,
    quality = 80,
    format = 'webp',
    blur = 0,
    dpr = 1
  } = options;

  const params = new URLSearchParams();

  if (width) params.append('width', width.toString());
  if (height) params.append('height', height.toString());
  if (quality) params.append('quality', quality.toString());
  if (format) params.append('format', format);
  if (blur > 0) params.append('blur', blur.toString());
  if (dpr > 1) params.append('dpr', dpr.toString());

  const queryString = params.toString();
  return `${BUNNY_BASE_URL}/${path}${queryString ? `?${queryString}` : ''}`;
};

export const getResponsiveImageUrl = (path: string, sizes: number[]): string[] => {
  return sizes.map(size => getImageUrl(path, { width: size }));
};

export const getPlaceholderUrl = (path: string): string => {
  return getImageUrl(path, {
    width: 20,
    quality: 20,
    blur: 10
  });
};