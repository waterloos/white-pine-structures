import { Structure, ProposalItem } from '../types';

export const calculateTotalPrice = (
  structure: Structure,
  selectedOptions: { [key: string]: string | boolean | number }
): number => {
  let totalPrice = structure.basePrice;

  // Calculate additional costs from selected options
  Object.entries(selectedOptions).forEach(([optionId, value]) => {
    const option = structure.options.find(opt => opt.id === optionId);
    
    if (option && value) {
      if (typeof option.priceModifier === 'function') {
        totalPrice += option.priceModifier(structure.basePrice);
      } else {
        totalPrice += option.priceModifier;
      }
    }
  });

  return totalPrice;
};

export const generateProposalSummary = (proposal: ProposalItem, structure: Structure): string => {
  const lines = [
    `Structure Type: ${structure.name}`,
    `Base Price: $${proposal.basePrice.toLocaleString()}`,
    `Selected Options:`,
  ];

  Object.entries(proposal.options).forEach(([optionId, value]) => {
    const option = structure.options.find(opt => opt.id === optionId);
    if (option && value) {
      lines.push(`  - ${option.name}: $${typeof option.priceModifier === 'function' 
        ? option.priceModifier(structure.basePrice).toLocaleString() 
        : option.priceModifier.toLocaleString()}`);
    }
  });

  lines.push(`Total Price: $${proposal.totalPrice.toLocaleString()}`);

  return lines.join('\n');
};