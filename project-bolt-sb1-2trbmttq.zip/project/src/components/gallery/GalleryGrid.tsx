import React, { useState } from 'react';
import { GalleryImage } from '../../types/gallery';
import { ChevronLeft, ChevronRight, X } from 'lucide-react';

interface GalleryGridProps {
  images: GalleryImage[];
  columns?: number;
}

const GalleryGrid: React.FC<GalleryGridProps> = ({ 
  images, 
  columns = 3 
}) => {
  const [selectedImage, setSelectedImage] = useState<GalleryImage | null>(null);
  const [currentIndex, setCurrentIndex] = useState(0);

  const openLightbox = (image: GalleryImage) => {
    setSelectedImage(image);
    setCurrentIndex(images.findIndex(img => img.id === image.id));
    document.body.style.overflow = 'hidden';
  };

  const closeLightbox = () => {
    setSelectedImage(null);
    document.body.style.overflow = 'auto';
  };

  const nextImage = () => {
    setCurrentIndex((prev) => (prev + 1) % images.length);
    setSelectedImage(images[(currentIndex + 1) % images.length]);
  };

  const prevImage = () => {
    setCurrentIndex((prev) => (prev - 1 + images.length) % images.length);
    setSelectedImage(images[(currentIndex - 1 + images.length) % images.length]);
  };

  return (
    <>
      <div 
        className={`grid grid-cols-1 md:grid-cols-2 lg:grid-cols-${columns} gap-4`}
        role="grid"
      >
        {images.map((image) => (
          <div
            key={image.id}
            className="aspect-square overflow-hidden rounded-lg cursor-pointer group"
            onClick={() => openLightbox(image)}
            role="gridcell"
          >
            <img
              src={image.url}
              alt={image.alt}
              loading="lazy"
              className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
            />
          </div>
        ))}
      </div>

      {/* Lightbox */}
      {selectedImage && (
        <div className="fixed inset-0 z-50 bg-black bg-opacity-95 flex items-center justify-center">
          <button
            onClick={closeLightbox}
            className="absolute top-4 right-4 text-white p-2 hover:text-gray-300"
            aria-label="Close lightbox"
          >
            <X size={24} />
          </button>

          <button
            onClick={prevImage}
            className="absolute left-4 text-white p-2 hover:text-gray-300"
            aria-label="Previous image"
          >
            <ChevronLeft size={24} />
          </button>

          <button
            onClick={nextImage}
            className="absolute right-4 text-white p-2 hover:text-gray-300"
            aria-label="Next image"
          >
            <ChevronRight size={24} />
          </button>

          <div className="max-w-7xl mx-auto px-4">
            <img
              src={selectedImage.url}
              alt={selectedImage.alt}
              className="max-h-[85vh] mx-auto"
            />
            <div className="text-white text-center mt-4">
              <h3 className="text-xl font-semibold">{selectedImage.title}</h3>
              <p className="text-gray-300 mt-2">{selectedImage.description}</p>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default GalleryGrid;