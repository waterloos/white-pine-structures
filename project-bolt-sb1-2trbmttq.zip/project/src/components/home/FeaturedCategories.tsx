import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';

interface CategoryCardProps {
  title: string;
  description: string;
  imageUrl: string;
  link: string;
}

const CategoryCard: React.FC<CategoryCardProps> = ({ title, description, imageUrl, link }) => {
  return (
    <div className="relative group overflow-hidden rounded-lg shadow-md h-64 sm:h-80">
      <img 
        src={`${imageUrl}?width=900&height=675&quality=80&format=webp`}
        alt={title} 
        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black via-black/70 to-transparent p-4 sm:p-6 flex flex-col justify-end">
        <h3 className="text-xl sm:text-2xl font-semibold mb-2 text-white drop-shadow-lg">{title}</h3>
        <p className="text-sm sm:text-base text-gray-200 mb-4 drop-shadow line-clamp-2 sm:line-clamp-none">{description}</p>
        <Link 
          to={link} 
          className="inline-flex items-center text-white font-medium group-hover:underline drop-shadow"
        >
          Explore {title}
          <ArrowRight className="ml-2 h-5 w-5 transition-transform group-hover:translate-x-1" />
        </Link>
      </div>
    </div>
  );
};

const FeaturedCategories: React.FC = () => {
  const categories = [
    {
      title: 'Sheds',
      description: 'Custom storage solutions for any need, from garden tools to workshop space.',
      imageUrl: 'https://structures.b-cdn.net/category-sheds',
      link: '/sheds'
    },
    {
      title: 'Garages',
      description: 'Protect your vehicles and create additional workspace with our custom garages.',
      imageUrl: 'https://structures.b-cdn.net/category-garages',
      link: '/garages'
    },
    {
      title: 'Other Structures',
      description: 'Specialized buildings from greenhouses to animal shelters, built to your specifications.',
      imageUrl: 'https://structures.b-cdn.net/category-other',
      link: '/other-structures'
    }
  ];

  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-2xl sm:text-3xl font-serif font-bold text-gray-900 mb-4">What We Build</h2>
          <p className="text-lg sm:text-xl text-gray-600 max-w-3xl mx-auto">
            Explore our range of handcrafted structures, each built with premium materials and exceptional craftsmanship.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8">
          {categories.map((category, index) => (
            <CategoryCard key={index} {...category} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturedCategories;