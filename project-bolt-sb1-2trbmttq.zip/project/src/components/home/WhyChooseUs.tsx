import React from 'react';
import { Award, Clock, Hammer, Heart } from 'lucide-react';

interface FeatureProps {
  icon: React.ReactNode;
  title: string;
  description: string;
}

const Feature: React.FC<FeatureProps> = ({ icon, title, description }) => {
  return (
    <div className="text-center p-6">
      <div className="inline-flex items-center justify-center h-16 w-16 rounded-full bg-[#978E5F] bg-opacity-10 text-[#978E5F] mb-4">
        {icon}
      </div>
      <h3 className="text-xl font-semibold mb-2 text-gray-900">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  );
};

const WhyChooseUs: React.FC = () => {
  const features = [
    {
      icon: <Award size={32} />,
      title: 'Quality Craftsmanship',
      description: 'Every structure is built with premium materials and attention to detail for lasting quality.'
    },
    {
      icon: <Hammer size={32} />,
      title: 'Custom Designs',
      description: 'We work with you to create the perfect structure that meets your specific needs and preferences.'
    },
    {
      icon: <Clock size={32} />,
      title: 'Timely Delivery',
      description: 'Our efficient processes ensure your custom structure is delivered on schedule.'
    },
    {
      icon: <Heart size={32} />,
      title: 'Customer Satisfaction',
      description: 'We\'re not satisfied until you are, with service that continues after delivery.'
    }
  ];

  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-serif font-bold text-gray-900 mb-4">Why Choose White Pine Structures</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            For over 25 years, we\'ve been dedicated to building high-quality structures that stand the test of time.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <Feature key={index} {...feature} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default WhyChooseUs;