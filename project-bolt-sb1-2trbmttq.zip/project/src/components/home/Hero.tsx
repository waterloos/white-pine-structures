import React from 'react';
import ButtonLink from '../common/ButtonLink';

const Hero: React.FC = () => {
  return (
    <div className="relative h-screen flex items-center">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://structures.b-cdn.net/hero-shed.jpg?width=900&height=675&quality=80&format=webp"
          alt="White Pine Structures Hero" 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/60 to-transparent"></div>
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="max-w-2xl">
          <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-serif font-bold mb-4 md:mb-6 leading-tight text-white drop-shadow-lg">
            Crafting Quality Structures for Your Life
          </h1>
          <p className="text-lg sm:text-xl md:text-2xl mb-6 md:mb-8 text-gray-100 drop-shadow">
            Custom-built sheds, garages, and outdoor structures designed to enhance your property and meet your specific needs.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <ButtonLink 
              to="/sheds" 
              variant="primary"
              className="sm:mr-4 text-lg text-center"
            >
              Explore What We Build
            </ButtonLink>
            <ButtonLink 
              to="/stock-structures" 
              variant="outline"
              className="text-lg text-white border-white hover:bg-white hover:text-gray-900 text-center"
            >
              Shop Stock Structures
            </ButtonLink>
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 flex flex-col items-center animate-bounce">
        <span className="text-white text-sm mb-2 drop-shadow">Scroll Down</span>
        <svg 
          className="w-6 h-6 text-white drop-shadow" 
          fill="none" 
          stroke="currentColor" 
          viewBox="0 0 24 24"
        >
          <path 
            strokeLinecap="round" 
            strokeLinejoin="round" 
            strokeWidth="2" 
            d="M19 14l-7 7m0 0l-7-7m7 7V3"
          />
        </svg>
      </div>
    </div>
  );
};

export default Hero;