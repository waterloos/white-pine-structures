import React from 'react';
import { Link } from 'react-router-dom';
import StockInventoryCard from '../stock/StockInventoryCard';
import { getFeaturedItems } from '../../data/stockInventory';
import { ArrowRight } from 'lucide-react';

const FeaturedStock: React.FC = () => {
  const featuredItems = getFeaturedItems().slice(0, 3);

  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12">
          <div>
            <h2 className="text-3xl font-serif font-bold text-gray-900 mb-4">Ready to Deliver Structures</h2>
            <p className="text-xl text-gray-600 max-w-3xl">
              Browse our in-stock structures that are ready for immediate delivery to your location.
            </p>
          </div>
          <div className="mt-4 md:mt-0">
            <Link 
              to="/stock-structures" 
              className="inline-flex items-center text-[#978E5F] font-medium hover:underline"
            >
              View All Stock
              <ArrowRight className="ml-2 h-5 w-5" />
            </Link>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {featuredItems.map(item => (
            <StockInventoryCard 
              key={item.modelNumber} 
              item={item} 
            />
          ))}
        </div>
        
        <div className="mt-12 text-center">
          <Link 
            to="/stock-structures" 
            className="inline-block bg-[#978E5F] text-white px-6 py-3 rounded-full font-medium hover:bg-opacity-90 transition-colors"
          >
            Browse All Stock Structures
          </Link>
        </div>
      </div>
    </section>
  );
};

export default FeaturedStock;