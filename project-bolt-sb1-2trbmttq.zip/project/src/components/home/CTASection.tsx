import React from 'react';
import ButtonLink from '../common/ButtonLink';

const CTASection: React.FC = () => {
  return (
    <section className="py-20 bg-gray-900 text-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-serif font-bold mb-6">Ready to Start Your Project?</h2>
          <p className="text-xl text-gray-300 mb-8">
            Whether you need a custom shed, a new garage, or want to check out our stock structures, we're here to help you find the perfect solution.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <ButtonLink 
              to="/proposal-generator" 
              variant="primary"
              className="text-lg"
            >
              Generate a Custom Proposal
            </ButtonLink>
            <ButtonLink 
              to="/contact" 
              variant="outline"
              className="text-lg text-white border-white hover:bg-white hover:text-gray-900"
            >
              Contact Us
            </ButtonLink>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CTASection;