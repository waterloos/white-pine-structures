import React from 'react';
import TestimonialCard from '../common/TestimonialCard';
import { testimonials } from '../../data/gallery';

const TestimonialSection: React.FC = () => {
  const featuredTestimonials = testimonials.slice(0, 3);

  return (
    <section className="py-16 bg-[#978E5F] bg-opacity-10">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-serif font-bold text-gray-900 mb-4">What Our Customers Say</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Read about the experiences of customers who have chosen White Pine Structures for their outdoor building needs.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {featuredTestimonials.map(testimonial => (
            <TestimonialCard 
              key={testimonial.id} 
              testimonial={testimonial} 
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default TestimonialSection;