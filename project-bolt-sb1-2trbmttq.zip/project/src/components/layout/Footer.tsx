import React from 'react';
import { Phone, Mail, MapPin, Facebook, Instagram, Twitter } from 'lucide-react';
import { Link } from 'react-router-dom';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-900 text-white pt-12 pb-8">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          
          {/* Company Info */}
          <div>
            <h3 className="text-xl font-serif font-bold mb-4 text-[#978E5F]">White Pine Structures</h3>
            <p className="mb-4 text-gray-300">
              Crafting high-quality custom sheds, garages, and outdoor structures since 1998.
            </p>
            <div className="flex space-x-4 mt-4">
              <a href="https://facebook.com/whitepinestructures" target="_blank" rel="noopener noreferrer" className="text-gray-300 hover:text-[#978E5F] transition-colors">
                <Facebook size={20} />
              </a>
              <a href="https://instagram.com/whitepinestructures" target="_blank" rel="noopener noreferrer" className="text-gray-300 hover:text-[#978E5F] transition-colors">
                <Instagram size={20} />
              </a>
              <a href="https://twitter.com/whitepinestructures" target="_blank" rel="noopener noreferrer" className="text-gray-300 hover:text-[#978E5F] transition-colors">
                <Twitter size={20} />
              </a>
            </div>
          </div>
          
          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Products & Services</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/all-structures" className="text-gray-300 hover:text-[#978E5F] transition-colors">All Structures</Link>
              </li>
              <li>
                <Link to="/sheds" className="text-gray-300 hover:text-[#978E5F] transition-colors">Storage Sheds</Link>
              </li>
              <li>
                <Link to="/garages" className="text-gray-300 hover:text-[#978E5F] transition-colors">Custom Garages</Link>
              </li>
              <li>
                <Link to="/other-structures" className="text-gray-300 hover:text-[#978E5F] transition-colors">Specialty Buildings</Link>
              </li>
              <li>
                <Link to="/stock-structures" className="text-gray-300 hover:text-[#978E5F] transition-colors">Stock Structures</Link>
              </li>
              <li>
                <Link to="/installation-services" className="text-gray-300 hover:text-[#978E5F] transition-colors">Installation Services</Link>
              </li>
              <li>
                <Link to="/site-preparation-services" className="text-gray-300 hover:text-[#978E5F] transition-colors">Site Preparation</Link>
              </li>
            </ul>
          </div>
          
          {/* Resources */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Resources</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/warranty" className="text-gray-300 hover:text-[#978E5F] transition-colors">Warranty Information</Link>
              </li>
              <li>
                <Link to="/delivery-installation" className="text-gray-300 hover:text-[#978E5F] transition-colors">Delivery & Installation</Link>
              </li>
              <li>
                <Link to="/financing" className="text-gray-300 hover:text-[#978E5F] transition-colors">Financing Options</Link>
              </li>
              <li>
                <Link to="/maintenance-guide" className="text-gray-300 hover:text-[#978E5F] transition-colors">Maintenance Guide</Link>
              </li>
              <li>
                <Link to="/site-preparation" className="text-gray-300 hover:text-[#978E5F] transition-colors">Site Preparation Guide</Link>
              </li>
              <li>
                <Link to="/building-permits" className="text-gray-300 hover:text-[#978E5F] transition-colors">Building Permits</Link>
              </li>
              <li>
                <Link to="/faq" className="text-gray-300 hover:text-[#978E5F] transition-colors">FAQ</Link>
              </li>
              <li>
                <Link to="/blog" className="text-gray-300 hover:text-[#978E5F] transition-colors">Blog</Link>
              </li>
            </ul>
          </div>
          
          {/* Contact Info */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Contact Us</h3>
            <div className="space-y-3">
              <div className="flex items-start">
                <MapPin className="h-5 w-5 mr-2 text-[#978E5F] flex-shrink-0 mt-0.5" />
                <p className="text-gray-300">
                  3341 W Lincoln Hwy<br />
                  Parkesburg, PA 19365
                </p>
              </div>
              <div className="flex items-center">
                <Phone className="h-5 w-5 mr-2 text-[#978E5F] flex-shrink-0" />
                <a href="tel:+12075550123" className="text-gray-300 hover:text-[#978E5F] transition-colors">
                  (207) 555-0123
                </a>
              </div>
              <div className="flex items-center">
                <Mail className="h-5 w-5 mr-2 text-[#978E5F] flex-shrink-0" />
                <a href="mailto:info@whitepinestructures.com" className="text-gray-300 hover:text-[#978E5F] transition-colors">
                  info@whitepinestructures.com
                </a>
              </div>
              <div className="pt-4">
                <Link 
                  to="/delivery-areas" 
                  className="text-[#978E5F] hover:underline"
                >
                  View Service Areas
                </Link>
              </div>
            </div>
          </div>
        </div>
        
        {/* Legal Links */}
        <div className="mt-12 pt-8 border-t border-gray-800">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm">
              &copy; {new Date().getFullYear()} White Pine Structures. All rights reserved.
            </p>
            <div className="flex space-x-6 mt-4 md:mt-0">
              <Link to="/privacy-policy" className="text-gray-400 hover:text-[#978E5F] text-sm">
                Privacy Policy
              </Link>
              <Link to="/terms-of-service" className="text-gray-400 hover:text-[#978E5F] text-sm">
                Terms of Service
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;