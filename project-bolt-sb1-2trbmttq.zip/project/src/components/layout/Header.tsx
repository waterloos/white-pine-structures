import React, { useState, useEffect } from 'react';
import { Menu, X, ChevronDown } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';

const Header: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const location = useLocation();
  const isHomePage = location.pathname === '/';

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setIsOpen(false);
  }, [location]);

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }

    return () => {
      document.body.style.overflow = '';
    };
  }, [isOpen]);

  const navLinks = [
    {
      title: 'What We Build',
      dropdown: true,
      items: [
        { title: 'All Structures', path: '/all-structures' },
        { title: 'Storage Sheds', path: '/sheds' },
        { title: 'Custom Garages', path: '/garages' },
        { title: 'Specialty Buildings', path: '/other-structures' },
        { title: 'Stock Structures', path: '/stock-structures' },
        { title: 'Proposal Generator', path: '/proposal-generator' }
      ]
    },
    { title: 'Colors', path: '/colors' },
    { title: 'Gallery', path: '/gallery' },
    { title: 'About', path: '/about' }
  ];

  return (
    <header 
      className={`fixed w-full z-50 transition-all duration-300 ${
        isScrolled || isOpen 
          ? 'bg-white shadow-lg' 
          : isHomePage 
            ? 'bg-transparent' 
            : 'bg-[#1d1d1f]'
      }`}
    >
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <nav className="flex items-center justify-between h-20">
          {/* Logo */}
          <Link 
            to="/" 
            className={`text-2xl font-serif font-bold transition-colors duration-300 ${
              isScrolled || isOpen 
                ? 'text-[#978E5F]' 
                : isHomePage 
                  ? 'text-[#978E5F]' 
                  : 'text-white'
            }`}
          >
            White Pine Structures
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center space-x-2">
            {navLinks.map((link, index) => (
              link.dropdown ? (
                <div key={index} className="relative group">
                  <button 
                    className={`flex items-center px-4 py-2 rounded-lg transition-all duration-300 ${
                      isScrolled || isOpen
                        ? 'text-gray-700 hover:bg-gray-100' 
                        : isHomePage
                          ? 'text-white hover:bg-white/10'
                          : 'text-white hover:bg-white/10'
                    }`}
                  >
                    <span>{link.title}</span>
                    <ChevronDown className="w-4 h-4 ml-1 transition-transform duration-300 group-hover:rotate-180" />
                  </button>
                  <div className="absolute left-0 mt-1 w-64 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300 transform translate-y-2 group-hover:translate-y-0">
                    <div className="py-2 bg-white rounded-xl shadow-xl ring-1 ring-black ring-opacity-5">
                      {link.items.map((item, itemIndex) => (
                        <Link
                          key={itemIndex}
                          to={item.path}
                          className="block px-4 py-3 text-gray-700 hover:bg-gray-50 hover:text-[#978E5F] transition-colors"
                        >
                          {item.title}
                        </Link>
                      ))}
                    </div>
                  </div>
                </div>
              ) : (
                <Link
                  key={index}
                  to={link.path}
                  className={`px-4 py-2 rounded-lg transition-all duration-300 ${
                    isScrolled || isOpen
                      ? 'text-gray-700 hover:bg-gray-100' 
                      : isHomePage
                        ? 'text-white hover:bg-white/10'
                        : 'text-white hover:bg-white/10'
                  }`}
                >
                  {link.title}
                </Link>
              )
            ))}
            <Link 
              to="/contact" 
              className={`ml-4 px-6 py-2 rounded-lg transition-all duration-300 transform hover:scale-105 ${
                isScrolled || isOpen
                  ? 'bg-[#978E5F] text-white hover:bg-[#8A825A]'
                  : isHomePage
                    ? 'bg-[#978E5F] text-white hover:bg-[#8A825A]'
                    : 'bg-white text-[#1d1d1f] hover:bg-gray-100'
              }`}
            >
              Contact Us
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className={`lg:hidden p-2 rounded-lg transition-colors ${
              isScrolled || isOpen 
                ? 'text-gray-800 hover:bg-gray-100' 
                : isHomePage
                  ? 'text-white hover:bg-white/10'
                  : 'text-white hover:bg-white/10'
            }`}
            aria-label="Toggle menu"
          >
            {isOpen ? <X size={24} /> : <Menu size={24} />}
          </button>

          {/* Mobile Navigation */}
          <div 
            className={`lg:hidden fixed inset-0 bg-white z-40 transition-all duration-300 ${
              isOpen ? 'opacity-100 visible' : 'opacity-0 invisible pointer-events-none'
            }`}
            style={{ top: '80px' }}
          >
            <div className="container mx-auto px-4 py-6 h-[calc(100vh-80px)] overflow-y-auto">
              <div className="space-y-4">
                {navLinks.map((link, index) => (
                  <div key={index}>
                    {link.dropdown ? (
                      <div className="mb-4">
                        <div className="text-lg font-medium text-gray-900 mb-2">{link.title}</div>
                        <div className="space-y-2 pl-4">
                          {link.items.map((item, itemIndex) => (
                            <Link
                              key={itemIndex}
                              to={item.path}
                              className="block py-2 text-gray-600 hover:text-[#978E5F] transition-colors"
                              onClick={() => setIsOpen(false)}
                            >
                              {item.title}
                            </Link>
                          ))}
                        </div>
                      </div>
                    ) : (
                      <Link
                        to={link.path}
                        className="block text-lg text-gray-900 hover:text-[#978E5F] py-2 transition-colors"
                        onClick={() => setIsOpen(false)}
                      >
                        {link.title}
                      </Link>
                    )}
                  </div>
                ))}
                <Link 
                  to="/contact" 
                  className="block mt-6 bg-[#978E5F] text-white px-6 py-3 rounded-lg text-center hover:bg-[#8A825A] transition-colors"
                  onClick={() => setIsOpen(false)}
                >
                  Contact Us
                </Link>
              </div>
            </div>
          </div>
        </nav>
      </div>
    </header>
  );
};

export default Header;