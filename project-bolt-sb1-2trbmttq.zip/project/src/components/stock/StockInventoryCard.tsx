import React from 'react';
import { Link } from 'react-router-dom';
import { MapPin, DollarSign, Clock, ArrowRight } from 'lucide-react';
import { StockInventoryItem } from '../../types';
import Image from '../common/Image';

interface StockInventoryCardProps {
  item: StockInventoryItem;
}

const StockInventoryCard: React.FC<StockInventoryCardProps> = ({ item }) => {
  const inquiryParams = new URLSearchParams({
    model: item.modelNumber,
    type: item.type,
    size: item.specifications.size,
    name: item.name,
    subject: `Inquiry about ${item.name} (#${item.modelNumber})`,
    message: `I'm interested in the ${item.name} (#${item.modelNumber}) that's currently in stock.\n\nSpecifications:\n- Size: ${item.specifications.size}\n- Material: ${item.specifications.material}\n- Price: $${item.pricing.retailPrice.toLocaleString()}\n\nPlease provide information about availability and next steps.`
  }).toString();

  return (
    <div className="group bg-white rounded-lg shadow-md overflow-hidden transform transition-all duration-300 hover:shadow-xl hover:-translate-y-1 border border-gray-200">
      {/* Image Section */}
      <div className="relative">
        <div className="h-56 overflow-hidden">
          <Image 
            src={item.images[0].url} 
            alt={item.images[0].alt}
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          />
        </div>
        
        {/* Status Tags */}
        <div className="absolute top-0 left-0 right-0 p-4 flex flex-wrap gap-2">
          <div className="flex flex-wrap gap-2 items-center">
            <span className="bg-black/70 backdrop-blur-sm text-white px-3 py-1 rounded-full text-sm font-medium">
              #{item.modelNumber}
            </span>
            {item.status === 'available' && (
              <span className="bg-green-500/70 backdrop-blur-sm text-white px-3 py-1 rounded-full text-sm font-medium">
                Available Now
              </span>
            )}
            {item.pricing.discount && (
              <span className="bg-red-500/70 backdrop-blur-sm text-white px-3 py-1 rounded-full text-sm font-medium whitespace-nowrap">
                Save ${item.pricing.discount.amount.toLocaleString()}
              </span>
            )}
          </div>
        </div>
      </div>
      
      {/* Content Section */}
      <div className="p-6">
        <div className="mb-4">
          <h3 className="text-xl font-semibold text-gray-900 mb-2 line-clamp-1">{item.name}</h3>
          <p className="text-gray-600 text-sm line-clamp-2">{item.description}</p>
        </div>

        {/* Quick Specs */}
        <div className="space-y-3 mb-4">
          <div className="flex items-center text-sm text-gray-600">
            <MapPin className="h-4 w-4 mr-2 text-gray-400 flex-shrink-0" />
            <span className="truncate">{item.specifications.size} • {item.specifications.material}</span>
          </div>
          <div className="flex items-center text-sm text-gray-600">
            <MapPin className="h-4 w-4 mr-2 text-gray-400 flex-shrink-0" />
            <span className="truncate">3341 W Lincoln Hwy, Parkesburg, PA 19365</span>
          </div>
          <div className="flex items-center text-sm font-medium text-[#978E5F]">
            <DollarSign className="h-4 w-4 mr-2 flex-shrink-0" />
            <div className="flex items-center gap-2">
              {item.pricing.discount ? (
                <>
                  <span className="line-through text-gray-400">${item.pricing.retailPrice.toLocaleString()}</span>
                  <span className="text-red-500">${(item.pricing.retailPrice - item.pricing.discount.amount).toLocaleString()}</span>
                </>
              ) : (
                <span>${item.pricing.retailPrice.toLocaleString()}</span>
              )}
            </div>
          </div>
          {item.pricing.rentToOwn && (
            <div className="flex items-center text-sm text-gray-600">
              <Clock className="h-4 w-4 mr-2 text-gray-400 flex-shrink-0" />
              <span className="truncate">From ${item.pricing.rentToOwn.monthlyPayment}/mo with rent-to-own</span>
            </div>
          )}
        </div>

        {/* Features Tags */}
        {item.specifications.additionalFeatures && (
          <div className="mb-6">
            <div className="flex flex-wrap gap-1.5">
              {item.specifications.additionalFeatures.slice(0, 3).map((feature, index) => (
                <span 
                  key={index}
                  className="bg-gray-100 text-gray-700 px-2 py-0.5 rounded-full text-xs"
                >
                  {feature}
                </span>
              ))}
              {item.specifications.additionalFeatures.length > 3 && (
                <span className="text-[#978E5F] text-xs">
                  +{item.specifications.additionalFeatures.length - 3} more
                </span>
              )}
            </div>
          </div>
        )}

        {/* Actions */}
        <div className="flex gap-3">
          <Link
            to={`/stock-structures/${item.modelNumber}`}
            className="flex-1 bg-[#978E5F] text-white text-center py-2 rounded-full font-medium hover:bg-[#8A825A] transition-colors flex items-center justify-center group text-sm"
          >
            View Details
            <ArrowRight className="ml-1.5 h-4 w-4 transition-transform group-hover:translate-x-1" />
          </Link>
          {item.status === 'available' ? (
            <Link
              to={`/contact?${inquiryParams}`}
              className="flex-1 border-2 border-[#978E5F] text-[#978E5F] text-center py-2 rounded-full font-medium hover:bg-[#978E5F] hover:text-white transition-colors text-sm"
            >
              Get Quote
            </Link>
          ) : (
            <Link
              to={`/proposal-generator?model=${item.name}`}
              className="flex-1 border-2 border-[#978E5F] text-[#978E5F] text-center py-2 rounded-full font-medium hover:bg-[#978E5F] hover:text-white transition-colors text-sm"
            >
              Build Your Own
            </Link>
          )}
        </div>
      </div>
    </div>
  );
};

export default StockInventoryCard;