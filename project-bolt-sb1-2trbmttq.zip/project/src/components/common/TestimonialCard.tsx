import React from 'react';
import { Testimonial } from '../../types';
import { Star } from 'lucide-react';

interface TestimonialCardProps {
  testimonial: Testimonial;
}

const TestimonialCard: React.FC<TestimonialCardProps> = ({ testimonial }) => {
  return (
    <div className="bg-white rounded-lg shadow-md p-6 h-full flex flex-col">
      <div className="flex items-center mb-4">
        {[...Array(5)].map((_, i) => (
          <Star 
            key={i}
            className={`h-4 w-4 ${i < testimonial.rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`}
          />
        ))}
      </div>
      
      <p className="text-gray-700 italic mb-4 flex-grow">&ldquo;{testimonial.text}&rdquo;</p>
      
      <div className="mt-auto">
        <p className="font-semibold text-gray-900">{testimonial.customer}</p>
        <p className="text-sm text-gray-500">{testimonial.date}</p>
      </div>
    </div>
  );
};

export default TestimonialCard;