import React from 'react';
import { Gallery } from '../../types';

interface GalleryCardProps {
  item: Gallery;
  onClick: () => void;
}

const GalleryCard: React.FC<GalleryCardProps> = ({ item, onClick }) => {
  return (
    <div 
      className="relative group overflow-hidden rounded-lg shadow-md cursor-pointer"
      onClick={onClick}
    >
      <div className="h-64 w-full overflow-hidden">
        <img 
          src={item.imageUrl} 
          alt={item.title} 
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
      </div>
      <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/30 to-transparent p-4 flex flex-col justify-end opacity-90 transition-opacity group-hover:opacity-100">
        <h3 className="text-white text-lg font-semibold">{item.title}</h3>
        <p className="text-gray-200 text-sm mt-1">{item.structureName}</p>
      </div>
    </div>
  );
};

export default GalleryCard;