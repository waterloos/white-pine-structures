import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { Structure } from '../../types';

interface StructureCardProps {
  structure: Structure;
  showDetails?: boolean;
}

const StructureCard: React.FC<StructureCardProps> = ({ 
  structure, 
  showDetails = false 
}) => {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden transition-transform duration-300 hover:shadow-xl">
      <div className="h-56 overflow-hidden">
        <img 
          src={structure.imageUrl} 
          alt={structure.name}
          className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
        />
      </div>
      <div className="p-6">
        <h3 className="text-xl font-semibold text-gray-900 mb-2">{structure.name}</h3>
        <p className="text-gray-600 mb-4">{structure.description}</p>
        
        {showDetails && (
          <div className="mb-4">
            <div className="flex justify-between text-sm mb-2">
              <span className="text-gray-500">Size Range:</span>
              <span className="font-medium">{structure.minSize} - {structure.maxSize}</span>
            </div>
            <div className="flex justify-between text-sm mb-2">
              <span className="text-gray-500">Base Price:</span>
              <span className="font-medium">${structure.basePrice.toLocaleString()}</span>
            </div>
            
            <div className="mt-4">
              <h4 className="text-sm font-semibold text-gray-700 mb-2">Features:</h4>
              <ul className="text-sm text-gray-600 space-y-1 ml-4">
                {structure.features.slice(0, 3).map((feature, index) => (
                  <li key={index} className="list-disc">{feature}</li>
                ))}
                {structure.features.length > 3 && (
                  <li className="text-[#978E5F] font-medium">+ {structure.features.length - 3} more</li>
                )}
              </ul>
            </div>
          </div>
        )}
        
        <div className="mt-4">
          <Link
            to={`/structures/${structure.id}`}
            className="inline-flex items-center text-[#978E5F] font-medium hover:underline"
          >
            View Details
            <ArrowRight className="ml-1 h-4 w-4" />
          </Link>
        </div>
      </div>
    </div>
  );
};

export default StructureCard;