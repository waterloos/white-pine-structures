import React, { useState, useEffect } from 'react';
import { getImageUrl, getPlaceholderUrl } from '../../utils/imageLoader';

interface ImageProps extends React.ImgHTMLAttributes<HTMLImageElement> {
  src: string;
  alt: string;
  width?: number;
  height?: number;
  sizes?: string;
  className?: string;
  priority?: boolean;
}

const Image: React.FC<ImageProps> = ({
  src,
  alt,
  width,
  height,
  sizes = '100vw',
  className = '',
  priority = false,
  ...props
}) => {
  const [isLoaded, setIsLoaded] = useState(false);
  const [error, setError] = useState(false);

  // Generate srcSet for responsive images
  const srcSet = [0.5, 1, 1.5, 2]
    .map(dpr => {
      const w = width ? width * dpr : undefined;
      return `${getImageUrl(src, { width: w, dpr })} ${dpr}x`;
    })
    .join(', ');

  // Generate low-quality placeholder
  const placeholder = getPlaceholderUrl(src);

  useEffect(() => {
    if (priority) {
      const img = new Image();
      img.src = getImageUrl(src, { width, height });
      img.onload = () => setIsLoaded(true);
      img.onerror = () => setError(true);
    }
  }, [src, width, height, priority]);

  return (
    <div className={`relative overflow-hidden ${className}`}>
      {/* Placeholder image with blur effect */}
      {!isLoaded && !error && (
        <img
          src={placeholder}
          alt=""
          className="absolute inset-0 w-full h-full object-cover filter blur-lg scale-110 transform"
          aria-hidden="true"
        />
      )}
      
      {/* Main image */}
      <img
        src={getImageUrl(src, { width, height })}
        srcSet={srcSet}
        sizes={sizes}
        alt={alt}
        width={width}
        height={height}
        onLoad={() => setIsLoaded(true)}
        onError={() => setError(true)}
        className={`w-full h-full object-cover transition-opacity duration-300 ${
          isLoaded ? 'opacity-100' : 'opacity-0'
        }`}
        loading={priority ? 'eager' : 'lazy'}
        {...props}
      />
    </div>
  );
};

export default Image;