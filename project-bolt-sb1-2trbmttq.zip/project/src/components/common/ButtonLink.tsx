import React from 'react';
import { Link } from 'react-router-dom';

interface ButtonLinkProps {
  to: string;
  children: React.ReactNode;
  variant?: 'primary' | 'secondary' | 'outline';
  className?: string;
}

const ButtonLink: React.FC<ButtonLinkProps> = ({ 
  to, 
  children, 
  variant = 'primary',
  className = ''
}) => {
  const baseClasses = "inline-block px-6 py-3 rounded font-medium transition-colors duration-300 text-center";
  
  const variantClasses = {
    primary: "bg-[#978E5F] text-white hover:bg-opacity-90",
    secondary: "bg-gray-800 text-white hover:bg-gray-700",
    outline: "border border-[#978E5F] text-[#978E5F] hover:bg-[#978E5F] hover:text-white"
  };

  return (
    <Link 
      to={to} 
      className={`${baseClasses} ${variantClasses[variant]} ${className}`}
    >
      {children}
    </Link>
  );
};

export default ButtonLink;