import React from 'react';
import { Link } from 'react-router-dom';
import { StockStructure } from '../../types';
import { CheckCircle, MapPin } from 'lucide-react';

interface StockStructureCardProps {
  structure: StockStructure;
}

const StockStructureCard: React.FC<StockStructureCardProps> = ({ structure }) => {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden transition-transform duration-300 hover:shadow-xl border border-gray-200">
      <div className="relative">
        <div className="h-56 overflow-hidden">
          <img 
            src={structure.imageUrl} 
            alt={structure.name}
            className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
          />
        </div>
        {structure.available && (
          <div className="absolute top-4 right-4 bg-green-500 text-white text-xs font-bold px-3 py-1 rounded-full flex items-center">
            <CheckCircle className="mr-1 h-3 w-3" />
            Available Now
          </div>
        )}
      </div>
      
      <div className="p-6">
        <div className="flex justify-between items-start mb-3">
          <h3 className="text-xl font-semibold text-gray-900">{structure.name}</h3>
          <span className="text-xl font-bold text-[#978E5F]">${structure.price.toLocaleString()}</span>
        </div>
        
        <div className="flex items-center mb-4 text-sm text-gray-500">
          <MapPin className="h-4 w-4 mr-1 text-gray-400" />
          <span>{structure.location}</span>
        </div>
        
        <div className="grid grid-cols-2 gap-4 mb-4 text-sm">
          <div>
            <span className="text-gray-500">Size:</span>
            <p className="font-medium">{structure.size}</p>
          </div>
          <div>
            <span className="text-gray-500">Color:</span>
            <p className="font-medium">{structure.color}</p>
          </div>
        </div>
        
        <div className="mb-4">
          <span className="text-gray-500 text-sm">Features:</span>
          <div className="mt-1 flex flex-wrap gap-2">
            {structure.additionalFeatures.map((feature, index) => (
              <span key={index} className="bg-gray-100 text-gray-700 text-xs px-2 py-1 rounded">{feature}</span>
            ))}
          </div>
        </div>
        
        <div className="mt-4 flex space-x-3">
          <Link
            to={`/stock-structures/${structure.id}`}
            className="flex-1 bg-[#978E5F] text-white text-center py-2 rounded hover:bg-opacity-90 transition-colors"
          >
            View Details
          </Link>
          <Link
            to={`/contact?inquire=${structure.id}`}
            className="flex-1 border border-[#978E5F] text-[#978E5F] text-center py-2 rounded hover:bg-[#978E5F] hover:text-white transition-colors"
          >
            Inquire
          </Link>
        </div>
      </div>
    </div>
  );
};

export default StockStructureCard;