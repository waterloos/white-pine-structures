import React, { useEffect } from 'react';
import Hero from '../components/home/Hero';
import FeaturedCategories from '../components/home/FeaturedCategories';
import WhyChooseUs from '../components/home/WhyChooseUs';
import FeaturedStock from '../components/home/FeaturedStock';
import TestimonialSection from '../components/home/TestimonialSection';
import CTASection from '../components/home/CTASection';
import { Calendar, DollarSign, CheckCircle, Clock } from 'lucide-react';

const Home: React.FC = () => {
  useEffect(() => {
    document.title = 'White Pine Structures - Custom Sheds, Garages & Outdoor Structures';
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  }, []);

  return (
    <main>
      <section aria-labelledby="hero-heading">
        <h1 id="hero-heading" className="sr-only">White Pine Structures - Custom Sheds, Garages & Outdoor Structures</h1>
        <Hero />
      </section>

      <section aria-labelledby="categories-heading">
        <h2 id="categories-heading" className="sr-only">Our Product Categories</h2>
        <FeaturedCategories />
      </section>

      <section aria-labelledby="why-choose-heading">
        <h2 id="why-choose-heading" className="sr-only">Why Choose White Pine Structures</h2>
        <WhyChooseUs />
      </section>

      <section aria-labelledby="featured-stock-heading">
        <h2 id="featured-stock-heading" className="sr-only">Featured Stock Structures</h2>
        <FeaturedStock />
      </section>

      <section aria-labelledby="testimonials-heading">
        <h2 id="testimonials-heading" className="sr-only">Customer Testimonials</h2>
        <TestimonialSection />
      </section>

      {/* SmartPay Rent-to-Own Section */}
      <section aria-labelledby="smartpay-heading" className="py-16 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto text-center">
            <h2 id="smartpay-heading" className="text-3xl font-serif font-bold text-gray-900 mb-6">
              Flexible Rent-to-Own Options
            </h2>
            <p className="text-lg text-gray-600 mb-12">
              Get your dream structure today with SmartPay's easy rent-to-own program. No credit check required!
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              <div className="bg-gray-50 p-6 rounded-lg">
                <Calendar className="h-8 w-8 text-[#978E5F] mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Flexible Terms</h3>
                <p className="text-gray-600 text-sm">
                  Choose from 24 or 36-month payment plans that fit your budget
                </p>
              </div>
              <div className="bg-gray-50 p-6 rounded-lg">
                <DollarSign className="h-8 w-8 text-[#978E5F] mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Low Payments</h3>
                <p className="text-gray-600 text-sm">
                  Affordable monthly payments with a small initial deposit
                </p>
              </div>
              <div className="bg-gray-50 p-6 rounded-lg">
                <CheckCircle className="h-8 w-8 text-[#978E5F] mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">No Credit Check</h3>
                <p className="text-gray-600 text-sm">
                  Quick approval process with no credit check required
                </p>
              </div>
              <div className="bg-gray-50 p-6 rounded-lg">
                <Clock className="h-8 w-8 text-[#978E5F] mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Early Payoff</h3>
                <p className="text-gray-600 text-sm">
                  Pay off early anytime with no prepayment penalties
                </p>
              </div>
            </div>
            <p className="text-sm text-gray-500 mt-8">
              Rent-to-Own program provided through SmartPay. Visit any of our locations to learn more about payment options.
            </p>
          </div>
        </div>
      </section>

      <section aria-labelledby="service-areas-heading" className="py-16 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <h2 id="service-areas-heading" className="text-3xl font-serif font-bold text-center text-gray-900 mb-8">
            Our Service Area
          </h2>
          <div className="max-w-4xl mx-auto">
            <p className="text-lg text-gray-600 text-center mb-12">
              White Pine Structures proudly serves customers throughout the Mid-Atlantic region, delivering and installing our custom structures across Pennsylvania, New Jersey, Delaware, and Maryland.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="bg-gray-50 p-6 rounded-lg">
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Pennsylvania</h3>
                <div className="grid grid-cols-2 gap-2 text-gray-600">
                  <div>• Chester County</div>
                  <div>• Lancaster County</div>
                  <div>• Delaware County</div>
                  <div>• Montgomery County</div>
                  <div>• Berks County</div>
                  <div>• York County</div>
                </div>
              </div>
              <div className="bg-gray-50 p-6 rounded-lg">
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Additional Service Areas</h3>
                <div className="space-y-4">
                  <div>
                    <p className="font-medium text-gray-800">New Jersey</p>
                    <p className="text-gray-600">South Jersey regions including Camden, Burlington, and Gloucester counties</p>
                  </div>
                  <div>
                    <p className="font-medium text-gray-800">Delaware</p>
                    <p className="text-gray-600">New Castle County and surrounding areas</p>
                  </div>
                  <div>
                    <p className="font-medium text-gray-800">Maryland</p>
                    <p className="text-gray-600">Northern Maryland including Cecil and Harford counties</p>
                  </div>
                </div>
              </div>
            </div>
            <p className="text-sm text-gray-500 text-center mt-8">
              Contact us to confirm service availability in your specific location. Delivery fees may vary based on distance.
            </p>
          </div>
        </div>
      </section>

      <section aria-labelledby="quality-heading" className="py-16 bg-[#978E5F] bg-opacity-10">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto text-center">
            <h2 id="quality-heading" className="text-3xl font-serif font-bold text-gray-900 mb-6">
              Our Quality Promise
            </h2>
            <p className="text-lg text-gray-700 mb-8">
              At White Pine Structures, we stand behind every structure we build. Our commitment to quality is backed by:
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="bg-white p-6 rounded-lg shadow-sm">
                <h3 className="text-xl font-semibold text-gray-900 mb-3">Premium Materials</h3>
                <p className="text-gray-600">
                  We use only the highest quality, pressure-treated lumber and premium hardware to ensure your structure stands the test of time.
                </p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-sm">
                <h3 className="text-xl font-semibold text-gray-900 mb-3">Expert Craftsmanship</h3>
                <p className="text-gray-600">
                  Our skilled craftsmen bring decades of experience to every project, ensuring superior construction and attention to detail.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section aria-labelledby="cta-heading">
        <h2 id="cta-heading" className="sr-only">Get Started with Your Custom Structure</h2>
        <CTASection />
      </section>
    </main>
  );
};

export default Home;