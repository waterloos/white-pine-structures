import React, { useEffect, useState } from 'react';
import GalleryCard from '../components/common/GalleryCard';
import TestimonialCard from '../components/common/TestimonialCard';
import { Gallery as GalleryType } from '../types';
import { galleryItems, testimonials } from '../data/gallery';
import { X } from 'lucide-react';

const Gallery: React.FC = () => {
  const [filter, setFilter] = useState<string>('all');
  const [filteredItems, setFilteredItems] = useState<GalleryType[]>(galleryItems);
  const [selectedItem, setSelectedItem] = useState<GalleryType | null>(null);
  const [lightboxOpen, setLightboxOpen] = useState(false);

  useEffect(() => {
    window.scrollTo(0, 0);
    document.title = 'Gallery - White Pine Structures';
  }, []);

  useEffect(() => {
    if (filter === 'all') {
      setFilteredItems(galleryItems);
    } else {
      setFilteredItems(galleryItems.filter(item => item.structureType === filter));
    }
  }, [filter]);

  const openLightbox = (item: GalleryType) => {
    setSelectedItem(item);
    setLightboxOpen(true);
    document.body.style.overflow = 'hidden';
  };

  const closeLightbox = () => {
    setLightboxOpen(false);
    document.body.style.overflow = 'auto';
  };

  return (
    <div>
      {/* Hero Section - Apple Style */}
      <div className="pt-40 pb-24 bg-gradient-to-b from-white to-gray-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-6xl sm:text-7xl font-semibold tracking-tight text-gray-900 mb-6">
              Project Gallery
            </h1>
            <p className="text-xl sm:text-2xl text-gray-500 leading-relaxed max-w-3xl mx-auto">
              Browse our gallery of completed projects and see the quality craftsmanship that goes into every White Pine structure.
            </p>
          </div>
        </div>
      </div>

      {/* Gallery Section */}
      <div className="py-16 bg-gray-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          {/* Filter Tabs */}
          <div className="flex justify-center mb-12">
            <div className="inline-flex bg-white rounded-lg p-1 shadow-md">
              <button
                className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                  filter === 'all' ? 'bg-[#978E5F] text-white' : 'text-gray-700 hover:bg-gray-100'
                }`}
                onClick={() => setFilter('all')}
              >
                All Projects
              </button>
              <button
                className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                  filter === 'shed' ? 'bg-[#978E5F] text-white' : 'text-gray-700 hover:bg-gray-100'
                }`}
                onClick={() => setFilter('shed')}
              >
                Sheds
              </button>
              <button
                className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                  filter === 'garage' ? 'bg-[#978E5F] text-white' : 'text-gray-700 hover:bg-gray-100'
                }`}
                onClick={() => setFilter('garage')}
              >
                Garages
              </button>
              <button
                className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                  filter === 'other' ? 'bg-[#978E5F] text-white' : 'text-gray-700 hover:bg-gray-100'
                }`}
                onClick={() => setFilter('other')}
              >
                Other
              </button>
            </div>
          </div>
          
          {/* Gallery Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredItems.map(item => (
              <GalleryCard 
                key={item.id} 
                item={item}
                onClick={() => openLightbox(item)}
              />
            ))}
          </div>
          
          {filteredItems.length === 0 && (
            <div className="text-center py-16">
              <h3 className="text-2xl font-semibold text-gray-700">No projects found</h3>
              <p className="text-gray-600 mt-2">Try selecting a different category.</p>
            </div>
          )}
        </div>
      </div>

      {/* Testimonials Section */}
      <div className="py-16 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-serif font-bold text-gray-900 mb-4">What Our Customers Say</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Don't just take our word for it. Here's what our customers have to say about their White Pine Structures.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map(testimonial => (
              <TestimonialCard 
                key={testimonial.id} 
                testimonial={testimonial} 
              />
            ))}
          </div>
        </div>
      </div>

      {/* Lightbox */}
      {lightboxOpen && selectedItem && (
        <div className="fixed inset-0 bg-black bg-opacity-90 z-50 flex items-center justify-center p-4">
          <div className="max-w-6xl w-full max-h-screen overflow-auto">
            <div className="relative">
              <button
                onClick={closeLightbox}
                className="absolute top-4 right-4 bg-white bg-opacity-20 p-2 rounded-full text-white hover:bg-opacity-40 transition-colors"
              >
                <X size={24} />
              </button>
              
              <img 
                src={selectedItem.imageUrl} 
                alt={selectedItem.title} 
                className="w-full h-auto rounded-lg"
              />
              
              <div className="bg-white p-6 rounded-lg mt-4">
                <h3 className="text-2xl font-semibold text-gray-900 mb-2">{selectedItem.title}</h3>
                <p className="text-gray-700 mb-4">{selectedItem.description}</p>
                <div className="flex items-center">
                  <span className="text-sm font-medium text-gray-500">Structure Type:</span>
                  <span className="ml-2 text-sm bg-[#978E5F] bg-opacity-20 text-[#978E5F] px-2 py-1 rounded">
                    {selectedItem.structureName}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Gallery;