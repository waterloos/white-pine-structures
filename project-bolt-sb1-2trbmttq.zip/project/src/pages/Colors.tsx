import React, { useEffect, useState } from 'react';
import { colorCategories, getPopularColors } from '../data/colors';
import type { ColorOption } from '../types/colors';

const Colors: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const popularColors = getPopularColors();

  useEffect(() => {
    window.scrollTo(0, 0);
    document.title = 'Color Options - White Pine Structures';
  }, []);

  const ColorSwatch: React.FC<{ color: ColorOption }> = ({ color }) => (
    <div className="group relative">
      <div className="aspect-square rounded-lg overflow-hidden shadow-md">
        <div 
          className="w-full h-full"
          style={{ backgroundColor: color.hex }}
        />
      </div>
      <div className="mt-2">
        <h4 className="font-medium text-gray-900">{color.name}</h4>
        {color.description && (
          <p className="text-sm text-gray-500">{color.description}</p>
        )}
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <div className="pt-32 pb-16 bg-gradient-to-b from-gray-900 to-gray-800">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl">
            <h1 className="text-5xl sm:text-6xl font-serif font-bold mb-6 text-white tracking-tight">
              Color Options
            </h1>
            <p className="text-xl text-gray-300 leading-relaxed max-w-3xl">
              Choose from our wide selection of colors to create a structure that perfectly matches your style and surroundings.
            </p>
          </div>
        </div>
      </div>

      <div className="py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          {/* Popular Colors */}
          <section className="mb-16">
            <h2 className="text-3xl font-serif font-bold text-gray-900 mb-8">Popular Colors</h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-6">
              {popularColors.map(color => (
                <ColorSwatch key={`${color.category}-${color.id}`} color={color} />
              ))}
            </div>
          </section>

          {/* Category Navigation */}
          <div className="flex flex-wrap gap-2 mb-8">
            <button
              onClick={() => setSelectedCategory('all')}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                selectedCategory === 'all'
                  ? 'bg-[#978E5F] text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              All Colors
            </button>
            {colorCategories.map(category => (
              <button
                key={category.id}
                onClick={() => setSelectedCategory(category.id)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                  selectedCategory === category.id
                    ? 'bg-[#978E5F] text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {category.name}
              </button>
            ))}
          </div>

          {/* Color Categories */}
          {(selectedCategory === 'all' ? colorCategories : colorCategories.filter(cat => cat.id === selectedCategory))
            .map(category => (
              <section key={category.id} className="mb-16">
                <h2 className="text-3xl font-serif font-bold text-gray-900 mb-4">{category.name}</h2>
                <p className="text-gray-600 mb-8">{category.description}</p>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-6">
                  {category.options.map(color => (
                    <ColorSwatch key={`${category.id}-${color.id}`} color={color} />
                  ))}
                </div>
              </section>
            ))}
        </div>
      </div>
    </div>
  );
};

export default Colors;