import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, MapPin, DollarSign, Clock, Tag, Check, Info } from 'lucide-react';
import { getStockItemByModelNumber } from '../data/stockInventory';
import type { StockInventoryItem } from '../types';
import ButtonLink from '../components/common/ButtonLink';
import StockImageGallery from '../components/stock/StockImageGallery';

const StockStructureDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [item, setItem] = useState<StockInventoryItem | null>(null);

  useEffect(() => {
    if (id) {
      const stockItem = getStockItemByModelNumber(id);
      setItem(stockItem || null);
      
      if (stockItem) {
        document.title = `${stockItem.name} - Stock Structure - White Pine Structures`;
      }
      
      window.scrollTo(0, 0);
    }
  }, [id]);

  if (!item) {
    return (
      <div className="min-h-screen bg-gray-50 pt-32 pb-16">
        <div className="container mx-auto px-4">
          <div className="text-center">
            <h1 className="text-2xl font-semibold text-gray-900">Structure not found</h1>
            <p className="mt-2 text-gray-600">The structure you're looking for doesn't exist.</p>
            <Link to="/stock-structures" className="mt-4 inline-block text-[#978E5F] hover:underline">
              Return to stock structures
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const inquiryParams = new URLSearchParams({
    model: item.modelNumber,
    type: item.type,
    size: item.specifications.size,
    name: item.name
  }).toString();

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section - Apple Style */}
      <div className="pt-32 pb-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <Link 
            to="/stock-structures"
            className="inline-flex items-center text-gray-500 hover:text-gray-900 transition-colors mb-8"
          >
            <ArrowLeft className="mr-2 h-5 w-5" />
            Back to Stock Structures
          </Link>

          <div className="max-w-4xl">
            <div className="flex items-center gap-4 mb-6">
              <span className="bg-gray-100 text-gray-600 px-3 py-1 rounded-full text-sm">
                #{item.modelNumber}
              </span>
              {item.status === 'available' && (
                <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-sm">
                  Available Now
                </span>
              )}
            </div>

            <h1 className="text-6xl sm:text-7xl font-semibold tracking-tight text-gray-900 mb-6">
              {item.name}
            </h1>
            
            <p className="text-xl sm:text-2xl text-gray-500 leading-relaxed max-w-3xl">
              {item.description}
            </p>

            <div className="mt-8 flex flex-wrap gap-6 text-lg text-gray-600">
              <div className="flex items-center">
                <Tag className="h-5 w-5 mr-2" />
                <span>{item.specifications.size}</span>
              </div>
              <div className="flex items-center">
                <MapPin className="h-5 w-5 mr-2" />
                <span>{item.location}</span>
              </div>
              <div className="flex items-center text-[#978E5F] font-medium">
                <DollarSign className="h-5 w-5 mr-2" />
                <span>${item.pricing.retailPrice.toLocaleString()}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Gallery Section */}
      <div className="bg-gray-50 py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <StockImageGallery images={item.images} />
        </div>
      </div>

      {/* Main Content */}
      <div className="py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            {/* Left Column - Details */}
            <div className="lg:col-span-2 space-y-12">
              {/* Specifications */}
              <section>
                <h2 className="text-3xl font-semibold text-gray-900 mb-8">Specifications</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="bg-gray-50 p-6 rounded-2xl">
                    <h3 className="font-medium text-gray-900 mb-3">Size & Material</h3>
                    <p className="text-gray-600">
                      {item.specifications.size}<br />
                      {item.specifications.material}
                    </p>
                  </div>
                  <div className="bg-gray-50 p-6 rounded-2xl">
                    <h3 className="font-medium text-gray-900 mb-3">Colors</h3>
                    <p className="text-gray-600">
                      Siding: {item.specifications.sidingColor}<br />
                      Trim: {item.specifications.trimColor}<br />
                      Roof: {item.specifications.roofColor}
                    </p>
                  </div>
                </div>
              </section>

              {/* Features */}
              {item.specifications.additionalFeatures && (
                <section>
                  <h2 className="text-3xl font-semibold text-gray-900 mb-8">Features</h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {item.specifications.additionalFeatures.map((feature, index) => (
                      <div key={index} className="flex items-start">
                        <Check className="h-5 w-5 text-[#978E5F] flex-shrink-0 mt-1 mr-3" />
                        <span className="text-gray-600">{feature}</span>
                      </div>
                    ))}
                  </div>
                </section>
              )}

              {/* Customization Options */}
              {item.customizations?.available && (
                <section>
                  <h2 className="text-3xl font-semibold text-gray-900 mb-8">Available Customizations</h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {item.customizations.options?.map((option, index) => (
                      <div key={index} className="flex items-start">
                        <Check className="h-5 w-5 text-[#978E5F] flex-shrink-0 mt-1 mr-3" />
                        <span className="text-gray-600">{option}</span>
                      </div>
                    ))}
                  </div>
                </section>
              )}
            </div>

            {/* Right Column - Pricing & CTA */}
            <div className="lg:col-span-1">
              <div className="sticky top-24 bg-gray-50 rounded-2xl p-8">
                <div className="mb-8">
                  <div className="flex items-baseline justify-between mb-2">
                    <span className="text-gray-600">Price</span>
                    <span className="text-3xl font-semibold text-gray-900">
                      ${item.pricing.retailPrice.toLocaleString()}
                    </span>
                  </div>
                  <p className="text-sm text-gray-500">
                    * Final price includes sales tax and delivery
                  </p>
                </div>

                {item.pricing.rentToOwn && (
                  <div className="mb-8 pb-8 border-b border-gray-200">
                    <div className="flex items-center text-gray-600 mb-2">
                      <Clock className="h-5 w-5 mr-2" />
                      <span>Rent to Own Available</span>
                    </div>
                    <p className="text-gray-900">
                      From ${item.pricing.rentToOwn.monthlyPayment}/month
                      <span className="text-sm text-gray-500 block mt-1">
                        for {item.pricing.rentToOwn.term} months
                      </span>
                    </p>
                  </div>
                )}

                <div className="space-y-4">
                  <ButtonLink 
                    to={`/contact?${inquiryParams}`}
                    variant="primary"
                    className="w-full justify-center text-lg py-4"
                  >
                    Request Quote
                  </ButtonLink>
                  
                  <ButtonLink 
                    to="/proposal-generator" 
                    variant="outline"
                    className="w-full justify-center"
                  >
                    Customize Design
                  </ButtonLink>
                </div>

                <div className="mt-8 bg-white rounded-xl p-4">
                  <div className="flex items-start">
                    <Info className="h-5 w-5 text-[#978E5F] flex-shrink-0 mt-0.5 mr-2" />
                    <p className="text-sm text-gray-600">
                      Currently on display at our {item.location}. Visit us to see it in person.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StockStructureDetail;