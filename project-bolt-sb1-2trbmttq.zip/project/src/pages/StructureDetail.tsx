import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Check, Info } from 'lucide-react';
import { Structure } from '../types';
import { getStructureById } from '../data/structures';
import ButtonLink from '../components/common/ButtonLink';
import StructureGallery from '../components/common/StructureGallery';

const StructureDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [structure, setStructure] = useState<Structure | null>(null);

  useEffect(() => {
    if (id) {
      const structureData = getStructureById(id);
      setStructure(structureData || null);
      
      if (structureData) {
        document.title = `${structureData.name} - White Pine Structures`;
      }
      
      window.scrollTo(0, 0);
    }
  }, [id]);

  if (!structure) {
    return (
      <div className="min-h-screen bg-gray-50 pt-32 pb-16">
        <div className="container mx-auto px-4">
          <div className="text-center">
            <h1 className="text-2xl font-semibold text-gray-900">Structure not found</h1>
            <p className="mt-2 text-gray-600">The structure you're looking for doesn't exist.</p>
            <Link to="/all-structures" className="mt-4 inline-block text-[#978E5F] hover:underline">
              Browse All Structures
            </Link>
          </div>
        </div>
      </div>
    );
  }

  // Create query parameters for contact form
  const inquiryParams = new URLSearchParams({
    type: structure.type,
    name: structure.name,
    size: structure.minSize,
    subject: `Inquiry about ${structure.name}`,
    message: `I'm interested in the ${structure.name} with the following specifications:\n\n- Type: ${structure.type}\n- Size: ${structure.minSize}\n- Base Price: $${structure.basePrice.toLocaleString()}\n\nPlease provide more information about customization options and pricing.`
  }).toString();

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section - Apple Style */}
      <div className="pt-32 pb-24 bg-gradient-to-b from-white to-gray-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <Link 
            to={`/${structure.type}s`}
            className="inline-flex items-center text-gray-500 hover:text-gray-900 transition-colors mb-8"
          >
            <ArrowLeft className="mr-2 h-5 w-5" />
            Back to {structure.type === 'other' ? 'Other Structures' : `${structure.type}s`}
          </Link>

          <div className="max-w-4xl">
            <h1 className="text-6xl sm:text-7xl font-semibold tracking-tight text-gray-900 mb-6">
              {structure.name}
            </h1>
            <p className="text-xl sm:text-2xl text-gray-500 leading-relaxed max-w-3xl">
              {structure.description}
            </p>
            <div className="mt-8 flex flex-wrap gap-4 text-lg">
              <div className="bg-gray-100 px-4 py-2 rounded-full">
                <span className="text-gray-500">Starting at </span>
                <span className="font-semibold text-gray-900">${structure.basePrice.toLocaleString()}</span>
              </div>
              <div className="bg-gray-100 px-4 py-2 rounded-full">
                <span className="text-gray-500">Size Range: </span>
                <span className="font-semibold text-gray-900">{structure.minSize} - {structure.maxSize}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Gallery Section */}
      <div className="bg-gray-50 py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-7xl mx-auto">
            <h2 className="text-3xl font-semibold text-gray-900 mb-8">Gallery</h2>
            <StructureGallery images={structure.gallery || []} />
            <div className="mt-4 text-center">
              <Link to="/gallery" className="text-[#978E5F] hover:underline">
                View More Examples in Our Gallery
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            {/* Left Column - Details */}
            <div className="lg:col-span-2">
              <div className="bg-white rounded-lg shadow-md p-8 mb-8">
                <h2 className="text-2xl font-semibold text-gray-900 mb-6">Features & Specifications</h2>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
                  <div>
                    <h3 className="font-medium text-gray-900 mb-3">Size Range</h3>
                    <p className="text-gray-600">
                      Minimum: {structure.minSize}<br />
                      Maximum: {structure.maxSize}
                    </p>
                    <p className="mt-2 text-sm">
                      <Link to="/site-preparation" className="text-[#978E5F] hover:underline">
                        View Site Preparation Guide
                      </Link>
                    </p>
                  </div>
                  <div>
                    <h3 className="font-medium text-gray-900 mb-3">Base Price</h3>
                    <p className="text-2xl font-bold text-[#978E5F]">
                      ${structure.basePrice.toLocaleString()}
                    </p>
                    <p className="mt-2 text-sm">
                      <Link to="/financing" className="text-[#978E5F] hover:underline">
                        View Financing Options
                      </Link>
                    </p>
                  </div>
                </div>
                
                <div className="mb-8">
                  <h3 className="font-medium text-gray-900 mb-3">Standard Features</h3>
                  <ul className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {structure.features.map((feature, index) => (
                      <li key={index} className="flex items-start">
                        <Check className="h-5 w-5 text-[#978E5F] flex-shrink-0 mt-0.5 mr-2" />
                        <span className="text-gray-600">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                
                <div>
                  <h3 className="font-medium text-gray-900 mb-3">Available Options</h3>
                  <div className="space-y-4">
                    {structure.options.map(option => (
                      <div key={option.id} className="bg-gray-50 rounded-lg p-4">
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <h4 className="font-medium text-gray-900">{option.name}</h4>
                            <p className="text-sm text-gray-600">{option.description}</p>
                          </div>
                          <span className="text-[#978E5F] font-medium">
                            +${typeof option.priceModifier === 'function' 
                              ? option.priceModifier(structure.basePrice).toLocaleString()
                              : option.priceModifier.toLocaleString()}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Construction Details */}
              <div className="bg-white rounded-lg shadow-md p-8">
                <h2 className="text-2xl font-semibold text-gray-900 mb-6">Construction Details</h2>
                <div className="prose max-w-none text-gray-600">
                  <p className="mb-4">
                    Every {structure.name} is built with premium materials and expert craftsmanship to ensure lasting quality and durability. Our structures feature:
                  </p>
                  <ul className="list-disc pl-5 space-y-2 mb-6">
                    <li>Pressure-treated floor joists and skids for superior durability</li>
                    <li>Premium-grade lumber throughout the construction</li>
                    <li>High-quality roofing materials with warranty protection</li>
                    <li>Professional-grade hardware and fasteners</li>
                    <li>Multiple ventilation options for proper airflow</li>
                    <li>Custom door and window placements available</li>
                  </ul>
                  <div className="bg-blue-50 rounded-lg p-4 flex items-start">
                    <Info className="h-5 w-5 text-blue-500 flex-shrink-0 mt-0.5 mr-2" />
                    <div>
                      <p className="text-blue-800 text-sm mb-2">
                        All our structures are built to meet or exceed local building codes and come with our comprehensive warranty coverage.
                      </p>
                      <Link to="/warranty" className="text-blue-600 hover:underline text-sm">
                        Learn More About Our Warranty
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Right Column - CTA */}
            <div className="lg:col-span-1">
              <div className="bg-white rounded-lg shadow-md p-8 sticky top-24">
                <h2 className="text-xl font-semibold text-gray-900 mb-6">Ready to Get Started?</h2>
                
                <div className="space-y-4 mb-8">
                  <ButtonLink 
                    to={`/contact?${inquiryParams}`}
                    variant="primary"
                    className="w-full justify-center"
                  >
                    Request Quote
                  </ButtonLink>
                  
                  <ButtonLink 
                    to="/proposal-generator" 
                    variant="outline"
                    className="w-full justify-center"
                  >
                    Generate Custom Proposal
                  </ButtonLink>
                </div>
                
                <div className="border-t border-gray-200 pt-6">
                  <h3 className="font-medium text-gray-900 mb-4">Why Choose White Pine Structures?</h3>
                  <ul className="space-y-3">
                    <li className="flex items-start">
                      <Check className="h-5 w-5 text-[#978E5F] flex-shrink-0 mt-0.5 mr-2" />
                      <span className="text-sm text-gray-600">25+ years of experience in custom structures</span>
                    </li>
                    <li className="flex items-start">
                      <Check className="h-5 w-5 text-[#978E5F] flex-shrink-0 mt-0.5 mr-2" />
                      <span className="text-sm text-gray-600">Premium materials and expert craftsmanship</span>
                    </li>
                    <li className="flex items-start">
                      <Check className="h-5 w-5 text-[#978E5F] flex-shrink-0 mt-0.5 mr-2" />
                      <span className="text-sm text-gray-600">Customizable to your specific needs</span>
                    </li>
                    <li className="flex items-start">
                      <Check className="h-5 w-5 text-[#978E5F] flex-shrink-0 mt-0.5 mr-2" />
                      <div className="text-sm text-gray-600">
                        Professional delivery and installation
                        <Link to="/delivery-installation" className="block text-[#978E5F] hover:underline mt-1">
                          Learn About Our Installation Process
                        </Link>
                      </div>
                    </li>
                  </ul>

                  <div className="mt-6 pt-6 border-t border-gray-200">
                    <h3 className="font-medium text-gray-900 mb-4">Have Questions?</h3>
                    <ul className="space-y-2">
                      <li>
                        <Link to="/faq" className="text-[#978E5F] hover:underline text-sm">
                          View Frequently Asked Questions
                        </Link>
                      </li>
                      <li>
                        <Link to="/building-permits" className="text-[#978E5F] hover:underline text-sm">
                          Building Permit Information
                        </Link>
                      </li>
                      <li>
                        <Link to="/maintenance-guide" className="text-[#978E5F] hover:underline text-sm">
                          Maintenance Guide
                        </Link>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StructureDetail;