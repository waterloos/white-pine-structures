import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import StructureCard from '../components/common/StructureCard';
import { Structure } from '../types';
import { shedStructures, garageStructures, otherStructures } from '../data/structures';

const StructureList: React.FC = () => {
  const { type } = useParams<{ type?: string }>();
  const [structures, setStructures] = useState<Structure[]>([]);
  const [title, setTitle] = useState<string>('');
  const [description, setDescription] = useState<string>('');

  useEffect(() => {
    window.scrollTo(0, 0);

    switch (type) {
      case 'sheds':
        setStructures(shedStructures);
        setTitle('Storage Sheds');
        setDescription('Choose from our selection of premium storage sheds, including Mini Barns, Hi Wall Barns, Quakers, Dutch Barns, and Workshop designs. Each shed is built with quality materials and expert craftsmanship.');
        document.title = 'Storage Sheds - White Pine Structures';
        break;
      case 'garages':
        setStructures(garageStructures);
        setTitle('Custom Garages');
        setDescription('Our custom garages provide secure vehicle storage and workspace, built to your specifications with quality materials.');
        document.title = 'Custom Garages - White Pine Structures';
        break;
      case 'other':
        setStructures(otherStructures);
        setTitle('Other Structures');
        setDescription('From greenhouses to hunting blinds, we build specialized structures to meet your unique outdoor needs.');
        document.title = 'Other Structures - White Pine Structures';
        break;
      case 'all':
      default:
        setStructures([...shedStructures, ...garageStructures, ...otherStructures]);
        setTitle('All Structures');
        setDescription('Browse our complete collection of custom-built outdoor structures.');
        document.title = 'All Structures - White Pine Structures';
    }
  }, [type]);

  return (
    <div>
      {/* Hero Section */}
      <div className="pt-40 pb-24 bg-gradient-to-b from-white to-gray-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-6xl sm:text-7xl font-semibold tracking-tight text-gray-900 mb-6">
              {title}
            </h1>
            <p className="text-xl sm:text-2xl text-gray-500 leading-relaxed max-w-3xl mx-auto">
              {description}
            </p>
          </div>
        </div>
      </div>

      {/* Structures Grid */}
      <div className="py-16 bg-gray-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          {type === 'sheds' && (
            <div className="mb-12">
              <h2 className="text-3xl font-serif font-bold text-gray-900 mb-6">Our Shed Styles</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-4">Traditional Styles</h3>
                  <ul className="space-y-2 text-gray-600">
                    <li>• Mini Barn - Classic barn styling with efficient storage</li>
                    <li>• Hi Wall Barn - Extra height for maximum storage</li>
                    <li>• Quaker - Elegant design with distinctive overhang</li>
                    <li>• Dutch Barn - Spacious with gambrel roof design</li>
                  </ul>
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-4">Workshop Styles</h3>
                  <ul className="space-y-2 text-gray-600">
                    <li>• Workshop - Purpose-built for projects and hobbies</li>
                    <li>• Classic Workshop - Traditional styling with modern features</li>
                    <li>• Classic Quaker - Premium design with enhanced features</li>
                  </ul>
                </div>
              </div>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {structures.map(structure => (
              <StructureCard 
                key={structure.id} 
                structure={structure} 
                showDetails={true}
              />
            ))}
          </div>
          
          {structures.length === 0 && (
            <div className="text-center py-16">
              <h3 className="text-2xl font-semibold text-gray-700">No structures found</h3>
              <p className="text-gray-600 mt-2">Please try another category or contact us for custom options.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default StructureList;