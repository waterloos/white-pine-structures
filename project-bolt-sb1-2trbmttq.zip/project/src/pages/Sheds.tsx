import React, { useEffect } from 'react';
import { shedStructures } from '../data/structures';
import StructureCard from '../components/common/StructureCard';

const Sheds: React.FC = () => {
  useEffect(() => {
    window.scrollTo(0, 0);
    document.title = 'Storage Sheds - White Pine Structures';
  }, []);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <div className="pt-32 pb-16 bg-gradient-to-b from-gray-900 to-gray-800">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl">
            <h1 className="text-5xl sm:text-6xl font-serif font-bold mb-6 text-white tracking-tight">
              Storage Sheds
            </h1>
            <p className="text-xl text-gray-300 leading-relaxed max-w-3xl">
              Choose from our selection of premium storage sheds, each built with quality materials and expert craftsmanship to meet your specific needs.
            </p>
          </div>
        </div>
      </div>

      {/* Categories Section */}
      <div className="py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-12">
            <h2 className="text-3xl font-serif font-bold text-gray-900 mb-6">Our Shed Styles</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Traditional Styles</h3>
                <ul className="space-y-3 text-gray-600">
                  <li className="flex items-start">
                    <span className="h-2 w-2 bg-[#978E5F] rounded-full mt-2 mr-3"></span>
                    <div>
                      <span className="font-medium">Mini Barn</span>
                      <p className="text-sm">Classic barn styling with efficient storage</p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <span className="h-2 w-2 bg-[#978E5F] rounded-full mt-2 mr-3"></span>
                    <div>
                      <span className="font-medium">Hi Wall Barn</span>
                      <p className="text-sm">Extra height for maximum storage</p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <span className="h-2 w-2 bg-[#978E5F] rounded-full mt-2 mr-3"></span>
                    <div>
                      <span className="font-medium">Quaker</span>
                      <p className="text-sm">Elegant design with distinctive overhang</p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <span className="h-2 w-2 bg-[#978E5F] rounded-full mt-2 mr-3"></span>
                    <div>
                      <span className="font-medium">Dutch Barn</span>
                      <p className="text-sm">Spacious with gambrel roof design</p>
                    </div>
                  </li>
                </ul>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Workshop Styles</h3>
                <ul className="space-y-3 text-gray-600">
                  <li className="flex items-start">
                    <span className="h-2 w-2 bg-[#978E5F] rounded-full mt-2 mr-3"></span>
                    <div>
                      <span className="font-medium">Workshop</span>
                      <p className="text-sm">Purpose-built for projects and hobbies</p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <span className="h-2 w-2 bg-[#978E5F] rounded-full mt-2 mr-3"></span>
                    <div>
                      <span className="font-medium">Classic Workshop</span>
                      <p className="text-sm">Traditional styling with modern features</p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <span className="h-2 w-2 bg-[#978E5F] rounded-full mt-2 mr-3"></span>
                    <div>
                      <span className="font-medium">Classic Quaker</span>
                      <p className="text-sm">Premium design with enhanced features</p>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
          </div>

          {/* Sheds Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {shedStructures.map(structure => (
              <StructureCard 
                key={structure.id} 
                structure={structure} 
                showDetails={true}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Sheds;