import React, { useEffect } from 'react';
import { garageStructures } from '../data/structures';
import StructureCard from '../components/common/StructureCard';

const Garages: React.FC = () => {
  useEffect(() => {
    window.scrollTo(0, 0);
    document.title = 'Custom Garages - White Pine Structures';
  }, []);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <div className="pt-32 pb-16 bg-gradient-to-b from-gray-900 to-gray-800">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl">
            <h1 className="text-5xl sm:text-6xl font-serif font-bold mb-6 text-white tracking-tight">
              Custom Garages
            </h1>
            <p className="text-xl text-gray-300 leading-relaxed max-w-3xl">
              From workshop garages to two-story designs, our custom garages combine superior craftsmanship with versatile functionality to meet your specific needs.
            </p>
          </div>
        </div>
      </div>

      {/* Categories Section */}
      <div className="py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-12">
            <h2 className="text-3xl font-serif font-bold text-gray-900 mb-6">Our Garage Styles</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Workshop & Classic Styles</h3>
                <ul className="space-y-3 text-gray-600">
                  <li className="flex items-start">
                    <span className="h-2 w-2 bg-[#978E5F] rounded-full mt-2 mr-3"></span>
                    <div>
                      <span className="font-medium">Workshop Garage</span>
                      <p className="text-sm">Versatile space with dedicated workshop area</p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <span className="h-2 w-2 bg-[#978E5F] rounded-full mt-2 mr-3"></span>
                    <div>
                      <span className="font-medium">Classic Workshop Garage</span>
                      <p className="text-sm">Traditional styling with modern functionality</p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <span className="h-2 w-2 bg-[#978E5F] rounded-full mt-2 mr-3"></span>
                    <div>
                      <span className="font-medium">Modular Garage</span>
                      <p className="text-sm">Quick-build design with flexible configuration</p>
                    </div>
                  </li>
                </ul>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Premium Designs</h3>
                <ul className="space-y-3 text-gray-600">
                  <li className="flex items-start">
                    <span className="h-2 w-2 bg-[#978E5F] rounded-full mt-2 mr-3"></span>
                    <div>
                      <span className="font-medium">Double Wide Classic</span>
                      <p className="text-sm">Spacious two-car garage with classic styling</p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <span className="h-2 w-2 bg-[#978E5F] rounded-full mt-2 mr-3"></span>
                    <div>
                      <span className="font-medium">Two Story Garage</span>
                      <p className="text-sm">Premium design with upstairs storage or living space</p>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
          </div>

          {/* Garages Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {garageStructures.map(structure => (
              <StructureCard 
                key={structure.id} 
                structure={structure} 
                showDetails={true}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Garages;