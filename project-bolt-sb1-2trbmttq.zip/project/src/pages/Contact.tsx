import React, { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { Phone, Mail, MapPin, Clock, CheckCircle, Loader2, AlertCircle } from 'lucide-react';
import { getStockItemByModelNumber } from '../data/stockInventory';

interface FormData {
  name: string;
  email: string;
  phone: string;
  subject: string;
  message: string;
  inquiryType: string;
  modelInfo?: {
    modelNumber?: string;
    type?: string;
    size?: string;
    name?: string;
  };
}

interface FormErrors {
  [key: string]: string;
}

const Contact: React.FC = () => {
  const location = useLocation();
  const [formSubmitted, setFormSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errors, setErrors] = useState<FormErrors>({});
  const [formData, setFormData] = useState<FormData>({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: '',
    inquiryType: 'general'
  });

  useEffect(() => {
    window.scrollTo(0, 0);
    document.title = 'Contact Us - White Pine Structures';
    
    // Parse query parameters
    const params = new URLSearchParams(location.search);
    const model = params.get('model');
    const type = params.get('type');
    const size = params.get('size');
    const name = params.get('name');
    const subject = params.get('subject');
    const message = params.get('message');
    
    // Handle stock structure inquiry
    if (model) {
      const stockItem = getStockItemByModelNumber(model);
      if (stockItem) {
        setFormData(prev => ({
          ...prev,
          subject: subject || `Inquiry about ${stockItem.name} (#${stockItem.modelNumber})`,
          inquiryType: 'stock',
          modelInfo: {
            modelNumber: stockItem.modelNumber,
            type: stockItem.type,
            size: stockItem.specifications.size,
            name: stockItem.name
          },
          message: message || `I'm interested in the ${stockItem.name} (#${stockItem.modelNumber}) that's currently in stock.\n\nSpecifications:\n- Size: ${stockItem.specifications.size}\n- Material: ${stockItem.specifications.material}\n- Price: $${stockItem.pricing.retailPrice.toLocaleString()}\n\nPlease provide information about availability and next steps.`
        }));
      }
    }
    // Handle custom structure inquiry
    else if (type && size) {
      setFormData(prev => ({
        ...prev,
        subject: subject || `Custom ${type} Inquiry (${size})`,
        inquiryType: 'custom',
        modelInfo: {
          type,
          size,
          name
        },
        message: message || `I'm interested in getting more information about building a custom ${type} with the following specifications:\n\n- Size: ${size}\n\nPlease provide information about pricing and next steps.`
      }));
    }
  }, [location]);

  const validateForm = (): boolean => {
    const newErrors: FormErrors = {};
    
    if (!formData.name.trim()) {
      newErrors.name = 'Name is required';
    }
    
    if (!formData.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Please enter a valid email address';
    }
    
    if (!formData.phone.trim()) {
      newErrors.phone = 'Phone number is required';
    } else if (!/^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/.test(formData.phone)) {
      newErrors.phone = 'Please enter a valid phone number';
    }
    
    if (!formData.message.trim()) {
      newErrors.message = 'Message is required';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    // Clear error when field is modified
    if (errors[name]) {
      setErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }
    
    setIsSubmitting(true);

    try {
      // Create the email data
      const emailData = {
        to: 'info@whitepinestructures.com',
        from: formData.email,
        subject: formData.subject || 'New Contact Form Submission',
        replyTo: formData.email,
        data: {
          name: formData.name,
          email: formData.email,
          phone: formData.phone,
          inquiryType: formData.inquiryType,
          message: formData.message,
          modelInfo: formData.modelInfo
        }
      };

      // Send the email
      const response = await fetch('/api/send-email', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(emailData)
      });

      if (!response.ok) {
        throw new Error('Failed to send email');
      }

      setFormSubmitted(true);
      setFormData({
        name: '',
        email: '',
        phone: '',
        subject: '',
        message: '',
        inquiryType: 'general'
      });
    } catch (error) {
      console.error('Error submitting form:', error);
      setErrors({
        submit: 'Failed to send message. Please try again or contact us directly.'
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div>
      {/* Hero Section - Apple Style */}
      <div className="pt-40 pb-24 bg-gradient-to-b from-white to-gray-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-6xl sm:text-7xl font-semibold tracking-tight text-gray-900 mb-6">
              Get in Touch
            </h1>
            <p className="text-xl sm:text-2xl text-gray-500 leading-relaxed max-w-3xl mx-auto">
              Have questions or ready to start your project? Our team is here to help bring your vision to life.
            </p>
          </div>
        </div>
      </div>

      <div className="py-16 bg-gray-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            {/* Contact Information */}
            <div className="lg:col-span-1">
              <div className="bg-white p-8 rounded-2xl shadow-sm">
                <h2 className="text-2xl font-semibold text-gray-900 mb-6">Contact Information</h2>
                
                <div className="space-y-6">
                  <div className="flex items-start">
                    <MapPin className="h-6 w-6 mr-4 text-[#978E5F] flex-shrink-0 mt-0.5" />
                    <div>
                      <h3 className="font-medium text-gray-900 mb-1">Our Location</h3>
                      <p className="text-gray-600">
                        3341 W Lincoln Hwy<br />
                        Parkesburg, PA 19365
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <Phone className="h-6 w-6 mr-4 text-[#978E5F] flex-shrink-0 mt-0.5" />
                    <div>
                      <h3 className="font-medium text-gray-900 mb-1">Phone</h3>
                      <a 
                        href="tel:+12075550123" 
                        className="text-gray-600 hover:text-[#978E5F] transition-colors"
                      >
                        (207) 555-0123
                      </a>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <Mail className="h-6 w-6 mr-4 text-[#978E5F] flex-shrink-0 mt-0.5" />
                    <div>
                      <h3 className="font-medium text-gray-900 mb-1">Email</h3>
                      <a 
                        href="mailto:info@whitepinestructures.com" 
                        className="text-gray-600 hover:text-[#978E5F] transition-colors"
                      >
                        info@whitepinestructures.com
                      </a>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <Clock className="h-6 w-6 mr-4 text-[#978E5F] flex-shrink-0 mt-0.5" />
                    <div>
                      <h3 className="font-medium text-gray-900 mb-1">Business Hours</h3>
                      <p className="text-gray-600">
                        Monday - Friday: 8:00 AM - 5:00 PM<br />
                        Saturday: 9:00 AM - 3:00 PM<br />
                        Sunday: Closed
                      </p>
                    </div>
                  </div>
                </div>
                
                <div className="mt-8 border-t border-gray-200 pt-8">
                  <h3 className="font-medium text-gray-900 mb-4">Visit Our Showroom</h3>
                  <p className="text-gray-600 mb-4">
                    Stop by our showroom to see our structures in person and speak with our design experts.
                  </p>
                  <div className="aspect-w-16 aspect-h-9 rounded-lg overflow-hidden">
                    <iframe
                      src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3064.1936976527766!2d-75.9346837!3d39.9582799!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c65d8c28f51f6f%3A0x3c2c2c2c2c2c2c2c!2s3341%20W%20Lincoln%20Hwy%2C%20Parkesburg%2C%20PA%2019365!5e0!3m2!1sen!2sus!4v1696345871150!5m2!1sen!2sus"
                      width="100%"
                      height="300"
                      style={{ border: 0 }}
                      allowFullScreen
                      loading="lazy"
                      referrerPolicy="no-referrer-when-downgrade"
                      title="Map to White Pine Structures"
                    ></iframe>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Contact Form */}
            <div className="lg:col-span-2">
              <div className="bg-white p-8 rounded-2xl shadow-sm">
                {!formSubmitted ? (
                  <>
                    <h2 className="text-2xl font-semibold text-gray-900 mb-6">Send Us a Message</h2>
                    <form onSubmit={handleSubmit} className="space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                          <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                            Your Name *
                          </label>
                          <input
                            type="text"
                            id="name"
                            name="name"
                            value={formData.name}
                            onChange={handleChange}
                            className={`w-full border ${errors.name ? 'border-red-500' : 'border-gray-300'} rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-[#978E5F] focus:border-transparent transition-colors`}
                            placeholder="John Smith"
                          />
                          {errors.name && (
                            <p className="mt-1 text-sm text-red-500 flex items-center">
                              <AlertCircle className="h-4 w-4 mr-1" />
                              {errors.name}
                            </p>
                          )}
                        </div>
                        
                        <div>
                          <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                            Email Address *
                          </label>
                          <input
                            type="email"
                            id="email"
                            name="email"
                            value={formData.email}
                            onChange={handleChange}
                            className={`w-full border ${errors.email ? 'border-red-500' : 'border-gray-300'} rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-[#978E5F] focus:border-transparent transition-colors`}
                            placeholder="john@example.com"
                          />
                          {errors.email && (
                            <p className="mt-1 text-sm text-red-500 flex items-center">
                              <AlertCircle className="h-4 w-4 mr-1" />
                              {errors.email}
                            </p>
                          )}
                        </div>
                        
                        <div>
                          <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
                            Phone Number *
                          </label>
                          <input
                            type="tel"
                            id="phone"
                            name="phone"
                            value={formData.phone}
                            onChange={handleChange}
                            className={`w-full border ${errors.phone ? 'border-red-500' : 'border-gray-300'} rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-[#978E5F] focus:border-transparent transition-colors`}
                            placeholder="(123) 456-7890"
                          />
                          {errors.phone && (
                            <p className="mt-1 text-sm text-red-500 flex items-center">
                              <AlertCircle className="h-4 w-4 mr-1" />
                              {errors.phone}
                            </p>
                          )}
                        </div>
                        
                        <div>
                          <label htmlFor="inquiryType" className="block text-sm font-medium text-gray-700 mb-1">
                            Inquiry Type
                          </label>
                          <select
                            id="inquiryType"
                            name="inquiryType"
                            value={formData.inquiryType}
                            onChange={handleChange}
                            className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-[#978E5F] focus:border-transparent transition-colors"
                          >
                            <option value="general">General Inquiry</option>
                            <option value="custom">Custom Structure</option>
                            <option value="stock">Stock Structure</option>
                            <option value="quote">Request Quote</option>
                            <option value="other">Other</option>
                          </select>
                        </div>
                      </div>
                      
                      <div>
                        <label htmlFor="subject" className="block text-sm font-medium text-gray-700 mb-1">
                          Subject
                        </label>
                        <input
                          type="text"
                          id="subject"
                          name="subject"
                          value={formData.subject}
                          onChange={handleChange}
                          className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-[#978E5F] focus:border-transparent transition-colors"
                          placeholder="What can we help you with?"
                        />
                      </div>
                      
                      <div>
                        <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-1">
                          Message *
                        </label>
                        <textarea
                          id="message"
                          name="message"
                          rows={6}
                          value={formData.message}
                          onChange={handleChange}
                          className={`w-full border ${errors.message ? 'border-red-500' : 'border-gray-300'} rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-[#978E5F] focus:border-transparent transition-colors`}
                          placeholder="Please provide any additional details or questions you have..."
                        />
                        {errors.message && (
                          <p className="mt-1 text-sm text-red-500 flex items-center">
                            <AlertCircle className="h-4 w-4 mr-1" />
                            {errors.message}
                          </p>
                        )}
                      </div>
                      
                      <div>
                        <button
                          type="submit"
                          className="w-full bg-[#978E5F] text-white px-6 py-3 rounded-lg font-medium hover:bg-opacity-90 transition-colors flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed"
                          disabled={isSubmitting}
                        >
                          {isSubmitting ? (
                            <>
                              <Loader2 className="animate-spin mr-2 h-5 w-5" />
                              Sending...
                            </>
                          ) : (
                            'Send Message'
                          )}
                        </button>
                      </div>
                    </form>
                  </>
                ) : (
                  <div className="text-center py-12">
                    <div className="flex items-center justify-center mb-6">
                      <div className="bg-green-100 p-3 rounded-full">
                        <CheckCircle className="h-12 w-12 text-green-500" />
                      </div>
                    </div>
                    <h2 className="text-2xl font-semibold text-gray-900 mb-4">Message Sent Successfully!</h2>
                    <p className="text-gray-600 mb-6">
                      Thank you for contacting White Pine Structures. We've received your message and will get back to you within 1-2 business days.
                    </p>
                    <button
                      onClick={() => setFormSubmitted(false)}
                      className="bg-[#978E5F] text-white px-6 py-3 rounded-lg font-medium hover:bg-opacity-90 transition-colors"
                    >
                      Send Another Message
                    </button>
                  </div>
                )}
              </div>
              
              <div className="mt-8 bg-[#978E5F] bg-opacity-10 p-8 rounded-2xl">
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Frequently Asked Questions</h3>
                <div className="space-y-4">
                  <div>
                    <h4 className="font-medium text-gray-900 mb-1">What areas do you serve?</h4>
                    <p className="text-gray-600">
                      We serve customers throughout Pennsylvania, with delivery available to most locations in the state.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-900 mb-1">How long does it take to build a custom structure?</h4>
                    <p className="text-gray-600">
                      Build times vary based on the complexity of the project, but most custom structures are completed within 2-6 weeks from order confirmation.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-900 mb-1">Do you offer financing options?</h4>
                    <p className="text-gray-600">
                      Yes, we partner with several financing companies to offer flexible payment options for your structure.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-900 mb-1">Can I visit your showroom to see structures in person?</h4>
                    <p className="text-gray-600">
                      Absolutely! We encourage customers to visit our showroom where we have various models on display.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;