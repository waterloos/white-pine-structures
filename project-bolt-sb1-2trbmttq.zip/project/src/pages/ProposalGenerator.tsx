import React, { useEffect, useState } from 'react';
import { Structure, ProposalItem } from '../types';
import { allStructures, getStructureById } from '../data/structures';
import { calculateTotalPrice, generateProposalSummary } from '../utils/proposalCalculator';
import { Check, Loader2, Copy, Mail } from 'lucide-react';

const ProposalGenerator: React.FC = () => {
  const [selectedStructureId, setSelectedStructureId] = useState<string>('');
  const [selectedStructure, setSelectedStructure] = useState<Structure | null>(null);
  const [selectedOptions, setSelectedOptions] = useState<{ [key: string]: string | boolean | number }>({});
  const [customerInfo, setCustomerInfo] = useState({
    name: '',
    email: '',
    phone: '',
    address: '',
    comments: '',
  });
  const [totalPrice, setTotalPrice] = useState<number>(0);
  const [proposalGenerated, setProposalGenerated] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [proposalSummary, setProposalSummary] = useState<string>('');
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    window.scrollTo(0, 0);
    document.title = 'Custom Proposal Generator - White Pine Structures';
  }, []);

  useEffect(() => {
    if (selectedStructureId) {
      const structure = getStructureById(selectedStructureId);
      setSelectedStructure(structure || null);
      
      // Reset selected options when structure changes
      setSelectedOptions({});
      setTotalPrice(structure?.basePrice || 0);
    } else {
      setSelectedStructure(null);
      setSelectedOptions({});
      setTotalPrice(0);
    }
  }, [selectedStructureId]);

  useEffect(() => {
    if (selectedStructure) {
      const newTotalPrice = calculateTotalPrice(selectedStructure, selectedOptions);
      setTotalPrice(newTotalPrice);
    }
  }, [selectedOptions, selectedStructure]);

  const handleOptionChange = (optionId: string, value: string | boolean | number) => {
    setSelectedOptions(prev => ({
      ...prev,
      [optionId]: value,
    }));
  };

  const handleCustomerInfoChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setCustomerInfo(prev => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Create proposal object
    const proposal: ProposalItem = {
      structureId: selectedStructureId,
      options: selectedOptions,
      basePrice: selectedStructure?.basePrice || 0,
      totalPrice: totalPrice,
    };
    
    // Generate proposal summary
    const summary = selectedStructure 
      ? generateProposalSummary(proposal, selectedStructure)
      : '';
    
    setProposalSummary(summary);
    
    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false);
      setProposalGenerated(true);
    }, 1500);
  };

  const handleCopyProposal = () => {
    navigator.clipboard.writeText(proposalSummary).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 3000);
    });
  };

  const handleReset = () => {
    setSelectedStructureId('');
    setSelectedStructure(null);
    setSelectedOptions({});
    setCustomerInfo({
      name: '',
      email: '',
      phone: '',
      address: '',
      comments: '',
    });
    setTotalPrice(0);
    setProposalGenerated(false);
    setProposalSummary('');
  };

  return (
    <div>
      {/* Hero Section */}
      <div className="relative py-24 bg-gray-900">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.pexels.com/photos/1292115/pexels-photo-1292115.jpeg" 
            alt="Custom Proposal Generator" 
            className="w-full h-full object-cover opacity-30"
          />
        </div>
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="max-w-3xl">
            <h1 className="text-4xl sm:text-5xl font-serif font-bold mb-6 text-white">Custom Proposal Generator</h1>
            <p className="text-xl text-gray-200">
              Create a custom proposal for your ideal structure. Select your options and get real-time pricing estimates.
            </p>
          </div>
        </div>
      </div>

      <div className="py-16 bg-gray-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          {!proposalGenerated ? (
            <div className="max-w-4xl mx-auto bg-white rounded-lg shadow-md p-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-6">Build Your Custom Structure</h2>
              
              <form onSubmit={handleSubmit}>
                {/* Step 1: Select Structure Type */}
                <div className="mb-8">
                  <h3 className="text-lg font-medium text-gray-900 mb-4">Step 1: Select Structure Type</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label htmlFor="structure-type" className="block text-sm font-medium text-gray-700 mb-1">
                        Structure Type
                      </label>
                      <select
                        id="structure-type"
                        className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#978E5F] focus:border-transparent"
                        value={selectedStructureId}
                        onChange={(e) => setSelectedStructureId(e.target.value)}
                        required
                      >
                        <option value="">Select a structure...</option>
                        <optgroup label="Sheds">
                          {allStructures.filter(s => s.type === 'shed').map(structure => (
                            <option key={structure.id} value={structure.id}>{structure.name}</option>
                          ))}
                        </optgroup>
                        <optgroup label="Garages">
                          {allStructures.filter(s => s.type === 'garage').map(structure => (
                            <option key={structure.id} value={structure.id}>{structure.name}</option>
                          ))}
                        </optgroup>
                        <optgroup label="Other Structures">
                          {allStructures.filter(s => s.type === 'other').map(structure => (
                            <option key={structure.id} value={structure.id}>{structure.name}</option>
                          ))}
                        </optgroup>
                      </select>
                    </div>
                    
                    {selectedStructure && (
                      <div className="bg-gray-50 p-4 rounded">
                        <p className="font-medium text-gray-900">{selectedStructure.name}</p>
                        <p className="text-sm text-gray-600 mt-1">{selectedStructure.description}</p>
                        <p className="mt-2 text-sm font-medium">Base Price: ${selectedStructure.basePrice.toLocaleString()}</p>
                      </div>
                    )}
                  </div>
                </div>
                
                {/* Step 2: Customize Options */}
                {selectedStructure && (
                  <div className="mb-8">
                    <h3 className="text-lg font-medium text-gray-900 mb-4">Step 2: Customize Options</h3>
                    <div className="space-y-4">
                      {selectedStructure.options.map(option => (
                        <div key={option.id} className="p-4 border border-gray-200 rounded">
                          <div className="flex justify-between items-start">
                            <div>
                              <label htmlFor={option.id} className="font-medium text-gray-900">{option.name}</label>
                              <p className="text-sm text-gray-600">{option.description}</p>
                            </div>
                            <div className="text-right">
                              <span className="font-medium text-[#978E5F]">
                                +${typeof option.priceModifier === 'function' 
                                  ? option.priceModifier(selectedStructure.basePrice).toLocaleString() 
                                  : option.priceModifier.toLocaleString()}
                              </span>
                            </div>
                          </div>
                          <div className="mt-2">
                            <input
                              type="checkbox"
                              id={option.id}
                              checked={!!selectedOptions[option.id]}
                              onChange={(e) => handleOptionChange(option.id, e.target.checked)}
                              className="rounded text-[#978E5F] focus:ring-[#978E5F]"
                            />
                            <label htmlFor={option.id} className="ml-2 text-sm text-gray-700">
                              Add this option
                            </label>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                
                {/* Step 3: Your Information */}
                {selectedStructure && (
                  <div className="mb-8">
                    <h3 className="text-lg font-medium text-gray-900 mb-4">Step 3: Your Information</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                          Full Name
                        </label>
                        <input
                          type="text"
                          id="name"
                          name="name"
                          value={customerInfo.name}
                          onChange={handleCustomerInfoChange}
                          className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#978E5F] focus:border-transparent"
                          required
                        />
                      </div>
                      <div>
                        <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                          Email Address
                        </label>
                        <input
                          type="email"
                          id="email"
                          name="email"
                          value={customerInfo.email}
                          onChange={handleCustomerInfoChange}
                          className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#978E5F] focus:border-transparent"
                          required
                        />
                      </div>
                      <div>
                        <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
                          Phone Number
                        </label>
                        <input
                          type="tel"
                          id="phone"
                          name="phone"
                          value={customerInfo.phone}
                          onChange={handleCustomerInfoChange}
                          className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#978E5F] focus:border-transparent"
                          required
                        />
                      </div>
                      <div>
                        <label htmlFor="address" className="block text-sm font-medium text-gray-700 mb-1">
                          Delivery Address
                        </label>
                        <input
                          type="text"
                          id="address"
                          name="address"
                          value={customerInfo.address}
                          onChange={handleCustomerInfoChange}
                          className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#978E5F] focus:border-transparent"
                          required
                        />
                      </div>
                      <div className="md:col-span-2">
                        <label htmlFor="comments" className="block text-sm font-medium text-gray-700 mb-1">
                          Additional Comments or Requirements
                        </label>
                        <textarea
                          id="comments"
                          name="comments"
                          rows={4}
                          value={customerInfo.comments}
                          onChange={handleCustomerInfoChange}
                          className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#978E5F] focus:border-transparent"
                        />
                      </div>
                    </div>
                  </div>
                )}
                
                {/* Summary and Submit */}
                {selectedStructure && (
                  <div>
                    <div className="bg-gray-50 p-6 rounded-lg mb-6">
                      <h3 className="text-lg font-medium text-gray-900 mb-4">Proposal Summary</h3>
                      <div className="flex justify-between mb-2">
                        <span className="text-gray-600">Base Price:</span>
                        <span className="font-medium">${selectedStructure.basePrice.toLocaleString()}</span>
                      </div>
                      
                      {Object.entries(selectedOptions).map(([optionId, value]) => {
                        if (value) {
                          const option = selectedStructure.options.find(opt => opt.id === optionId);
                          if (option) {
                            const cost = typeof option.priceModifier === 'function' 
                              ? option.priceModifier(selectedStructure.basePrice) 
                              : option.priceModifier;
                            return (
                              <div key={optionId} className="flex justify-between mb-2">
                                <span className="text-gray-600">{option.name}:</span>
                                <span className="font-medium">+${cost.toLocaleString()}</span>
                              </div>
                            );
                          }
                        }
                        return null;
                      })}
                      
                      <div className="border-t border-gray-300 mt-4 pt-4 flex justify-between">
                        <span className="text-lg font-medium">Total Price:</span>
                        <span className="text-lg font-bold text-[#978E5F]">${totalPrice.toLocaleString()}</span>
                      </div>
                    </div>
                    
                    <div className="flex justify-end">
                      <button
                        type="submit"
                        className="bg-[#978E5F] text-white px-6 py-3 rounded font-medium hover:bg-opacity-90 transition-colors flex items-center"
                        disabled={isSubmitting}
                      >
                        {isSubmitting ? (
                          <>
                            <Loader2 className="animate-spin mr-2 h-5 w-5" />
                            Generating Proposal...
                          </>
                        ) : (
                          'Generate Proposal'
                        )}
                      </button>
                    </div>
                  </div>
                )}
              </form>
            </div>
          ) : (
            <div className="max-w-4xl mx-auto bg-white rounded-lg shadow-md p-8">
              <div className="flex items-center justify-center mb-6">
                <div className="bg-green-100 p-3 rounded-full">
                  <Check className="h-10 w-10 text-green-500" />
                </div>
              </div>
              
              <h2 className="text-2xl font-semibold text-gray-900 text-center mb-6">
                Your Custom Proposal is Ready!
              </h2>
              
              <p className="text-center text-gray-600 mb-8">
                We've created a custom proposal based on your selections. A copy has been sent to your email.
              </p>
              
              <div className="bg-gray-50 p-6 rounded-lg mb-6 relative">
                <h3 className="text-lg font-medium text-gray-900 mb-4">Proposal Details</h3>
                <pre className="whitespace-pre-wrap font-mono text-sm text-gray-700 bg-gray-100 p-4 rounded">
                  {proposalSummary}
                </pre>
                <button
                  onClick={handleCopyProposal}
                  className="absolute top-4 right-4 bg-white p-2 rounded-md text-gray-500 hover:text-[#978E5F] hover:bg-gray-100 transition-colors"
                  title="Copy to clipboard"
                >
                  {copied ? <Check className="h-5 w-5" /> : <Copy className="h-5 w-5" />}
                </button>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                <div className="bg-blue-50 p-6 rounded-lg">
                  <h3 className="text-lg font-medium text-blue-900 mb-4">What Happens Next?</h3>
                  <ol className="list-decimal list-inside space-y-2 text-blue-800">
                    <li>Our team will review your proposal</li>
                    <li>We'll contact you within 1-2 business days</li>
                    <li>We'll schedule a consultation to finalize details</li>
                    <li>Once approved, construction will begin</li>
                  </ol>
                </div>
                
                <div className="bg-orange-50 p-6 rounded-lg">
                  <h3 className="text-lg font-medium text-orange-900 mb-4">Have Questions?</h3>
                  <p className="text-orange-800 mb-4">
                    If you have any questions about your proposal or would like to discuss modifications, please don't hesitate to contact us.
                  </p>
                  <a 
                    href="mailto:info@whitepinestructures.com" 
                    className="inline-flex items-center text-orange-700 font-medium hover:underline"
                  >
                    <Mail className="mr-2 h-5 w-5" />
                    info@whitepinestructures.com
                  </a>
                </div>
              </div>
              
              <div className="flex justify-center">
                <button
                  onClick={handleReset}
                  className="bg-[#978E5F] text-white px-6 py-3 rounded font-medium hover:bg-opacity-90 transition-colors"
                >
                  Create Another Proposal
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ProposalGenerator;