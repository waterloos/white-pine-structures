import React, { useEffect } from 'react';
import { MapPin, Truck, Clock, AlertTriangle } from 'lucide-react';
import ButtonLink from '../../components/common/ButtonLink';

const DeliveryAreas: React.FC = () => {
  useEffect(() => {
    window.scrollTo(0, 0);
    document.title = 'Delivery Areas - White Pine Structures';
  }, []);

  return (
    <div className="min-h-screen bg-gray-50 pt-32 pb-16">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-lg shadow-md p-8 mb-8">
            <div className="flex items-center mb-6">
              <MapPin className="h-8 w-8 text-[#978E5F] mr-3" />
              <h1 className="text-3xl font-serif font-bold text-gray-900">Service Areas</h1>
            </div>
            
            <p className="text-lg text-gray-600 mb-8">
              White Pine Structures proudly serves customers throughout Pennsylvania and surrounding states. Our delivery service ensures your structure arrives safely and is properly installed at your location.
            </p>

            <div className="space-y-8">
              <section>
                <h2 className="text-2xl font-semibold text-gray-900 mb-4">Primary Service Areas</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="bg-gray-50 p-6 rounded-lg">
                    <h3 className="font-semibold text-gray-900 mb-3">Pennsylvania Counties</h3>
                    <div className="grid grid-cols-2 gap-2">
                      <div className="space-y-2 text-gray-600">
                        <p>• Chester County</p>
                        <p>• Lancaster County</p>
                        <p>• Delaware County</p>
                        <p>• Montgomery County</p>
                      </div>
                      <div className="space-y-2 text-gray-600">
                        <p>• Berks County</p>
                        <p>• York County</p>
                        <p>• Lebanon County</p>
                        <p>• Bucks County</p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="bg-gray-50 p-6 rounded-lg">
                    <h3 className="font-semibold text-gray-900 mb-3">Standard Delivery Area</h3>
                    <ul className="space-y-2 text-gray-600">
                      <li>• Within 50 miles of Parkesburg, PA</li>
                      <li>• Standard delivery fees apply</li>
                      <li>• Most areas accessible same week</li>
                      <li>• Full installation service included</li>
                    </ul>
                  </div>
                </div>
              </section>

              <section>
                <h2 className="text-2xl font-semibold text-gray-900 mb-4">Extended Service Areas</h2>
                <div className="space-y-4">
                  <div className="bg-gray-50 p-6 rounded-lg">
                    <h3 className="font-semibold text-gray-900 mb-3">New Jersey</h3>
                    <p className="text-gray-600 mb-3">
                      South Jersey regions including:
                    </p>
                    <ul className="space-y-2 text-gray-600">
                      <li>• Camden County</li>
                      <li>• Burlington County</li>
                      <li>• Gloucester County</li>
                      <li>• Additional fees may apply</li>
                    </ul>
                  </div>

                  <div className="bg-gray-50 p-6 rounded-lg">
                    <h3 className="font-semibold text-gray-900 mb-3">Delaware</h3>
                    <p className="text-gray-600 mb-3">
                      Northern Delaware areas including:
                    </p>
                    <ul className="space-y-2 text-gray-600">
                      <li>• New Castle County</li>
                      <li>• Extended delivery scheduling</li>
                      <li>• Additional fees may apply</li>
                    </ul>
                  </div>

                  <div className="bg-gray-50 p-6 rounded-lg">
                    <h3 className="font-semibold text-gray-900 mb-3">Maryland</h3>
                    <p className="text-gray-600 mb-3">
                      Northern Maryland regions including:
                    </p>
                    <ul className="space-y-2 text-gray-600">
                      <li>• Cecil County</li>
                      <li>• Harford County</li>
                      <li>• Extended delivery scheduling</li>
                      <li>• Additional fees may apply</li>
                    </ul>
                  </div>
                </div>
              </section>

              <section>
                <h2 className="text-2xl font-semibold text-gray-900 mb-4">Delivery Information</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="bg-gray-50 p-6 rounded-lg">
                    <div className="flex items-center mb-3">
                      <Truck className="h-6 w-6 text-[#978E5F] mr-2" />
                      <h3 className="font-semibold text-gray-900">Delivery Process</h3>
                    </div>
                    <ul className="space-y-2 text-gray-600">
                      <li>• Site assessment before delivery</li>
                      <li>• Professional delivery team</li>
                      <li>• Specialized equipment used</li>
                      <li>• Careful placement and leveling</li>
                    </ul>
                  </div>

                  <div className="bg-gray-50 p-6 rounded-lg">
                    <div className="flex items-center mb-3">
                      <Clock className="h-6 w-6 text-[#978E5F] mr-2" />
                      <h3 className="font-semibold text-gray-900">Timing</h3>
                    </div>
                    <ul className="space-y-2 text-gray-600">
                      <li>• 2-3 week standard delivery</li>
                      <li>• Flexible scheduling available</li>
                      <li>• Weather considerations</li>
                      <li>• Installation included</li>
                    </ul>
                  </div>
                </div>
              </section>

              <section>
                <h2 className="text-2xl font-semibold text-gray-900 mb-4">Important Notes</h2>
                <div className="bg-yellow-50 p-6 rounded-lg mb-6">
                  <div className="flex items-start">
                    <AlertTriangle className="h-6 w-6 text-yellow-600 flex-shrink-0 mt-1 mr-3" />
                    <div>
                      <h3 className="font-semibold text-yellow-900 mb-2">Please Note</h3>
                      <ul className="space-y-2 text-yellow-800">
                        <li>• Site must be properly prepared before delivery</li>
                        <li>• Clear access path required (14' wide x 14' high)</li>
                        <li>• Additional fees may apply for difficult access</li>
                        <li>• Delivery dates subject to weather conditions</li>
                        <li>• Site assessment required for all deliveries</li>
                      </ul>
                    </div>
                  </div>
                </div>
                
                <div className="flex flex-col sm:flex-row gap-4">
                  <ButtonLink 
                    to="/site-preparation" 
                    variant="primary"
                    className="text-center"
                  >
                    Site Preparation Guide
                  </ButtonLink>
                  <ButtonLink 
                    to="/contact" 
                    variant="outline"
                    className="text-center"
                  >
                    Contact Us
                  </ButtonLink>
                </div>
              </section>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DeliveryAreas;