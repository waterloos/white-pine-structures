import React from 'react';
import { FileText } from 'lucide-react';

const BuildingPermits = () => {
  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <FileText className="mx-auto h-12 w-12 text-blue-600 mb-4" />
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Building Permits Guide</h1>
          <p className="text-lg text-gray-600">Understanding the permit requirements for your structure</p>
        </div>

        <div className="bg-white shadow-lg rounded-lg overflow-hidden">
          <div className="p-8">
            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">Why Building Permits Matter</h2>
              <p className="text-gray-600 mb-4">
                Building permits ensure that your structure meets local safety standards and building codes. They protect both you and your investment by guaranteeing that construction meets minimum safety requirements.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">When You Need a Permit</h2>
              <ul className="list-disc list-inside text-gray-600 space-y-2">
                <li>New structure construction</li>
                <li>Major renovations or additions</li>
                <li>Electrical or plumbing modifications</li>
                <li>Changes to load-bearing walls</li>
                <li>Foundation work</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">The Permit Process</h2>
              <ol className="list-decimal list-inside text-gray-600 space-y-4">
                <li>Submit detailed plans and specifications</li>
                <li>Pay required fees</li>
                <li>Wait for plan review and approval</li>
                <li>Schedule necessary inspections</li>
                <li>Obtain final approval</li>
              </ol>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">Our Support</h2>
              <p className="text-gray-600 mb-4">
                We assist our customers throughout the permit process by:
              </p>
              <ul className="list-disc list-inside text-gray-600 space-y-2">
                <li>Providing necessary technical drawings</li>
                <li>Offering guidance on local requirements</li>
                <li>Helping with documentation preparation</li>
                <li>Supporting during inspections</li>
              </ul>
            </section>

            <div className="mt-8 bg-blue-50 p-6 rounded-lg">
              <h3 className="text-xl font-semibold text-blue-900 mb-2">Need Help?</h3>
              <p className="text-blue-700">
                Contact our permit specialists for personalized assistance with your building permit requirements.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BuildingPermits;