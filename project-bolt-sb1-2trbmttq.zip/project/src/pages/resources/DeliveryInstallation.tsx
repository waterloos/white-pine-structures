import React, { useEffect } from 'react';
import { Truck, PenTool as Tools, MapPin, Clock } from 'lucide-react';
import ButtonLink from '../../components/common/ButtonLink';

const DeliveryInstallation: React.FC = () => {
  useEffect(() => {
    window.scrollTo(0, 0);
    document.title = 'Delivery & Installation - White Pine Structures';
  }, []);

  return (
    <div className="min-h-screen bg-gray-50 pt-32 pb-16">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-lg shadow-md p-8 mb-8">
            <div className="flex items-center mb-6">
              <Truck className="h-8 w-8 text-[#978E5F] mr-3" />
              <h1 className="text-3xl font-serif font-bold text-gray-900">Delivery & Installation</h1>
            </div>
            
            <p className="text-lg text-gray-600 mb-8">
              We provide professional delivery and installation services to ensure your structure is properly placed and ready for use.
            </p>

            <div className="space-y-8">
              <section>
                <h2 className="text-2xl font-semibold text-gray-900 mb-4">Delivery Process</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="bg-gray-50 p-6 rounded-lg">
                    <Clock className="h-6 w-6 text-[#978E5F] mb-3" />
                    <h3 className="font-semibold text-gray-900 mb-2">Scheduling</h3>
                    <p className="text-gray-600">
                      We'll work with you to schedule a delivery time that's convenient. Most deliveries are completed within 2-3 weeks of order confirmation.
                    </p>
                  </div>
                  
                  <div className="bg-gray-50 p-6 rounded-lg">
                    <MapPin className="h-6 w-6 text-[#978E5F] mb-3" />
                    <h3 className="font-semibold text-gray-900 mb-2">Site Access</h3>
                    <p className="text-gray-600">
                      Our delivery team will assess site access requirements and coordinate with you to ensure smooth delivery.
                    </p>
                  </div>
                </div>
              </section>

              <section>
                <h2 className="text-2xl font-semibold text-gray-900 mb-4">Installation Services</h2>
                <div className="bg-gray-50 p-6 rounded-lg">
                  <div className="flex items-start mb-6">
                    <Tools className="h-6 w-6 text-[#978E5F] flex-shrink-0 mt-1 mr-3" />
                    <div>
                      <h3 className="font-semibold text-gray-900 mb-2">Professional Installation</h3>
                      <p className="text-gray-600">
                        Our experienced installation team ensures your structure is properly leveled, secured, and ready for use. Installation typically includes:
                      </p>
                    </div>
                  </div>
                  <ul className="space-y-3 text-gray-600 mb-6">
                    <li className="flex items-center">
                      <span className="h-2 w-2 bg-[#978E5F] rounded-full mr-2"></span>
                      Final placement and leveling
                    </li>
                    <li className="flex items-center">
                      <span className="h-2 w-2 bg-[#978E5F] rounded-full mr-2"></span>
                      Securing the structure
                    </li>
                    <li className="flex items-center">
                      <span className="h-2 w-2 bg-[#978E5F] rounded-full mr-2"></span>
                      Door and window adjustment
                    </li>
                    <li className="flex items-center">
                      <span className="h-2 w-2 bg-[#978E5F] rounded-full mr-2"></span>
                      Final inspection and walkthrough
                    </li>
                  </ul>
                </div>
              </section>

              <section>
                <h2 className="text-2xl font-semibold text-gray-900 mb-4">What to Expect</h2>
                <div className="prose max-w-none text-gray-600">
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">Before Delivery</h3>
                  <ul className="mb-6">
                    <li>Ensure site is properly prepared and level</li>
                    <li>Clear access path for delivery equipment</li>
                    <li>Remove any obstacles or overhead restrictions</li>
                    <li>Mark underground utilities</li>
                  </ul>

                  <h3 className="text-lg font-semibold text-gray-900 mb-2">During Delivery</h3>
                  <ul className="mb-6">
                    <li>Our team will contact you when en route</li>
                    <li>Be available to confirm final placement</li>
                    <li>Allow 2-4 hours for complete installation</li>
                    <li>Final inspection and documentation</li>
                  </ul>
                </div>
              </section>

              <section>
                <h2 className="text-2xl font-semibold text-gray-900 mb-4">Service Area & Fees</h2>
                <div className="bg-gray-50 p-6 rounded-lg mb-6">
                  <p className="text-gray-600 mb-4">
                    We service the following areas with standard delivery fees:
                  </p>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                    <div>
                      <h3 className="font-semibold text-gray-900 mb-2">Primary Service Area</h3>
                      <ul className="space-y-1 text-gray-600">
                        <li>Chester County</li>
                        <li>Lancaster County</li>
                        <li>Delaware County</li>
                        <li>Montgomery County</li>
                      </ul>
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900 mb-2">Extended Service Area</h3>
                      <ul className="space-y-1 text-gray-600">
                        <li>Berks County</li>
                        <li>York County</li>
                        <li>Northern Maryland</li>
                        <li>Delaware</li>
                      </ul>
                    </div>
                  </div>
                  <p className="text-sm text-gray-500">
                    Additional fees may apply for extended service areas or special delivery requirements.
                  </p>
                </div>
                
                <div className="flex flex-col sm:flex-row gap-4">
                  <ButtonLink 
                    to="/site-preparation" 
                    variant="primary"
                    className="text-center"
                  >
                    Site Preparation Guide
                  </ButtonLink>
                  <ButtonLink 
                    to="/contact" 
                    variant="outline"
                    className="text-center"
                  >
                    Contact Us
                  </ButtonLink>
                </div>
              </section>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DeliveryInstallation;