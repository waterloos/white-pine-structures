import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Search, Filter, Calendar, Clock, ArrowRight } from 'lucide-react';
import { format } from 'date-fns';

interface BlogPost {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  author: string;
  date: string;
  readTime: number;
  category: string;
  tags: string[];
  imageUrl: string;
  slug: string;
}

const blogPosts: BlogPost[] = [
  {
    id: '1',
    title: 'How to Choose the Perfect Shed Size for Your Needs',
    excerpt: 'A comprehensive guide to determining the right shed size based on your storage needs, property size, and intended use.',
    content: '',
    author: 'John White',
    date: '2024-03-15',
    readTime: 5,
    category: 'Planning',
    tags: ['sheds', 'planning', 'sizing'],
    imageUrl: 'https://images.pexels.com/photos/259588/pexels-photo-259588.jpeg',
    slug: 'choosing-perfect-shed-size'
  },
  {
    id: '2',
    title: 'Essential Spring Maintenance Tips for Your Outdoor Structure',
    excerpt: 'Keep your shed or garage in top condition with these important spring maintenance tasks and tips.',
    content: '',
    author: 'Sarah Johnson',
    date: '2024-03-10',
    readTime: 4,
    category: 'Maintenance',
    tags: ['maintenance', 'seasonal', 'tips'],
    imageUrl: 'https://images.pexels.com/photos/273843/pexels-photo-273843.jpeg',
    slug: 'spring-maintenance-tips'
  },
  {
    id: '3',
    title: 'Converting Your Shed into a Home Office',
    excerpt: 'Step-by-step guide to transforming your backyard shed into a productive and comfortable home office space.',
    content: '',
    author: 'Mike Thompson',
    date: '2024-03-05',
    readTime: 6,
    category: 'DIY',
    tags: ['conversion', 'home-office', 'diy'],
    imageUrl: 'https://images.pexels.com/photos/1094767/pexels-photo-1094767.jpeg',
    slug: 'shed-to-home-office'
  },
  {
    id: '4',
    title: 'Understanding Building Permits for Outdoor Structures',
    excerpt: 'Navigate the permit process with confidence using this comprehensive guide to building permits and regulations.',
    content: '',
    author: 'John White',
    date: '2024-02-28',
    readTime: 7,
    category: 'Planning',
    tags: ['permits', 'regulations', 'planning'],
    imageUrl: 'https://images.pexels.com/photos/280222/pexels-photo-280222.jpeg',
    slug: 'building-permit-guide'
  },
  {
    id: '5',
    title: 'Maximizing Storage Space in Your Garage',
    excerpt: 'Creative solutions and organization tips to make the most of your garage storage space.',
    content: '',
    author: 'Sarah Johnson',
    date: '2024-02-20',
    readTime: 5,
    category: 'Organization',
    tags: ['storage', 'organization', 'garages'],
    imageUrl: 'https://images.pexels.com/photos/1546168/pexels-photo-1546168.jpeg',
    slug: 'maximize-garage-storage'
  }
];

const Blog: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [filteredPosts, setFilteredPosts] = useState(blogPosts);

  useEffect(() => {
    window.scrollTo(0, 0);
    document.title = 'Blog - White Pine Structures';
  }, []);

  useEffect(() => {
    const filtered = blogPosts.filter(post => {
      const matchesSearch = post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          post.excerpt.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          post.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
      
      const matchesCategory = selectedCategory === 'all' || post.category.toLowerCase() === selectedCategory.toLowerCase();
      
      return matchesSearch && matchesCategory;
    });
    
    setFilteredPosts(filtered);
  }, [searchTerm, selectedCategory]);

  const categories = ['all', ...new Set(blogPosts.map(post => post.category))];

  return (
    <div className="min-h-screen bg-gray-50 pt-32 pb-16">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-4xl font-serif font-bold text-gray-900 mb-6">Blog & Resources</h1>
          
          {/* Search and Filter */}
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <div className="space-y-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                <input
                  type="text"
                  placeholder="Search articles..."
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#978E5F] focus:border-transparent"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              
              <div className="flex flex-wrap gap-2">
                {categories.map(category => (
                  <button
                    key={category}
                    onClick={() => setSelectedCategory(category)}
                    className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                      selectedCategory === category
                        ? 'bg-[#978E5F] text-white'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    {category.charAt(0).toUpperCase() + category.slice(1)}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Blog Posts */}
          <div className="space-y-8">
            {filteredPosts.map(post => (
              <article key={post.id} className="bg-white rounded-lg shadow-md overflow-hidden transform transition-all duration-300 hover:shadow-xl">
                <div className="md:flex">
                  <div className="md:flex-shrink-0">
                    <img
                      className="h-48 w-full md:w-48 object-cover"
                      src={post.imageUrl}
                      alt={post.title}
                    />
                  </div>
                  <div className="p-6">
                    <div className="flex items-center gap-4 text-sm text-gray-500 mb-2">
                      <span className="bg-[#978E5F] bg-opacity-10 text-[#978E5F] px-2 py-1 rounded">
                        {post.category}
                      </span>
                      <span className="flex items-center">
                        <Calendar className="h-4 w-4 mr-1" />
                        {format(new Date(post.date), 'MMM d, yyyy')}
                      </span>
                      <span className="flex items-center">
                        <Clock className="h-4 w-4 mr-1" />
                        {post.readTime} min read
                      </span>
                    </div>
                    
                    <Link 
                      to={`/blog/${post.slug}`}
                      className="block group"
                    >
                      <h2 className="text-xl font-semibold text-gray-900 mb-2 group-hover:text-[#978E5F] transition-colors">
                        {post.title}
                      </h2>
                    </Link>
                    
                    <p className="text-gray-600 mb-4">
                      {post.excerpt}
                    </p>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <span className="text-sm text-gray-500">By {post.author}</span>
                      </div>
                      <Link
                        to={`/blog/${post.slug}`}
                        className="inline-flex items-center text-[#978E5F] text-sm font-medium hover:underline group"
                      >
                        Read More
                        <ArrowRight className="ml-1 h-4 w-4 transition-transform group-hover:translate-x-1" />
                      </Link>
                    </div>
                  </div>
                </div>
              </article>
            ))}
          </div>

          {filteredPosts.length === 0 && (
            <div className="bg-white rounded-lg shadow-md p-8 text-center">
              <h3 className="text-xl font-semibold text-gray-900 mb-2">No articles found</h3>
              <p className="text-gray-600">
                Try adjusting your search terms or filters to find what you're looking for.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Blog;