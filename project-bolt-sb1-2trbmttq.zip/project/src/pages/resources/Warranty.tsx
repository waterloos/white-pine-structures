import React from 'react';
import { Shield } from 'lucide-react';

const Warranty = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center gap-4 mb-8">
          <Shield className="w-8 h-8 text-primary" />
          <h1 className="text-4xl font-bold text-gray-900">Warranty Information</h1>
        </div>

        <div className="prose max-w-none">
          <p className="text-lg text-gray-700 mb-6">
            We stand behind the quality of our structures with comprehensive warranty coverage to give you peace of mind with your investment.
          </p>

          <h2 className="text-2xl font-semibold text-gray-900 mt-8 mb-4">Structural Warranty</h2>
          <ul className="list-disc pl-6 space-y-2 text-gray-700">
            <li>Lifetime warranty on all structural components</li>
            <li>Coverage against defects in materials and workmanship</li>
            <li>Protection against structural failure due to normal use</li>
          </ul>

          <h2 className="text-2xl font-semibold text-gray-900 mt-8 mb-4">Finish Warranty</h2>
          <ul className="list-disc pl-6 space-y-2 text-gray-700">
            <li>20-year warranty on exterior finishes</li>
            <li>Protection against peeling, cracking, or blistering</li>
            <li>Coverage for color fading beyond normal weathering</li>
          </ul>

          <h2 className="text-2xl font-semibold text-gray-900 mt-8 mb-4">Hardware & Components</h2>
          <ul className="list-disc pl-6 space-y-2 text-gray-700">
            <li>5-year warranty on door hardware and mechanisms</li>
            <li>3-year warranty on window components</li>
            <li>1-year warranty on other accessories and additions</li>
          </ul>

          <div className="bg-gray-50 p-6 rounded-lg mt-8">
            <h3 className="text-xl font-semibold text-gray-900 mb-4">Warranty Claims Process</h3>
            <ol className="list-decimal pl-6 space-y-2 text-gray-700">
              <li>Contact our warranty department</li>
              <li>Provide your structure's serial number and purchase information</li>
              <li>Describe the issue in detail and provide photos if possible</li>
              <li>Our team will review your claim within 48 business hours</li>
              <li>If approved, repairs or replacements will be scheduled promptly</li>
            </ol>
          </div>

          <div className="bg-blue-50 p-6 rounded-lg mt-8">
            <h3 className="text-xl font-semibold text-blue-900 mb-4">Important Notes</h3>
            <ul className="list-disc pl-6 space-y-2 text-blue-800">
              <li>Warranty coverage begins on the date of installation completion</li>
              <li>Regular maintenance is required to maintain warranty validity</li>
              <li>Warranty is transferable to new owners within the coverage period</li>
              <li>Commercial use may have different warranty terms</li>
            </ul>
          </div>

          <div className="mt-8 p-6 border border-gray-200 rounded-lg">
            <h3 className="text-xl font-semibold text-gray-900 mb-4">Contact Warranty Support</h3>
            <p className="text-gray-700 mb-4">
              For warranty claims or questions, our support team is available Monday through Friday, 8:00 AM to 5:00 PM EST.
            </p>
            <div className="space-y-2 text-gray-700">
              <p>Phone: 1-800-WARRANTY</p>
              <p>Email: warranty@example.com</p>
              <p>Online: Submit a claim through our customer portal</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Warranty;