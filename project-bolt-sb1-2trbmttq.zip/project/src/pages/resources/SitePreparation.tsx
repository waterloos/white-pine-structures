import React, { useEffect } from 'react';
import { Ruler, Droplets, Hammer, AlertTriangle } from 'lucide-react';
import ButtonLink from '../../components/common/ButtonLink';

const SitePreparation: React.FC = () => {
  useEffect(() => {
    window.scrollTo(0, 0);
    document.title = 'Site Preparation Guide - White Pine Structures';
  }, []);

  return (
    <div className="min-h-screen bg-gray-50 pt-32 pb-16">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-lg shadow-md p-8 mb-8">
            <div className="flex items-center mb-6">
              <Ruler className="h-8 w-8 text-[#978E5F] mr-3" />
              <h1 className="text-3xl font-serif font-bold text-gray-900">Site Preparation Guide</h1>
            </div>
            
            <p className="text-lg text-gray-600 mb-8">
              Proper site preparation is crucial for the longevity and stability of your structure. Follow these guidelines to ensure your site is ready for delivery and installation.
            </p>

            <div className="space-y-8">
              <section>
                <h2 className="text-2xl font-semibold text-gray-900 mb-4">Site Requirements</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="bg-gray-50 p-6 rounded-lg">
                    <h3 className="font-semibold text-gray-900 mb-3">Minimum Clearance</h3>
                    <ul className="space-y-2 text-gray-600">
                      <li>• 2-3 feet beyond structure dimensions</li>
                      <li>• 14 feet overhead clearance</li>
                      <li>• Clear access path for delivery</li>
                      <li>• Room for equipment maneuvering</li>
                    </ul>
                  </div>
                  
                  <div className="bg-gray-50 p-6 rounded-lg">
                    <h3 className="font-semibold text-gray-900 mb-3">Ground Conditions</h3>
                    <ul className="space-y-2 text-gray-600">
                      <li>• Level surface (within 1 inch)</li>
                      <li>• Proper soil compaction</li>
                      <li>• Good drainage</li>
                      <li>• No standing water</li>
                    </ul>
                  </div>
                </div>
              </section>

              <section>
                <h2 className="text-2xl font-semibold text-gray-900 mb-4">Foundation Options</h2>
                <div className="space-y-4">
                  <div className="bg-gray-50 p-6 rounded-lg">
                    <h3 className="font-semibold text-gray-900 mb-3">Gravel Pad</h3>
                    <p className="text-gray-600 mb-3">
                      Recommended for most storage sheds and smaller structures:
                    </p>
                    <ul className="space-y-2 text-gray-600">
                      <li>• 4-6 inches of compacted gravel</li>
                      <li>• Proper gravel grade (#57 stone recommended)</li>
                      <li>• Weed barrier underneath</li>
                      <li>• Extends 6 inches beyond structure</li>
                    </ul>
                  </div>

                  <div className="bg-gray-50 p-6 rounded-lg">
                    <h3 className="font-semibold text-gray-900 mb-3">Concrete Pad</h3>
                    <p className="text-gray-600 mb-3">
                      Required for garages and recommended for larger structures:
                    </p>
                    <ul className="space-y-2 text-gray-600">
                      <li>• 4-6 inches thick reinforced concrete</li>
                      <li>• Proper rebar placement</li>
                      <li>• Moisture barrier</li>
                      <li>• Extends 2 inches beyond structure</li>
                    </ul>
                  </div>

                  <div className="bg-gray-50 p-6 rounded-lg">
                    <h3 className="font-semibold text-gray-900 mb-3">Block Foundation</h3>
                    <p className="text-gray-600 mb-3">
                      Alternative option for uneven terrain:
                    </p>
                    <ul className="space-y-2 text-gray-600">
                      <li>• Concrete blocks on level gravel</li>
                      <li>• Proper spacing and support</li>
                      <li>• Must be level within 1 inch</li>
                      <li>• Professional installation recommended</li>
                    </ul>
                  </div>
                </div>
              </section>

              <section>
                <h2 className="text-2xl font-semibold text-gray-900 mb-4">Drainage Considerations</h2>
                <div className="bg-gray-50 p-6 rounded-lg">
                  <div className="flex items-center mb-4">
                    <Droplets className="h-6 w-6 text-[#978E5F] mr-2" />
                    <h3 className="font-semibold text-gray-900">Proper Water Management</h3>
                  </div>
                  <div className="space-y-4">
                    <p className="text-gray-600">
                      Ensure proper drainage to protect your structure:
                    </p>
                    <ul className="space-y-2 text-gray-600">
                      <li>• Grade slopes away from structure (1 inch per foot)</li>
                      <li>• Install drainage systems if needed</li>
                      <li>• Consider gutters and downspouts</li>
                      <li>• Plan for water runoff management</li>
                    </ul>
                  </div>
                </div>
              </section>

              <section>
                <h2 className="text-2xl font-semibold text-gray-900 mb-4">Site Preparation Steps</h2>
                <div className="bg-gray-50 p-6 rounded-lg">
                  <div className="flex items-center mb-4">
                    <Hammer className="h-6 w-6 text-[#978E5F] mr-2" />
                    <h3 className="font-semibold text-gray-900">Step-by-Step Process</h3>
                  </div>
                  <ol className="space-y-4 text-gray-600">
                    <li>
                      <p className="font-medium">1. Site Selection</p>
                      <ul className="ml-6 mt-2 space-y-1">
                        <li>• Check local zoning requirements</li>
                        <li>• Mark utilities</li>
                        <li>• Assess drainage patterns</li>
                        <li>• Consider accessibility</li>
                      </ul>
                    </li>
                    <li>
                      <p className="font-medium">2. Site Clearing</p>
                      <ul className="ml-6 mt-2 space-y-1">
                        <li>• Remove vegetation</li>
                        <li>• Clear debris</li>
                        <li>• Remove topsoil</li>
                        <li>• Level rough grade</li>
                      </ul>
                    </li>
                    <li>
                      <p className="font-medium">3. Foundation Preparation</p>
                      <ul className="ml-6 mt-2 space-y-1">
                        <li>• Install weed barrier</li>
                        <li>• Add and compact gravel</li>
                        <li>• Level surface</li>
                        <li>• Check measurements</li>
                      </ul>
                    </li>
                    <li>
                      <p className="font-medium">4. Final Checks</p>
                      <ul className="ml-6 mt-2 space-y-1">
                        <li>• Verify levelness</li>
                        <li>• Check drainage</li>
                        <li>• Confirm measurements</li>
                        <li>• Document with photos</li>
                      </ul>
                    </li>
                  </ol>
                </div>
              </section>

              <section>
                <h2 className="text-2xl font-semibold text-gray-900 mb-4">Common Issues to Avoid</h2>
                <div className="bg-red-50 p-6 rounded-lg">
                  <div className="flex items-start mb-4">
                    <AlertTriangle className="h-6 w-6 text-red-500 flex-shrink-0 mt-1 mr-3" />
                    <p className="text-red-700 font-medium">
                      Watch out for these common site preparation mistakes:
                    </p>
                  </div>
                  <ul className="space-y-2 text-red-600">
                    <li>• Insufficient drainage planning</li>
                    <li>• Inadequate foundation support</li>
                    <li>• Poor soil compaction</li>
                    <li>• Incorrect measurements</li>
                    <li>• Overlooking utility locations</li>
                    <li>• Insufficient access clearance</li>
                  </ul>
                </div>
              </section>

              <section>
                <h2 className="text-2xl font-semibold text-gray-900 mb-4">Professional Services</h2>
                <div className="bg-gray-50 p-6 rounded-lg mb-6">
                  <p className="text-gray-600 mb-4">
                    Don't want to handle site preparation yourself? We offer professional site preparation services:
                  </p>
                  <ul className="space-y-2 text-gray-600 mb-6">
                    <li>• Site evaluation and planning</li>
                    <li>• Grading and leveling</li>
                    <li>• Foundation installation</li>
                    <li>• Drainage solutions</li>
                  </ul>
                  <div className="flex flex-col sm:flex-row gap-4">
                    <ButtonLink 
                      to="/site-preparation-services" 
                      variant="primary"
                      className="text-center"
                    >
                      Site Preparation Services
                    </ButtonLink>
                    <ButtonLink 
                      to="/contact" 
                      variant="outline"
                      className="text-center"
                    >
                      Get a Quote
                    </ButtonLink>
                  </div>
                </div>
              </section>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SitePreparation;