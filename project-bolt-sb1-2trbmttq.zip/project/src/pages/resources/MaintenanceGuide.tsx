import React from 'react';
import { PenTool as Tool, Wrench, Hammer, Ruler, Paintbrush, Shield } from 'lucide-react';

const MaintenanceGuide = () => {
  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center">
          <h1 className="text-4xl font-bold text-gray-900 mb-8">Barn Maintenance Guide</h1>
          <p className="text-xl text-gray-600 mb-12">Keep your barn in top condition with our comprehensive maintenance guide</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {/* Regular Inspections */}
          <div className="bg-white rounded-lg shadow-lg p-6">
            <div className="flex items-center mb-4">
              <Tool className="h-8 w-8 text-blue-600 mr-3" />
              <h2 className="text-2xl font-semibold text-gray-900">Regular Inspections</h2>
            </div>
            <p className="text-gray-600">Perform monthly inspections of your barn's structure, checking for any signs of wear, damage, or potential issues.</p>
          </div>

          {/* Structural Maintenance */}
          <div className="bg-white rounded-lg shadow-lg p-6">
            <div className="flex items-center mb-4">
              <Wrench className="h-8 w-8 text-blue-600 mr-3" />
              <h2 className="text-2xl font-semibold text-gray-900">Structural Maintenance</h2>
            </div>
            <p className="text-gray-600">Regularly check and tighten all bolts, screws, and structural components to ensure stability and safety.</p>
          </div>

          {/* Weather Protection */}
          <div className="bg-white rounded-lg shadow-lg p-6">
            <div className="flex items-center mb-4">
              <Shield className="h-8 w-8 text-blue-600 mr-3" />
              <h2 className="text-2xl font-semibold text-gray-900">Weather Protection</h2>
            </div>
            <p className="text-gray-600">Inspect and maintain weather seals, roof condition, and drainage systems to protect against environmental damage.</p>
          </div>

          {/* Surface Care */}
          <div className="bg-white rounded-lg shadow-lg p-6">
            <div className="flex items-center mb-4">
              <Paintbrush className="h-8 w-8 text-blue-600 mr-3" />
              <h2 className="text-2xl font-semibold text-gray-900">Surface Care</h2>
            </div>
            <p className="text-gray-600">Clean surfaces regularly and maintain protective coatings to prevent rust and deterioration.</p>
          </div>

          {/* Repair Guidelines */}
          <div className="bg-white rounded-lg shadow-lg p-6">
            <div className="flex items-center mb-4">
              <Hammer className="h-8 w-8 text-blue-600 mr-3" />
              <h2 className="text-2xl font-semibold text-gray-900">Repair Guidelines</h2>
            </div>
            <p className="text-gray-600">Follow proper repair procedures and use recommended materials for any maintenance work.</p>
          </div>

          {/* Measurements & Documentation */}
          <div className="bg-white rounded-lg shadow-lg p-6">
            <div className="flex items-center mb-4">
              <Ruler className="h-8 w-8 text-blue-600 mr-3" />
              <h2 className="text-2xl font-semibold text-gray-900">Documentation</h2>
            </div>
            <p className="text-gray-600">Keep detailed records of all maintenance work, inspections, and repairs for future reference.</p>
          </div>
        </div>

        <div className="mt-12 bg-white rounded-lg shadow-lg p-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-6">Maintenance Schedule</h2>
          <div className="space-y-4">
            <div className="border-b pb-4">
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Monthly Tasks</h3>
              <ul className="list-disc list-inside text-gray-600">
                <li>Visual inspection of all structural components</li>
                <li>Check for signs of water damage or leaks</li>
                <li>Inspect door operation and hardware</li>
                <li>Clean gutters and drainage systems</li>
              </ul>
            </div>
            <div className="border-b pb-4">
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Quarterly Tasks</h3>
              <ul className="list-disc list-inside text-gray-600">
                <li>Detailed structural inspection</li>
                <li>Tighten all bolts and fasteners</li>
                <li>Check and repair weather sealing</li>
                <li>Inspect and clean ventilation systems</li>
              </ul>
            </div>
            <div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Annual Tasks</h3>
              <ul className="list-disc list-inside text-gray-600">
                <li>Professional structural assessment</li>
                <li>Complete roof inspection</li>
                <li>Repaint or touch up protective coatings</li>
                <li>Update maintenance documentation</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MaintenanceGuide;