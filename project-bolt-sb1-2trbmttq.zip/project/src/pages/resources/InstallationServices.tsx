import React, { useEffect } from 'react';
import { PenTool as Tool, CheckCircle, Clock, AlertTriangle } from 'lucide-react';
import ButtonLink from '../../components/common/ButtonLink';

const InstallationServices: React.FC = () => {
  useEffect(() => {
    window.scrollTo(0, 0);
    document.title = 'Installation Services - White Pine Structures';
  }, []);

  return (
    <div className="min-h-screen bg-gray-50 pt-32 pb-16">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-lg shadow-md p-8 mb-8">
            <div className="flex items-center mb-6">
              <Tool className="h-8 w-8 text-[#978E5F] mr-3" />
              <h1 className="text-3xl font-serif font-bold text-gray-900">Installation Services</h1>
            </div>
            
            <p className="text-lg text-gray-600 mb-8">
              Our professional installation team ensures your structure is properly placed, leveled, and ready for use. We handle everything from delivery to final setup.
            </p>

            <div className="space-y-8">
              <section>
                <h2 className="text-2xl font-semibold text-gray-900 mb-4">Our Services</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="bg-gray-50 p-6 rounded-lg">
                    <h3 className="font-semibold text-gray-900 mb-3">Site Assessment</h3>
                    <ul className="space-y-2 text-gray-600">
                      <li>• Professional site evaluation</li>
                      <li>• Soil condition analysis</li>
                      <li>• Drainage assessment</li>
                      <li>• Access path evaluation</li>
                      <li>• Utility location marking</li>
                    </ul>
                  </div>
                  
                  <div className="bg-gray-50 p-6 rounded-lg">
                    <h3 className="font-semibold text-gray-900 mb-3">Ground Preparation</h3>
                    <ul className="space-y-2 text-gray-600">
                      <li>• Site clearing and excavation</li>
                      <li>• Ground leveling</li>
                      <li>• Soil compaction</li>
                      <li>• Erosion control</li>
                      <li>• Drainage solutions</li>
                    </ul>
                  </div>
                </div>
              </section>

              <section>
                <h2 className="text-2xl font-semibold text-gray-900 mb-4">Foundation Options</h2>
                <div className="space-y-4">
                  <div className="bg-gray-50 p-6 rounded-lg">
                    <h3 className="font-semibold text-gray-900 mb-3">Gravel Pad Installation</h3>
                    <div className="flex items-start mb-3">
                      <Tool className="h-5 w-5 text-[#978E5F] flex-shrink-0 mt-0.5 mr-2" />
                      <p className="text-gray-600">Professional installation of a properly compacted gravel base:</p>
                    </div>
                    <ul className="space-y-2 text-gray-600 ml-7">
                      <li>• Site excavation</li>
                      <li>• Weed barrier installation</li>
                      <li>• #57 stone placement</li>
                      <li>• Professional compaction</li>
                      <li>• Final leveling</li>
                    </ul>
                  </div>

                  <div className="bg-gray-50 p-6 rounded-lg">
                    <h3 className="font-semibold text-gray-900 mb-3">Concrete Pad Installation</h3>
                    <div className="flex items-start mb-3">
                      <Tool className="h-5 w-5 text-[#978E5F] flex-shrink-0 mt-0.5 mr-2" />
                      <p className="text-gray-600">Complete concrete foundation installation:</p>
                    </div>
                    <ul className="space-y-2 text-gray-600 ml-7">
                      <li>• Site preparation</li>
                      <li>• Form construction</li>
                      <li>• Rebar installation</li>
                      <li>• Concrete pouring</li>
                      <li>• Surface finishing</li>
                    </ul>
                  </div>
                </div>
              </section>

              <section>
                <h2 className="text-2xl font-semibold text-gray-900 mb-4">Process Overview</h2>
                <div className="bg-gray-50 p-6 rounded-lg">
                  <ol className="space-y-4">
                    <li className="flex items-start">
                      <span className="flex-shrink-0 flex items-center justify-center h-6 w-6 rounded-full bg-[#978E5F] text-white text-sm font-medium mr-3">1</span>
                      <div>
                        <h4 className="font-medium text-gray-900">Initial Consultation</h4>
                        <p className="text-gray-600">Site visit and assessment of requirements</p>
                      </div>
                    </li>
                    <li className="flex items-start">
                      <span className="flex-shrink-0 flex items-center justify-center h-6 w-6 rounded-full bg-[#978E5F] text-white text-sm font-medium mr-3">2</span>
                      <div>
                        <h4 className="font-medium text-gray-900">Proposal</h4>
                        <p className="text-gray-600">Detailed quote and timeline for services</p>
                      </div>
                    </li>
                    <li className="flex items-start">
                      <span className="flex-shrink-0 flex items-center justify-center h-6 w-6 rounded-full bg-[#978E5F] text-white text-sm font-medium mr-3">3</span>
                      <div>
                        <h4 className="font-medium text-gray-900">Site Preparation</h4>
                        <p className="text-gray-600">Professional preparation of your site</p>
                      </div>
                    </li>
                    <li className="flex items-start">
                      <span className="flex-shrink-0 flex items-center justify-center h-6 w-6 rounded-full bg-[#978E5F] text-white text-sm font-medium mr-3">4</span>
                      <div>
                        <h4 className="font-medium text-gray-900">Final Inspection</h4>
                        <p className="text-gray-600">Quality check and approval for installation</p>
                      </div>
                    </li>
                  </ol>
                </div>
              </section>

              <section>
                <h2 className="text-2xl font-semibold text-gray-900 mb-4">Important Information</h2>
                <div className="bg-yellow-50 p-6 rounded-lg mb-6">
                  <div className="flex items-start">
                    <AlertTriangle className="h-6 w-6 text-yellow-600 flex-shrink-0 mt-1 mr-3" />
                    <div>
                      <h3 className="font-semibold text-yellow-900 mb-2">Before We Begin</h3>
                      <ul className="space-y-2 text-yellow-800">
                        <li>• Contact utility companies for marking</li>
                        <li>• Obtain necessary permits</li>
                        <li>• Clear access to work area</li>
                        <li>• Weather considerations</li>
                        <li>• HOA approval (if required)</li>
                      </ul>
                    </div>
                  </div>
                </div>
                
                <div className="flex flex-col sm:flex-row gap-4">
                  <ButtonLink 
                    to="/contact" 
                    variant="primary"
                    className="text-center"
                  >
                    Schedule Consultation
                  </ButtonLink>
                  <ButtonLink 
                    to="/site-preparation" 
                    variant="outline"
                    className="text-center"
                  >
                    View Preparation Guide
                  </ButtonLink>
                </div>
              </section>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default InstallationServices;