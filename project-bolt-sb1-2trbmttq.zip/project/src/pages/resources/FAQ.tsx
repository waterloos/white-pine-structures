import React, { useEffect, useState } from 'react';
import { ChevronDown, ChevronUp, Search } from 'lucide-react';
import ButtonLink from '../../components/common/ButtonLink';

interface FAQItem {
  question: string;
  answer: string;
  category: string;
}

const FAQ: React.FC = () => {
  const [activeIndex, setActiveIndex] = useState<number | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');

  useEffect(() => {
    window.scrollTo(0, 0);
    document.title = 'Frequently Asked Questions - White Pine Structures';
  }, []);

  const faqItems: FAQItem[] = [
    {
      category: 'general',
      question: 'What types of structures do you build?',
      answer: 'We specialize in custom sheds, garages, workshops, greenhouses, and other outdoor structures. Each building is crafted with premium materials and can be customized to meet your specific needs.'
    },
    {
      category: 'general',
      question: 'How long does it take to build a custom structure?',
      answer: 'Build times vary depending on the size and complexity of your structure. Typically, most custom builds are completed within 2-6 weeks from order confirmation. We\'ll provide you with a specific timeline during the ordering process.'
    },
    {
      category: 'pricing',
      question: 'Do you offer financing options?',
      answer: 'Yes! We partner with SmartPay to offer flexible rent-to-own options with no credit check required. Monthly payments can be spread over 24 or 36 months, and you can pay off early at any time with no penalties.'
    },
    {
      category: 'pricing',
      question: 'What is included in the price?',
      answer: 'Our prices include the structure itself, standard delivery within our service area, and basic installation. Additional fees may apply for site preparation, extended delivery distances, or special installation requirements.'
    },
    {
      category: 'delivery',
      question: 'What areas do you service?',
      answer: 'We primarily serve Pennsylvania, including Chester, Lancaster, Delaware, Montgomery, Berks, and York counties. We also deliver to parts of Maryland, Delaware, and New Jersey. Contact us for specific delivery availability in your area.'
    },
    {
      category: 'delivery',
      question: 'How is delivery handled?',
      answer: 'We use specialized equipment to deliver and place your structure. Our team will work with you to determine the best access route and final placement location. Most deliveries are completed within 2-3 hours.'
    },
    {
      category: 'site-prep',
      question: 'What kind of site preparation is needed?',
      answer: 'Your site should be level and have adequate drainage. We recommend a gravel pad or concrete slab depending on the structure size and intended use. Our site preparation guide provides detailed requirements, and we offer professional site preparation services.'
    },
    {
      category: 'site-prep',
      question: 'Do I need a permit for my structure?',
      answer: 'Permit requirements vary by location. Many municipalities require permits for structures over a certain size. We can provide necessary documentation for permit applications, but obtaining permits is the customer\'s responsibility.'
    },
    {
      category: 'warranty',
      question: 'What warranty coverage is provided?',
      answer: 'Our structures come with a 5-year structural warranty and 1-year craftsmanship warranty. We also pass through all manufacturer warranties on materials. Extended warranty options are available for purchase.'
    },
    {
      category: 'warranty',
      question: 'How do I make a warranty claim?',
      answer: 'Contact our warranty department with photos and description of the issue. We\'ll schedule an inspection if necessary and coordinate any needed repairs or replacements covered under warranty.'
    },
    {
      category: 'customization',
      question: 'Can I customize my structure?',
      answer: 'Yes! We offer extensive customization options including size, style, colors, door and window placement, interior features, and more. Our design team will work with you to create a structure that meets your specific needs.'
    },
    {
      category: 'customization',
      question: 'Can I modify my structure after installation?',
      answer: 'While possible, we recommend planning all modifications during the initial design phase. Post-installation modifications may affect your warranty coverage and should be performed by qualified professionals.'
    }
  ];

  const categories = [
    { id: 'all', name: 'All Questions' },
    { id: 'general', name: 'General Information' },
    { id: 'pricing', name: 'Pricing & Financing' },
    { id: 'delivery', name: 'Delivery & Installation' },
    { id: 'site-prep', name: 'Site Preparation' },
    { id: 'warranty', name: 'Warranty' },
    { id: 'customization', name: 'Customization' }
  ];

  const filteredFAQs = faqItems
    .filter(item => 
      (selectedCategory === 'all' || item.category === selectedCategory) &&
      (item.question.toLowerCase().includes(searchTerm.toLowerCase()) ||
       item.answer.toLowerCase().includes(searchTerm.toLowerCase()))
    );

  return (
    <div className="min-h-screen bg-gray-50 pt-32 pb-16">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-lg shadow-md p-8">
            <h1 className="text-3xl font-serif font-bold text-gray-900 mb-6">Frequently Asked Questions</h1>
            
            {/* Search and Filter */}
            <div className="mb-8 space-y-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                <input
                  type="text"
                  placeholder="Search questions..."
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#978E5F] focus:border-transparent"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              
              <div className="flex flex-wrap gap-2">
                {categories.map(category => (
                  <button
                    key={category.id}
                    onClick={() => setSelectedCategory(category.id)}
                    className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                      selectedCategory === category.id
                        ? 'bg-[#978E5F] text-white'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    {category.name}
                  </button>
                ))}
              </div>
            </div>

            {/* FAQ List */}
            <div className="space-y-4">
              {filteredFAQs.map((item, index) => (
                <div
                  key={index}
                  className="border border-gray-200 rounded-lg overflow-hidden"
                >
                  <button
                    onClick={() => setActiveIndex(activeIndex === index ? null : index)}
                    className="w-full px-6 py-4 text-left flex justify-between items-center hover:bg-gray-50 transition-colors"
                  >
                    <span className="font-medium text-gray-900">{item.question}</span>
                    {activeIndex === index ? (
                      <ChevronUp className="h-5 w-5 text-gray-500" />
                    ) : (
                      <ChevronDown className="h-5 w-5 text-gray-500" />
                    )}
                  </button>
                  
                  <div
                    className={`px-6 transition-all duration-200 ease-in-out ${
                      activeIndex === index ? 'py-4 border-t border-gray-200' : 'py-0 h-0'
                    }`}
                  >
                    <p className="text-gray-600">{item.answer}</p>
                  </div>
                </div>
              ))}
            </div>

            {filteredFAQs.length === 0 && (
              <div className="text-center py-8">
                <p className="text-gray-600">No questions found matching your search.</p>
              </div>
            )}

            {/* Contact CTA */}
            <div className="mt-12 bg-gray-50 p-6 rounded-lg text-center">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Still have questions?</h2>
              <p className="text-gray-600 mb-6">
                Our team is here to help! Contact us for personalized assistance with your project.
              </p>
              <div className="flex flex-col sm:flex-row justify-center gap-4">
                <ButtonLink 
                  to="/contact" 
                  variant="primary"
                  className="text-center"
                >
                  Contact Us
                </ButtonLink>
                <ButtonLink 
                  to="/proposal-generator" 
                  variant="outline"
                  className="text-center"
                >
                  Get a Custom Quote
                </ButtonLink>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FAQ;