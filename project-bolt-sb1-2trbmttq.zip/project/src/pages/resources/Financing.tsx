import React, { useEffect } from 'react';
import { DollarSign, Calculator, Clock, CheckCircle } from 'lucide-react';
import ButtonLink from '../../components/common/ButtonLink';

const Financing: React.FC = () => {
  useEffect(() => {
    window.scrollTo(0, 0);
    document.title = 'Financing Options - White Pine Structures';
  }, []);

  return (
    <div className="min-h-screen bg-gray-50 pt-32 pb-16">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-lg shadow-md p-8 mb-8">
            <div className="flex items-center mb-6">
              <DollarSign className="h-8 w-8 text-[#978E5F] mr-3" />
              <h1 className="text-3xl font-serif font-bold text-gray-900">Financing Options</h1>
            </div>
            
            <p className="text-lg text-gray-600 mb-8">
              Make your dream structure affordable with our flexible financing options. We partner with SmartPay to offer easy rent-to-own programs with no credit check required.
            </p>

            <div className="space-y-8">
              <section>
                <h2 className="text-2xl font-semibold text-gray-900 mb-4">SmartPay Rent-to-Own Program</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="bg-gray-50 p-6 rounded-lg">
                    <h3 className="font-semibold text-gray-900 mb-3">Program Benefits</h3>
                    <ul className="space-y-2">
                      {[
                        'No credit check required',
                        'Flexible payment terms',
                        'Early payoff options',
                        'Low monthly payments',
                        'Quick approval process'
                      ].map((benefit, index) => (
                        <li key={index} className="flex items-start">
                          <CheckCircle className="h-5 w-5 text-[#978E5F] flex-shrink-0 mt-0.5 mr-2" />
                          <span className="text-gray-600">{benefit}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                  
                  <div className="bg-gray-50 p-6 rounded-lg">
                    <h3 className="font-semibold text-gray-900 mb-3">How It Works</h3>
                    <ol className="space-y-3 text-gray-600">
                      <li className="flex items-start">
                        <span className="flex-shrink-0 flex items-center justify-center h-6 w-6 rounded-full bg-[#978E5F] text-white text-sm font-medium mr-3">1</span>
                        <span>Choose your structure and customize options</span>
                      </li>
                      <li className="flex items-start">
                        <span className="flex-shrink-0 flex items-center justify-center h-6 w-6 rounded-full bg-[#978E5F] text-white text-sm font-medium mr-3">2</span>
                        <span>Complete simple application process</span>
                      </li>
                      <li className="flex items-start">
                        <span className="flex-shrink-0 flex items-center justify-center h-6 w-6 rounded-full bg-[#978E5F] text-white text-sm font-medium mr-3">3</span>
                        <span>Make first payment and schedule delivery</span>
                      </li>
                      <li className="flex items-start">
                        <span className="flex-shrink-0 flex items-center justify-center h-6 w-6 rounded-full bg-[#978E5F] text-white text-sm font-medium mr-3">4</span>
                        <span>Enjoy your structure while making payments</span>
                      </li>
                    </ol>
                  </div>
                </div>
              </section>

              <section>
                <h2 className="text-2xl font-semibold text-gray-900 mb-4">Payment Terms</h2>
                <div className="space-y-4">
                  <div className="bg-gray-50 p-6 rounded-lg">
                    <div className="flex items-center mb-4">
                      <Clock className="h-6 w-6 text-[#978E5F] mr-2" />
                      <h3 className="font-semibold text-gray-900">Flexible Options</h3>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <h4 className="font-medium text-gray-900 mb-2">24-Month Term</h4>
                        <ul className="space-y-2 text-gray-600">
                          <li>• Higher monthly payments</li>
                          <li>• Shorter commitment</li>
                          <li>• Lower total cost</li>
                          <li>• 10% initial payment</li>
                        </ul>
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-900 mb-2">36-Month Term</h4>
                        <ul className="space-y-2 text-gray-600">
                          <li>• Lower monthly payments</li>
                          <li>• Extended payment period</li>
                          <li>• More budget-friendly</li>
                          <li>• 10% initial payment</li>
                        </ul>
                      </div>
                    </div>
                  </div>

                  <div className="bg-gray-50 p-6 rounded-lg">
                    <div className="flex items-center mb-4">
                      <Calculator className="h-6 w-6 text-[#978E5F] mr-2" />
                      <h3 className="font-semibold text-gray-900">Payment Example</h3>
                    </div>
                    <div className="overflow-x-auto">
                      <table className="w-full">
                        <thead>
                          <tr className="text-left">
                            <th className="pb-3 text-gray-600">Structure Price</th>
                            <th className="pb-3 text-gray-600">Down Payment</th>
                            <th className="pb-3 text-gray-600">24 Month Payment</th>
                            <th className="pb-3 text-gray-600">36 Month Payment</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr className="border-t border-gray-200">
                            <td className="py-3">$3,000</td>
                            <td className="py-3">$300</td>
                            <td className="py-3">$138/mo</td>
                            <td className="py-3">$98/mo</td>
                          </tr>
                          <tr className="border-t border-gray-200">
                            <td className="py-3">$5,000</td>
                            <td className="py-3">$500</td>
                            <td className="py-3">$230/mo</td>
                            <td className="py-3">$164/mo</td>
                          </tr>
                          <tr className="border-t border-gray-200">
                            <td className="py-3">$8,000</td>
                            <td className="py-3">$800</td>
                            <td className="py-3">$368/mo</td>
                            <td className="py-3">$262/mo</td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                    <p className="text-sm text-gray-500 mt-4">
                      * Payments are examples only. Actual payments may vary based on structure price and options selected.
                    </p>
                  </div>
                </div>
              </section>

              <section>
                <h2 className="text-2xl font-semibold text-gray-900 mb-4">Early Payoff Options</h2>
                <div className="bg-gray-50 p-6 rounded-lg">
                  <p className="text-gray-600 mb-4">
                    You can pay off your structure early at any time with no prepayment penalties:
                  </p>
                  <ul className="space-y-2 text-gray-600">
                    <li className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-[#978E5F] flex-shrink-0 mt-0.5 mr-2" />
                      <span>Pay off the remaining balance at any time</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-[#978E5F] flex-shrink-0 mt-0.5 mr-2" />
                      <span>No early payment penalties</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-[#978E5F] flex-shrink-0 mt-0.5 mr-2" />
                      <span>Reduced total cost with early payoff</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-[#978E5F] flex-shrink-0 mt-0.5 mr-2" />
                      <span>Flexible payment amounts accepted</span>
                    </li>
                  </ul>
                </div>
              </section>

              <section>
                <h2 className="text-2xl font-semibold text-gray-900 mb-4">Application Process</h2>
                <div className="bg-gray-50 p-6 rounded-lg mb-6">
                  <p className="text-gray-600 mb-4">
                    Getting started with SmartPay is quick and easy:
                  </p>
                  <ol className="space-y-4 mb-6">
                    <li className="flex items-start">
                      <span className="flex-shrink-0 flex items-center justify-center h-6 w-6 rounded-full bg-[#978E5F] text-white text-sm font-medium mr-3">1</span>
                      <div>
                        <h4 className="font-medium text-gray-900">Choose Your Structure</h4>
                        <p className="text-gray-600">Select your structure and customize it to your needs</p>
                      </div>
                    </li>
                    <li className="flex items-start">
                      <span className="flex-shrink-0 flex items-center justify-center h-6 w-6 rounded-full bg-[#978E5F] text-white text-sm font-medium mr-3">2</span>
                      <div>
                        <h4 className="font-medium text-gray-900">Complete Application</h4>
                        <p className="text-gray-600">Fill out the simple application form with basic information</p>
                      </div>
                    </li>
                    <li className="flex items-start">
                      <span className="flex-shrink-0 flex items-center justify-center h-6 w-6 rounded-full bg-[#978E5F] text-white text-sm font-medium mr-3">3</span>
                      <div>
                        <h4 className="font-medium text-gray-900">Provide Documentation</h4>
                        <p className="text-gray-600">Submit proof of income and residence</p>
                      </div>
                    </li>
                    <li className="flex items-start">
                      <span className="flex-shrink-0 flex items-center justify-center h-6 w-6 rounded-full bg-[#978E5F] text-white text-sm font-medium mr-3">4</span>
                      <div>
                        <h4 className="font-medium text-gray-900">Get Approved</h4>
                        <p className="text-gray-600">Receive quick approval and schedule your delivery</p>
                      </div>
                    </li>
                  </ol>
                  <div className="flex flex-col sm:flex-row gap-4">
                    <ButtonLink 
                      to="/contact" 
                      variant="primary"
                      className="text-center"
                    >
                      Apply Now
                    </ButtonLink>
                    <ButtonLink 
                      to="/stock-structures" 
                      variant="outline"
                      className="text-center"
                    >
                      View Available Structures
                    </ButtonLink>
                  </div>
                </div>
              </section>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Financing;