import React, { useEffect, useState } from 'react';
import { Search, Filter, SlidersHorizontal } from 'lucide-react';
import StockInventoryCard from '../components/stock/StockInventoryCard';
import { StockInventoryItem } from '../types';
import { stockInventory } from '../data/stockInventory';

const StockStructures: React.FC = () => {
  const [inventory, setInventory] = useState<StockInventoryItem[]>(stockInventory);
  const [filters, setFilters] = useState({
    type: 'all',
    status: 'all',
    priceRange: [0, 50000],
    searchTerm: '',
    sortBy: 'newest'
  });

  useEffect(() => {
    window.scrollTo(0, 0);
    document.title = 'Stock Structures - White Pine Structures';
  }, []);

  useEffect(() => {
    let filtered = [...stockInventory];

    if (filters.type !== 'all') {
      filtered = filtered.filter(item => item.type === filters.type);
    }

    if (filters.status !== 'all') {
      filtered = filtered.filter(item => item.status === filters.status);
    }

    filtered = filtered.filter(
      item => item.pricing.retailPrice >= filters.priceRange[0] && 
              item.pricing.retailPrice <= filters.priceRange[1]
    );

    if (filters.searchTerm) {
      const searchLower = filters.searchTerm.toLowerCase();
      filtered = filtered.filter(item => 
        item.name.toLowerCase().includes(searchLower) ||
        item.modelNumber.toLowerCase().includes(searchLower) ||
        item.description.toLowerCase().includes(searchLower)
      );
    }

    switch (filters.sortBy) {
      case 'newest':
        filtered.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        break;
      case 'price-low':
        filtered.sort((a, b) => a.pricing.retailPrice - b.pricing.retailPrice);
        break;
      case 'price-high':
        filtered.sort((a, b) => b.pricing.retailPrice - a.pricing.retailPrice);
        break;
    }

    setInventory(filtered);
  }, [filters]);

  return (
    <div>
      {/* Hero Section - Apple Style */}
      <div className="pt-40 pb-24 bg-gradient-to-b from-white to-gray-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-6xl sm:text-7xl font-semibold tracking-tight text-gray-900 mb-6">
              Stock Structures
            </h1>
            <p className="text-xl sm:text-2xl text-gray-500 leading-relaxed max-w-3xl mx-auto">
              Browse our inventory of ready-to-deliver structures, available for immediate purchase and delivery to your location.
            </p>
          </div>
        </div>
      </div>

      {/* Filters Section */}
      <div className="sticky top-20 bg-white shadow-md z-30">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex flex-col md:flex-row md:items-center md:space-x-6 space-y-4 md:space-y-0">
            {/* Search */}
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                <input
                  type="text"
                  placeholder="Search by name, model number, or description..."
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#978E5F] focus:border-transparent"
                  value={filters.searchTerm}
                  onChange={(e) => setFilters(prev => ({ ...prev, searchTerm: e.target.value }))}
                />
              </div>
            </div>

            {/* Type Filter */}
            <div className="flex items-center space-x-4">
              <div className="flex items-center">
                <Filter className="mr-2 text-gray-500" size={20} />
                <select
                  className="border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#978E5F] focus:border-transparent"
                  value={filters.type}
                  onChange={(e) => setFilters(prev => ({ ...prev, type: e.target.value }))}
                >
                  <option value="all">All Types</option>
                  <option value="shed">Sheds</option>
                  <option value="garage">Garages</option>
                  <option value="greenhouse">Greenhouses</option>
                  <option value="hunting-blind">Hunting Blinds</option>
                  <option value="run-in">Run-In Sheds</option>
                </select>
              </div>

              <div className="flex items-center">
                <SlidersHorizontal className="mr-2 text-gray-500" size={20} />
                <select
                  className="border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#978E5F] focus:border-transparent"
                  value={filters.sortBy}
                  onChange={(e) => setFilters(prev => ({ ...prev, sortBy: e.target.value }))}
                >
                  <option value="newest">Newest First</option>
                  <option value="price-low">Price: Low to High</option>
                  <option value="price-high">Price: High to Low</option>
                </select>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Inventory Grid */}
      <div className="bg-gray-50 py-8">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-6 flex justify-between items-center">
            <h2 className="text-2xl font-semibold text-gray-900">
              {inventory.length} {inventory.length === 1 ? 'Structure' : 'Structures'} Available
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {inventory.map(item => (
              <StockInventoryCard key={item.modelNumber} item={item} />
            ))}
          </div>

          {inventory.length === 0 && (
            <div className="text-center py-16">
              <h3 className="text-2xl font-semibold text-gray-700">No structures found</h3>
              <p className="text-gray-600 mt-2">Try adjusting your filters or search terms.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default StockStructures;