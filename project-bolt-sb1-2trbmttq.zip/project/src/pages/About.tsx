import React, { useEffect } from 'react';
import { Users, Calendar, Award, Shield } from 'lucide-react';
import ButtonLink from '../components/common/ButtonLink';

const About: React.FC = () => {
  useEffect(() => {
    window.scrollTo(0, 0);
    document.title = 'About Us - White Pine Structures';
  }, []);

  return (
    <div>
      {/* Hero Section - Apple Style */}
      <div className="pt-40 pb-24 bg-gradient-to-b from-white to-gray-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-6xl sm:text-7xl font-semibold tracking-tight text-gray-900 mb-6">
              About White Pine Structures
            </h1>
            <p className="text-xl sm:text-2xl text-gray-500 leading-relaxed max-w-3xl mx-auto">
              Crafting high-quality custom structures since 1998. Learn about our story, values, and commitment to excellence.
            </p>
          </div>
        </div>
      </div>

      {/* Our Story Section */}
      <div className="py-16 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-serif font-bold text-gray-900 mb-6">Our Story</h2>
              <p className="text-gray-700 mb-4">
                White Pine Structures was founded in 1998 with a simple mission: to create high-quality outdoor structures that enhance properties and meet the unique needs of our customers. What began as a small family business has grown into a trusted name in custom sheds, garages, and specialty structures throughout Maine.
              </p>
              <p className="text-gray-700 mb-6">
                Our founder, John White, started the company with a passion for woodworking and a commitment to traditional craftsmanship. After years working in construction, John saw the need for outdoor structures that combined durability with aesthetic appeal. He assembled a team of skilled craftsmen who shared his vision, and White Pine Structures was born.
              </p>
              <div className="grid grid-cols-2 gap-4 mb-6">
                <div className="bg-gray-50 p-4 rounded-lg text-center">
                  <span className="block text-3xl font-bold text-[#978E5F] mb-2">25+</span>
                  <span className="text-gray-600">Years of Experience</span>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg text-center">
                  <span className="block text-3xl font-bold text-[#978E5F] mb-2">5,000+</span>
                  <span className="text-gray-600">Structures Built</span>
                </div>
              </div>
            </div>
            <div className="relative">
              <img 
                src="https://images.pexels.com/photos/1094767/pexels-photo-1094767.jpeg" 
                alt="White Pine Structures workshop" 
                className="rounded-lg shadow-lg"
              />
              <div className="absolute inset-0 border-8 border-[#978E5F] rounded-lg transform translate-x-6 translate-y-6 -z-10"></div>
            </div>
          </div>
        </div>
      </div>

      {/* Values Section */}
      <div className="py-16 bg-gray-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-serif font-bold text-gray-900 mb-4">Our Values</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              At White Pine Structures, our work is guided by a set of core values that inform everything we do.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-md text-center">
              <div className="inline-flex items-center justify-center h-16 w-16 rounded-full bg-[#978E5F] bg-opacity-10 text-[#978E5F] mb-4">
                <Award size={28} />
              </div>
              <h3 className="text-xl font-semibold mb-2 text-gray-900">Quality Craftsmanship</h3>
              <p className="text-gray-600">
                We take pride in our work and never compromise on materials or construction techniques.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md text-center">
              <div className="inline-flex items-center justify-center h-16 w-16 rounded-full bg-[#978E5F] bg-opacity-10 text-[#978E5F] mb-4">
                <Users size={28} />
              </div>
              <h3 className="text-xl font-semibold mb-2 text-gray-900">Customer Focus</h3>
              <p className="text-gray-600">
                We listen to our customers' needs and work collaboratively to create the perfect structures.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md text-center">
              <div className="inline-flex items-center justify-center h-16 w-16 rounded-full bg-[#978E5F] bg-opacity-10 text-[#978E5F] mb-4">
                <Shield size={28} />
              </div>
              <h3 className="text-xl font-semibold mb-2 text-gray-900">Integrity</h3>
              <p className="text-gray-600">
                We operate with honesty and transparency in all our business practices and relationships.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md text-center">
              <div className="inline-flex items-center justify-center h-16 w-16 rounded-full bg-[#978E5F] bg-opacity-10 text-[#978E5F] mb-4">
                <Calendar size={28} />
              </div>
              <h3 className="text-xl font-semibold mb-2 text-gray-900">Reliability</h3>
              <p className="text-gray-600">
                We deliver on our promises, with structures that are completed on time and built to last.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Team Section */}
      <div className="py-16 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-serif font-bold text-gray-900 mb-4">Our Team</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Meet the skilled craftspeople and professionals who make White Pine Structures possible.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-gray-50 rounded-lg overflow-hidden shadow-md">
              <img 
                src="https://images.pexels.com/photos/1516680/pexels-photo-1516680.jpeg" 
                alt="John White, Founder" 
                className="w-full h-64 object-cover"
              />
              <div className="p-6">
                <h3 className="text-xl font-semibold text-gray-900 mb-1">John White</h3>
                <p className="text-[#978E5F] font-medium mb-4">Founder & Master Craftsman</p>
                <p className="text-gray-600">
                  With over 35 years of woodworking experience, John founded White Pine Structures to create outdoor buildings that combine functionality with traditional craftsmanship.
                </p>
              </div>
            </div>
            
            <div className="bg-gray-50 rounded-lg overflow-hidden shadow-md">
              <img 
                src="https://images.pexels.com/photos/3778603/pexels-photo-3778603.jpeg" 
                alt="Sarah Johnson, Design Manager" 
                className="w-full h-64 object-cover"
              />
              <div className="p-6">
                <h3 className="text-xl font-semibold text-gray-900 mb-1">Sarah Johnson</h3>
                <p className="text-[#978E5F] font-medium mb-4">Design Manager</p>
                <p className="text-gray-600">
                  Sarah works directly with customers to design structures that meet their specific needs while ensuring aesthetic appeal and structural integrity.
                </p>
              </div>
            </div>
            
            <div className="bg-gray-50 rounded-lg overflow-hidden shadow-md">
              <img 
                src="https://images.pexels.com/photos/1181345/pexels-photo-1181345.jpeg" 
                alt="Mike Thompson, Construction Lead" 
                className="w-full h-64 object-cover"
              />
              <div className="p-6">
                <h3 className="text-xl font-semibold text-gray-900 mb-1">Mike Thompson</h3>
                <p className="text-[#978E5F] font-medium mb-4">Construction Lead</p>
                <p className="text-gray-600">
                  With 20 years in construction, Mike leads our building team, ensuring that every structure is built to exact specifications with quality craftsmanship.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="py-16 bg-[#978E5F] bg-opacity-10">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-serif font-bold text-gray-900 mb-6">Ready to Start Your Project?</h2>
            <p className="text-xl text-gray-700 mb-8">
              Contact us today to discuss your custom structure needs or browse our in-stock buildings ready for delivery.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <ButtonLink 
                to="/contact" 
                variant="primary"
                className="text-lg"
              >
                Contact Us
              </ButtonLink>
              <ButtonLink 
                to="/proposal-generator" 
                variant="outline"
                className="text-lg"
              >
                Generate a Proposal
              </ButtonLink>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;