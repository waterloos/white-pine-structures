import { Gallery, Testimonial } from '../types';
import { allStructures } from './structures';

// Generate gallery items from structure data
export const galleryItems: Gallery[] = allStructures.flatMap(structure => 
  structure.gallery.map((galleryImage, index) => ({
    id: `${structure.id}-${index}`,
    imageUrl: galleryImage.url,
    title: galleryImage.caption || structure.name,
    description: structure.description,
    structureType: structure.type,
    structureName: structure.name,
  }))
);

export const testimonials: Testimonial[] = [
  {
    id: 'testimonial-1',
    customer: 'John D.',
    text: 'Our Mini Barn has transformed our backyard storage situation. The quality of craftsmanship is outstanding, and the team at White Pine Structures was a pleasure to work with from design to delivery.',
    rating: 5,
    date: '2024-03-15',
    structureType: 'shed',
  },
  {
    id: 'testimonial-2',
    customer: 'Sarah M.',
    text: 'We purchased a Classic Workshop for my husband\'s woodworking hobby, and it has exceeded our expectations. The attention to detail and quality of materials is evident in every aspect of the structure.',
    rating: 5,
    date: '2024-02-22',
    structureType: 'shed',
  },
  {
    id: 'testimonial-3',
    customer: 'Robert L.',
    text: 'The Two Story Garage from White Pine Structures has given us not only much-needed vehicle storage but also a fantastic workshop and storage area upstairs. The construction quality is second to none.',
    rating: 5,
    date: '2024-01-10',
    structureType: 'garage',
  },
  {
    id: 'testimonial-4',
    customer: 'Emily T.',
    text: 'Our new Greenhouse has completely changed our gardening experience. The design is perfect, and the installation was quick and professional. We\'re already planning our expanded garden for next season!',
    rating: 4,
    date: '2023-12-05',
    structureType: 'other',
  },
  {
    id: 'testimonial-5',
    customer: 'Michael B.',
    text: 'The custom options for our Quaker shed made all the difference. We were able to match it perfectly to our home\'s style, and the proposal process made pricing clear from the beginning.',
    rating: 5,
    date: '2023-11-18',
    structureType: 'shed',
  },
];