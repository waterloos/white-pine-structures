import { ColorCategory } from '../types/colors';

export const colorCategories: ColorCategory[] = [
  {
    id: 'paint',
    name: 'Paint Colors',
    description: 'Our durable paint options provide lasting protection and beauty for your structure.',
    options: [
      { id: 'red', name: 'Red', hex: '#B22234', category: 'paint', available: true, popular: true },
      { id: 'black', name: 'Black', hex: '#000000', category: 'paint', available: true },
      { id: 'bronze', name: 'Bronze', hex: '#CD7F32', category: 'paint', available: true },
      { id: 'clay', name: 'Clay', hex: '#C4A484', category: 'paint', available: true, popular: true },
      { id: 'blue', name: 'Blue', hex: '#1E4D8C', category: 'paint', available: true },
      { id: 'dark-gray', name: 'Dark Gray', hex: '#4A4A4A', category: 'paint', available: true, popular: true },
      { id: 'light-gray', name: 'Light Gray', hex: '#9B9B9B', category: 'paint', available: true },
      { id: 'dark-green', name: 'Dark Green', hex: '#2B5329', category: 'paint', available: true },
      { id: 'light-green', name: 'Light Green', hex: '#90A955', category: 'paint', available: true },
      { id: 'dark-brown', name: 'Dark Brown', hex: '#5C4033', category: 'paint', available: true },
      { id: 'light-brown', name: 'Light Brown', hex: '#996633', category: 'paint', available: true },
      { id: 'tan', name: 'Tan', hex: '#D2B48C', category: 'paint', available: true },
      { id: 'beige', name: 'Beige', hex: '#F5F5DC', category: 'paint', available: true },
      { id: 'linen', name: 'Linen', hex: '#FAF0E6', category: 'paint', available: true, popular: true }
    ]
  },
  {
    id: 'vinyl',
    name: 'Vinyl Siding Colors',
    description: 'Premium vinyl siding options that combine durability with low maintenance.',
    options: [
      { id: 'vinyl-wheat', name: 'Wheat', hex: '#F5DEB3', category: 'vinyl', available: true },
      { id: 'vinyl-ivory', name: 'Ivory', hex: '#FFFFF0', category: 'vinyl', available: true },
      { id: 'vinyl-linen', name: 'Linen', hex: '#FAF0E6', category: 'vinyl', available: true, popular: true },
      { id: 'vinyl-white', name: 'White', hex: '#FFFFFF', category: 'vinyl', available: true, popular: true },
      { id: 'vinyl-slate', name: 'Slate', hex: '#708090', category: 'vinyl', available: true },
      { id: 'vinyl-heritage-gray', name: 'Heritage Gray', hex: '#9B9B9B', category: 'vinyl', available: true },
      { id: 'vinyl-red', name: 'Red', hex: '#B22234', category: 'vinyl', available: true },
      { id: 'vinyl-blue', name: 'Blue', hex: '#1E4D8C', category: 'vinyl', available: true },
      { id: 'vinyl-sage', name: 'Sage', hex: '#9CAF88', category: 'vinyl', available: true },
      { id: 'vinyl-khaki', name: 'Khaki', hex: '#C3B091', category: 'vinyl', available: true },
      { id: 'vinyl-sandstone', name: 'Sandstone', hex: '#C3B091', category: 'vinyl', available: true },
      { id: 'vinyl-tan', name: 'Tan', hex: '#D2B48C', category: 'vinyl', available: true }
    ]
  },
  {
    id: 'trim',
    name: 'Trim Colors',
    description: 'Accent your structure with our selection of trim colors.',
    options: [
      { id: 'trim-black', name: 'Black', hex: '#000000', category: 'trim', available: true, popular: true },
      { id: 'trim-blue', name: 'Blue', hex: '#1E4D8C', category: 'trim', available: true },
      { id: 'trim-clay', name: 'Clay', hex: '#C4A484', category: 'trim', available: true },
      { id: 'trim-cream', name: 'Cream', hex: '#FFFDD0', category: 'trim', available: true },
      { id: 'trim-dark-brown', name: 'Dark Brown', hex: '#5C4033', category: 'trim', available: true },
      { id: 'trim-dark-gray', name: 'Dark Gray', hex: '#4A4A4A', category: 'trim', available: true },
      { id: 'trim-hunter-green', name: 'Hunter Green', hex: '#355E3B', category: 'trim', available: true },
      { id: 'trim-light-gray', name: 'Light Gray', hex: '#9B9B9B', category: 'trim', available: true },
      { id: 'trim-pearl', name: 'Pearl', hex: '#F0EAD6', category: 'trim', available: true },
      { id: 'trim-red', name: 'Red', hex: '#B22234', category: 'trim', available: true }
    ]
  },
  {
    id: 'shingle',
    name: 'Shingle Colors',
    description: 'High-quality architectural shingles in a variety of colors.',
    options: [
      { id: 'shingle-blue', name: 'Blue', hex: '#1E4D8C', category: 'shingle', available: true },
      { id: 'shingle-dark-gray', name: 'Dark Gray', hex: '#4A4A4A', category: 'shingle', available: true, popular: true },
      { id: 'shingle-black', name: 'Black', hex: '#000000', category: 'shingle', available: true, popular: true },
      { id: 'shingle-dark-brown', name: 'Dark Brown', hex: '#5C4033', category: 'shingle', available: true },
      { id: 'shingle-light-gray', name: 'Light Gray', hex: '#9B9B9B', category: 'shingle', available: true },
      { id: 'shingle-light-brown', name: 'Light Brown', hex: '#996633', category: 'shingle', available: true },
      { id: 'shingle-dark-green', name: 'Dark Green', hex: '#2B5329', category: 'shingle', available: true },
      { id: 'shingle-weatherwood', name: 'Weatherwood', hex: '#7A7A7A', category: 'shingle', available: true, popular: true }
    ]
  },
  {
    id: 'stain',
    name: 'Stain Colors',
    description: 'Natural wood stains that protect while enhancing the beauty of the wood.',
    options: [
      { id: 'stain-barnwood', name: 'Barnwood', hex: '#8B7355', category: 'stain', available: true },
      { id: 'stain-butternut', name: 'Butternut', hex: '#CD853F', category: 'stain', available: true },
      { id: 'stain-charcoal', name: 'Charcoal', hex: '#36454F', category: 'stain', available: true },
      { id: 'stain-chestnut-brown', name: 'Chestnut Brown', hex: '#954535', category: 'stain', available: true },
      { id: 'stain-golden-wheat', name: 'Golden Wheat', hex: '#DAA520', category: 'stain', available: true },
      { id: 'stain-mahogany', name: 'Mahogany', hex: '#C04000', category: 'stain', available: true },
      { id: 'stain-natural-cedar', name: 'Natural Cedar', hex: '#D27D2D', category: 'stain', available: true },
      { id: 'stain-natural-redwood', name: 'Natural Redwood', hex: '#8B4513', category: 'stain', available: true },
      { id: 'stain-natural-teak', name: 'Natural Teak', hex: '#996633', category: 'stain', available: true },
      { id: 'stain-sage', name: 'Sage', hex: '#9CAF88', category: 'stain', available: true }
    ]
  },
  {
    id: 'metal',
    name: 'Ribbed Metal Roofing Colors',
    description: 'Durable metal roofing options with superior weather protection.',
    options: [
      { id: 'metal-bright-white', name: 'Bright White', hex: '#FFFFFF', category: 'metal', available: true },
      { id: 'metal-polar-white', name: 'Polar White', hex: '#F5F5F5', category: 'metal', available: true },
      { id: 'metal-light-stone', name: 'Light Stone', hex: '#D3D3D3', category: 'metal', available: true },
      { id: 'metal-ivory', name: 'Ivory', hex: '#FFFFF0', category: 'metal', available: true },
      { id: 'metal-clay', name: 'Clay', hex: '#C4A484', category: 'metal', available: true },
      { id: 'metal-tan', name: 'Tan', hex: '#D2B48C', category: 'metal', available: true },
      { id: 'metal-ash-gray', name: 'Ash Gray', hex: '#B2BEB5', category: 'metal', available: true },
      { id: 'metal-pewter-gray', name: 'Pewter Gray', hex: '#8E8E90', category: 'metal', available: true },
      { id: 'metal-charcoal', name: 'Charcoal', hex: '#36454F', category: 'metal', available: true },
      { id: 'metal-burnished-slate', name: 'Burnished Slate', hex: '#4A4E4D', category: 'metal', available: true },
      { id: 'metal-brown', name: 'Brown', hex: '#5C4033', category: 'metal', available: true },
      { id: 'metal-burgundy', name: 'Burgundy', hex: '#800020', category: 'metal', available: true },
      { id: 'metal-rural-red', name: 'Rural Red', hex: '#B22234', category: 'metal', available: true },
      { id: 'metal-bright-red', name: 'Bright Red', hex: '#FF0000', category: 'metal', available: true },
      { id: 'metal-evergreen', name: 'Evergreen', hex: '#2B5329', category: 'metal', available: true },
      { id: 'metal-ivy-green', name: 'Ivy Green', hex: '#3F704D', category: 'metal', available: true },
      { id: 'metal-copper', name: 'Copper Metallic', hex: '#B87333', category: 'metal', available: true },
      { id: 'metal-gallery-blue', name: 'Gallery Blue', hex: '#1E4D8C', category: 'metal', available: true },
      { id: 'metal-ocean-blue', name: 'Ocean Blue', hex: '#4F42B5', category: 'metal', available: true },
      { id: 'metal-black', name: 'Black', hex: '#000000', category: 'metal', available: true }
    ]
  }
];

export const getColorsByCategory = (category: string): ColorOption[] => {
  const categoryData = colorCategories.find(cat => cat.id === category);
  return categoryData?.options || [];
};

export const getPopularColors = (): ColorOption[] => {
  return colorCategories.flatMap(category => 
    category.options.filter(option => option.popular)
  );
};