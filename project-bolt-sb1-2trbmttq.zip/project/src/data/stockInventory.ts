import { StockInventoryItem } from '../types';

export const stockInventory: StockInventoryItem[] = [
  {
    modelNumber: '3152',
    type: 'shed',
    name: 'Transom Dormer',
    description: 'Elegant Transom Dormer with premium features and classic styling.',
    specifications: {
      size: '12x20',
      material: 'Wood LP SmartSide',
      sidingColor: 'White',
      trimColor: 'White',
      roofColor: 'Black',
      additionalFeatures: ['Transom Windows', 'Dormer Design', 'Premium Construction']
    },
    pricing: {
      retailPrice: 7655,
      rentToOwn: {
        monthlyPayment: 352.76,
        term: 36
      }
    },
    status: 'available',
    location: 'Main Showroom',
    images: [
      {
        url: 'https://images.pexels.com/photos/259588/pexels-photo-259588.jpeg',
        alt: 'Transom Dormer',
        isPrimary: true,
        caption: 'Transom Dormer with White Finish'
      }
    ],
    createdAt: '2024-03-20T00:00:00Z',
    updatedAt: '2024-03-20T00:00:00Z',
    featured: true
  },
  {
    modelNumber: '3152A',
    type: 'shed',
    name: 'A-Frame Classic Workshop',
    description: 'Spacious A-Frame Classic Workshop perfect for all your needs.',
    specifications: {
      size: '10x20',
      material: 'Wood LP SmartSide',
      sidingColor: 'White',
      trimColor: 'White',
      roofColor: 'Black Metal',
      additionalFeatures: ['A-Frame Design', 'Workshop Layout', 'Metal Roofing']
    },
    pricing: {
      retailPrice: 9955,
      rentToOwn: {
        monthlyPayment: 458.76,
        term: 36
      }
    },
    status: 'available',
    location: 'Main Showroom',
    images: [
      {
        url: 'https://images.pexels.com/photos/273843/pexels-photo-273843.jpeg',
        alt: 'A-Frame Classic Workshop',
        isPrimary: true,
        caption: 'A-Frame Classic Workshop with Metal Roof'
      }
    ],
    createdAt: '2024-03-20T00:00:00Z',
    updatedAt: '2024-03-20T00:00:00Z'
  },
  {
    modelNumber: '3115',
    type: 'shed',
    name: 'A-Frame Workshop',
    description: 'Versatile A-Frame Workshop with modern features.',
    specifications: {
      size: '10x16',
      material: 'Wood LP SmartSide',
      sidingColor: 'Dark Gray',
      trimColor: 'White',
      roofColor: 'Charcoal Gray',
      additionalFeatures: ['A-Frame Design', 'Workshop Space']
    },
    pricing: {
      retailPrice: 4025,
      rentToOwn: {
        monthlyPayment: 185.48,
        term: 36
      },
      discount: {
        amount: 500,
        percentage: 12.4,
        reason: 'Spring Sale'
      }
    },
    status: 'available',
    location: 'Main Showroom',
    images: [
      {
        url: 'https://images.pexels.com/photos/273843/pexels-photo-273843.jpeg',
        alt: 'A-Frame Workshop',
        isPrimary: true,
        caption: 'A-Frame Workshop in Dark Gray'
      }
    ],
    createdAt: '2024-03-20T00:00:00Z',
    updatedAt: '2024-03-20T00:00:00Z'
  },
  {
    modelNumber: '3067',
    type: 'shed',
    name: 'Hi Wall Barn',
    description: 'Spacious Hi Wall Barn with increased headroom and storage capacity.',
    specifications: {
      size: '12x20',
      material: 'Wood LP SmartSide',
      sidingColor: 'Red',
      trimColor: 'Black',
      roofColor: 'Black',
      additionalFeatures: ['High Walls', 'Increased Storage']
    },
    pricing: {
      retailPrice: 5690,
      rentToOwn: {
        monthlyPayment: 262.21,
        term: 36
      }
    },
    status: 'available',
    location: 'Main Showroom',
    images: [
      {
        url: 'https://images.pexels.com/photos/259588/pexels-photo-259588.jpeg',
        alt: 'Hi Wall Barn',
        isPrimary: true,
        caption: 'Hi Wall Barn in Classic Red'
      }
    ],
    createdAt: '2024-03-20T00:00:00Z',
    updatedAt: '2024-03-20T00:00:00Z'
  },
  {
    modelNumber: '3055',
    type: 'greenhouse',
    name: 'A-Frame Greenhouse',
    description: 'Custom A-Frame Greenhouse perfect for year-round growing.',
    specifications: {
      size: '8x12',
      material: 'Wood LP SmartSide',
      sidingColor: 'White',
      trimColor: 'White',
      roofColor: 'Translucent',
      additionalFeatures: ['Translucent Roof', 'Ventilation System']
    },
    pricing: {
      retailPrice: 4520,
      rentToOwn: {
        monthlyPayment: 208.29,
        term: 36
      }
    },
    status: 'available',
    location: 'Garden Center',
    images: [
      {
        url: 'https://images.pexels.com/photos/2219941/pexels-photo-2219941.jpeg',
        alt: 'A-Frame Greenhouse',
        isPrimary: true,
        caption: 'A-Frame Greenhouse with Translucent Roof'
      }
    ],
    createdAt: '2024-03-20T00:00:00Z',
    updatedAt: '2024-03-20T00:00:00Z'
  },
  {
    modelNumber: '2728',
    type: 'shed',
    name: 'Hi Wall Barn',
    description: 'Classic Hi Wall Barn with traditional styling.',
    specifications: {
      size: '10x16',
      material: 'Wood LP SmartSide',
      sidingColor: 'White',
      trimColor: 'Black',
      roofColor: 'Black',
      additionalFeatures: ['High Walls', 'Traditional Design']
    },
    pricing: {
      retailPrice: 4270,
      rentToOwn: {
        monthlyPayment: 196.77,
        term: 36
      }
    },
    status: 'sold',
    location: 'Main Showroom',
    images: [
      {
        url: 'https://images.pexels.com/photos/259588/pexels-photo-259588.jpeg',
        alt: 'Hi Wall Barn',
        isPrimary: true,
        caption: 'Hi Wall Barn in White'
      }
    ],
    createdAt: '2024-03-20T00:00:00Z',
    updatedAt: '2024-03-20T00:00:00Z'
  },
  {
    modelNumber: '3094',
    type: 'shed',
    name: 'A-Frame Workshop',
    description: 'Spacious A-Frame Workshop with modern amenities.',
    specifications: {
      size: '12x16',
      material: 'Wood LP SmartSide',
      sidingColor: 'Dark Gray',
      trimColor: 'White',
      roofColor: 'Black',
      additionalFeatures: ['A-Frame Design', 'Workshop Layout']
    },
    pricing: {
      retailPrice: 4720,
      rentToOwn: {
        monthlyPayment: 217.51,
        term: 36
      }
    },
    status: 'sold',
    location: 'Main Showroom',
    images: [
      {
        url: 'https://images.pexels.com/photos/273843/pexels-photo-273843.jpeg',
        alt: 'A-Frame Workshop',
        isPrimary: true,
        caption: 'A-Frame Workshop in Dark Gray'
      }
    ],
    createdAt: '2024-03-20T00:00:00Z',
    updatedAt: '2024-03-20T00:00:00Z'
  },
  {
    modelNumber: '3100',
    type: 'shed',
    name: 'A-Frame Workshop',
    description: 'Compact A-Frame Workshop perfect for small spaces.',
    specifications: {
      size: '8x12',
      material: 'Wood LP SmartSide',
      sidingColor: 'Linen',
      trimColor: 'Bronze',
      roofColor: 'Black',
      additionalFeatures: ['A-Frame Design', 'Compact Size']
    },
    pricing: {
      retailPrice: 3495,
      rentToOwn: {
        monthlyPayment: 161.06,
        term: 36
      }
    },
    status: 'sold',
    location: 'Main Showroom',
    images: [
      {
        url: 'https://images.pexels.com/photos/273843/pexels-photo-273843.jpeg',
        alt: 'A-Frame Workshop',
        isPrimary: true,
        caption: 'A-Frame Workshop in Linen'
      }
    ],
    createdAt: '2024-03-20T00:00:00Z',
    updatedAt: '2024-03-20T00:00:00Z'
  },
  {
    modelNumber: '3089',
    type: 'shed',
    name: 'Mini Barn',
    description: 'Classic Mini Barn with traditional styling.',
    specifications: {
      size: '10x14',
      material: 'Wood LP SmartSide',
      sidingColor: 'Bronze',
      trimColor: 'Red',
      roofColor: 'Black',
      additionalFeatures: ['Traditional Design', 'Compact Storage']
    },
    pricing: {
      retailPrice: 3480,
      rentToOwn: {
        monthlyPayment: 160.37,
        term: 36
      }
    },
    status: 'available',
    location: 'Main Showroom',
    images: [
      {
        url: 'https://images.pexels.com/photos/259588/pexels-photo-259588.jpeg',
        alt: 'Mini Barn',
        isPrimary: true,
        caption: 'Mini Barn in Bronze with Red Trim'
      }
    ],
    createdAt: '2024-03-20T00:00:00Z',
    updatedAt: '2024-03-20T00:00:00Z'
  },
  {
    modelNumber: '3005',
    type: 'shed',
    name: 'A-Frame Workshop',
    description: 'Spacious A-Frame Workshop with clean design.',
    specifications: {
      size: '12x18',
      material: 'Wood LP SmartSide',
      sidingColor: 'White',
      trimColor: 'White',
      roofColor: 'Black',
      additionalFeatures: ['A-Frame Design', 'Workshop Space']
    },
    pricing: {
      retailPrice: 4535,
      rentToOwn: {
        monthlyPayment: 208.99,
        term: 36
      }
    },
    status: 'sold',
    location: 'Main Showroom',
    images: [
      {
        url: 'https://images.pexels.com/photos/273843/pexels-photo-273843.jpeg',
        alt: 'A-Frame Workshop',
        isPrimary: true,
        caption: 'A-Frame Workshop in White'
      }
    ],
    createdAt: '2024-03-20T00:00:00Z',
    updatedAt: '2024-03-20T00:00:00Z'
  },
  {
    modelNumber: '3059',
    type: 'shed',
    name: 'Quaker',
    description: 'Classic Quaker style shed with elegant design.',
    specifications: {
      size: '8x12',
      material: 'Wood LP SmartSide',
      sidingColor: 'Light Gray',
      trimColor: 'White',
      roofColor: 'Charcoal Gray',
      additionalFeatures: ['Quaker Style', 'Elegant Design']
    },
    pricing: {
      retailPrice: 2895,
      rentToOwn: {
        monthlyPayment: 133.41,
        term: 36
      }
    },
    status: 'sold',
    location: 'Main Showroom',
    images: [
      {
        url: 'https://images.pexels.com/photos/280222/pexels-photo-280222.jpeg',
        alt: 'Quaker Shed',
        isPrimary: true,
        caption: 'Quaker Shed in Light Gray'
      }
    ],
    createdAt: '2024-03-20T00:00:00Z',
    updatedAt: '2024-03-20T00:00:00Z'
  },
  {
    modelNumber: '2746',
    type: 'shed',
    name: 'Classic Quaker',
    description: 'Traditional Classic Quaker with premium features.',
    specifications: {
      size: '10x14',
      material: 'Wood LP SmartSide',
      sidingColor: 'White',
      trimColor: 'White',
      roofColor: 'Copper Penny',
      additionalFeatures: ['Classic Design', 'Premium Features']
    },
    pricing: {
      retailPrice: 5180,
      rentToOwn: {
        monthlyPayment: 238.71,
        term: 36
      }
    },
    status: 'sold',
    location: 'Main Showroom',
    images: [
      {
        url: 'https://images.pexels.com/photos/280222/pexels-photo-280222.jpeg',
        alt: 'Classic Quaker',
        isPrimary: true,
        caption: 'Classic Quaker with Copper Penny Roof'
      }
    ],
    createdAt: '2024-03-20T00:00:00Z',
    updatedAt: '2024-03-20T00:00:00Z'
  },
  {
    modelNumber: '3025',
    type: 'shed',
    name: 'Quaker',
    description: 'Modern Quaker shed with traditional elements.',
    specifications: {
      size: '10x12',
      material: 'Wood LP SmartSide',
      sidingColor: 'Blue',
      trimColor: 'White',
      roofColor: 'Black',
      additionalFeatures: ['Quaker Style', 'Modern Features']
    },
    pricing: {
      retailPrice: 3300,
      rentToOwn: {
        monthlyPayment: 152.07,
        term: 36
      }
    },
    status: 'sold',
    location: 'Main Showroom',
    images: [
      {
        url: 'https://images.pexels.com/photos/280222/pexels-photo-280222.jpeg',
        alt: 'Quaker Shed',
        isPrimary: true,
        caption: 'Quaker Shed in Blue'
      }
    ],
    createdAt: '2024-03-20T00:00:00Z',
    updatedAt: '2024-03-20T00:00:00Z'
  },
  {
    modelNumber: '3092',
    type: 'shed',
    name: 'A-Frame Workshop',
    description: 'Vinyl-sided A-Frame Workshop with modern features.',
    specifications: {
      size: '8x12',
      material: 'Vinyl Sided',
      sidingColor: 'White',
      trimColor: 'Black',
      roofColor: 'Black',
      additionalFeatures: ['A-Frame Design', 'Vinyl Siding']
    },
    pricing: {
      retailPrice: 3515,
      rentToOwn: {
        monthlyPayment: 161.98,
        term: 36
      }
    },
    status: 'available',
    location: 'Main Showroom',
    images: [
      {
        url: 'https://images.pexels.com/photos/273843/pexels-photo-273843.jpeg',
        alt: 'A-Frame Workshop',
        isPrimary: true,
        caption: 'Vinyl-sided A-Frame Workshop'
      }
    ],
    createdAt: '2024-03-20T00:00:00Z',
    updatedAt: '2024-03-20T00:00:00Z'
  },
  {
    modelNumber: '3109',
    type: 'shed',
    name: 'A-Frame Workshop',
    description: 'Vinyl-sided A-Frame Workshop with spacious design.',
    specifications: {
      size: '10x14',
      material: 'Vinyl Sided',
      sidingColor: 'White',
      trimColor: 'Black',
      roofColor: 'Black',
      additionalFeatures: ['A-Frame Design', 'Vinyl Siding']
    },
    pricing: {
      retailPrice: 4705,
      rentToOwn: {
        monthlyPayment: 216.82,
        term: 36
      }
    },
    status: 'sold',
    location: 'Main Showroom',
    images: [
      {
        url: 'https://images.pexels.com/photos/273843/pexels-photo-273843.jpeg',
        alt: 'A-Frame Workshop',
        isPrimary: true,
        caption: 'Vinyl-sided A-Frame Workshop'
      }
    ],
    createdAt: '2024-03-20T00:00:00Z',
    updatedAt: '2024-03-20T00:00:00Z'
  },
  {
    modelNumber: '3024',
    type: 'shed',
    name: 'Hi Wall Barn',
    description: 'Spacious Hi Wall Barn with modern styling.',
    specifications: {
      size: '10x20',
      material: 'Wood LP SmartSide',
      sidingColor: 'Clay',
      trimColor: 'Clay',
      roofColor: 'Black',
      additionalFeatures: ['High Walls', 'Modern Design']
    },
    pricing: {
      retailPrice: 4835,
      rentToOwn: {
        monthlyPayment: 222.81,
        term: 36
      }
    },
    status: 'available',
    location: 'Main Showroom',
    images: [
      {
        url: 'https://images.pexels.com/photos/259588/pexels-photo-259588.jpeg',
        alt: 'Hi Wall Barn',
        isPrimary: true,
        caption: 'Hi Wall Barn in Clay'
      }
    ],
    createdAt: '2024-03-20T00:00:00Z',
    updatedAt: '2024-03-20T00:00:00Z'
  },
  {
    modelNumber: '3087',
    type: 'shed',
    name: 'A-Frame Workshop',
    description: 'Large A-Frame Workshop with premium features.',
    specifications: {
      size: '10x20',
      material: 'Wood LP SmartSide',
      sidingColor: 'Linen',
      trimColor: 'Black',
      roofColor: 'Black',
      additionalFeatures: ['A-Frame Design', 'Spacious Interior']
    },
    pricing: {
      retailPrice: 4430,
      rentToOwn: {
        monthlyPayment: 204.15,
        term: 36
      }
    },
    status: 'available',
    location: 'Main Showroom',
    images: [
      {
        url: 'https://images.pexels.com/photos/273843/pexels-photo-273843.jpeg',
        alt: 'A-Frame Workshop',
        isPrimary: true,
        caption: 'A-Frame Workshop in Linen'
      }
    ],
    createdAt: '2024-03-20T00:00:00Z',
    updatedAt: '2024-03-20T00:00:00Z'
  },
  {
    modelNumber: '3114',
    type: 'shed',
    name: 'Classic A-Frame Workshop',
    description: 'Premium Classic A-Frame Workshop with vinyl siding.',
    specifications: {
      size: '10x20',
      material: 'Vinyl Sided',
      sidingColor: 'Misty Shadow',
      trimColor: 'White',
      roofColor: 'Black',
      additionalFeatures: ['Classic Design', 'Vinyl Siding']
    },
    pricing: {
      retailPrice: 7665,
      rentToOwn: {
        monthlyPayment: 353.23,
        term: 36
      }
    },
    status: 'available',
    location: 'Main Showroom',
    images: [
      {
        url: 'https://images.pexels.com/photos/273843/pexels-photo-273843.jpeg',
        alt: 'Classic A-Frame Workshop',
        isPrimary: true,
        caption: 'Classic A-Frame Workshop in Misty Shadow'
      }
    ],
    createdAt: '2024-03-20T00:00:00Z',
    updatedAt: '2024-03-20T00:00:00Z'
  },
  {
    modelNumber: '3061',
    type: 'shed',
    name: 'Classic Quaker',
    description: 'Traditional Classic Quaker with bronze finish.',
    specifications: {
      size: '10x16',
      material: 'Wood LP SmartSide',
      sidingColor: 'Bronze',
      trimColor: 'White',
      roofColor: 'Black',
      additionalFeatures: ['Classic Design', 'Traditional Style']
    },
    pricing: {
      retailPrice: 5125,
      rentToOwn: {
        monthlyPayment: 236.18,
        term: 36
      }
    },
    status: 'available',
    location: 'Main Showroom',
    images: [
      {
        url: 'https://images.pexels.com/photos/280222/pexels-photo-280222.jpeg',
        alt: 'Classic Quaker',
        isPrimary: true,
        caption: 'Classic Quaker in Bronze'
      }
    ],
    createdAt: '2024-03-20T00:00:00Z',
    updatedAt: '2024-03-20T00:00:00Z'
  },
  {
    modelNumber: '3090',
    type: 'shed',
    name: 'A-Frame Dormer',
    description: 'Compact A-Frame Dormer with modern styling.',
    specifications: {
      size: '8x12',
      material: 'Wood LP SmartSide',
      sidingColor: 'Clay',
      trimColor: 'Black',
      roofColor: 'Black',
      additionalFeatures: ['Dormer Design', 'A-Frame Style']
    },
    pricing: {
      retailPrice: 3850,
      rentToOwn: {
        monthlyPayment: 177.42,
        term: 36
      }
    },
    status: 'available',
    location: 'Main Showroom',
    images: [
      {
        url: 'https://images.pexels.com/photos/273843/pexels-photo-273843.jpeg',
        alt: 'A-Frame Dormer',
        isPrimary: true,
        caption: 'A-Frame Dormer in Clay'
      }
    ],
    createdAt: '2024-03-20T00:00:00Z',
    updatedAt: '2024-03-20T00:00:00Z'
  }
];

export const getStockItemByModelNumber = (modelNumber: string): StockInventoryItem | undefined => {
  return stockInventory.find(item => item.modelNumber === modelNumber);
};

export const getStockItemsByType = (type: string): StockInventoryItem[] => {
  return stockInventory.filter(item => item.type === type);
};

export const getAvailableStockItems = (): StockInventoryItem[] => {
  return stockInventory.filter(item => item.status === 'available');
};

export const getDiscountedStockItems = (): StockInventoryItem[] => {
  return stockInventory.filter(item => item.pricing.discount !== undefined);
};

export const getFeaturedItems = (): StockInventoryItem[] => {
  return stockInventory.filter(item => item.featured);
};

export const calculateDiscountedPrice = (item: StockInventoryItem): number => {
  if (!item.pricing.discount) return item.pricing.retailPrice;
  return item.pricing.retailPrice - item.pricing.discount.amount;
};

export const getStockItemsByPriceRange = (minPrice: number, maxPrice: number): StockInventoryItem[] => {
  return stockInventory.filter(item => {
    const price = calculateDiscountedPrice(item);
    return price >= minPrice && price <= maxPrice;
  });
};

export const getStockItemsByLocation = (location: string): StockInventoryItem[] => {
  return stockInventory.filter(item => item.location === location);
};

export const searchStockItems = (searchTerm: string): StockInventoryItem[] => {
  const term = searchTerm.toLowerCase();
  return stockInventory.filter(item => 
    item.name.toLowerCase().includes(term) ||
    item.description.toLowerCase().includes(term) ||
    item.modelNumber.toLowerCase().includes(term) ||
    item.specifications.additionalFeatures?.some(feature => 
      feature.toLowerCase().includes(term)
    )
  );
};

export const sortStockItems = (
  items: StockInventoryItem[],
  sortBy: 'price-asc' | 'price-desc' | 'newest' | 'name'
): StockInventoryItem[] => {
  const sortedItems = [...items];
  
  switch (sortBy) {
    case 'price-asc':
      return sortedItems.sort((a, b) => calculateDiscountedPrice(a) - calculateDiscountedPrice(b));
    case 'price-desc':
      return sortedItems.sort((a, b) => calculateDiscountedPrice(b) - calculateDiscountedPrice(a));
    case 'newest':
      return sortedItems.sort((a, b) => 
        new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      );
    case 'name':
      return sortedItems.sort((a, b) => a.name.localeCompare(b.name));
    default:
      return sortedItems;
  }
};

export const getRelatedStockItems = (item: StockInventoryItem, limit = 3): StockInventoryItem[] => {
  return stockInventory
    .filter(related => 
      related.modelNumber !== item.modelNumber && // Exclude current item
      (related.type === item.type || // Same type
       related.specifications.size === item.specifications.size) // Same size
    )
    .slice(0, limit);
};

export const getStockItemStats = () => {
  return {
    total: stockInventory.length,
    available: stockInventory.filter(item => item.status === 'available').length,
    sold: stockInventory.filter(item => item.status === 'sold').length,
    discounted: stockInventory.filter(item => item.pricing.discount).length,
    averagePrice: stockInventory.reduce((sum, item) => sum + item.pricing.retailPrice, 0) / stockInventory.length
  };
};