import { Structure } from '../types';

export const shedStructures: Structure[] = [
  {
    id: 'mini-barn',
    type: 'shed',
    name: 'Mini Barn',
    description: 'Classic barn-style storage solution with traditional charm. Perfect for garden tools, lawn equipment, and general storage needs.',
    features: [
      'Classic barn-style roof design',
      'Double doors with heavy-duty hinges',
      'Pressure-treated floor joists',
      'LP SmartSide siding with 50-year warranty',
      'Architectural shingles',
      'Aluminum threshold',
      'Weather-tight construction',
      'Optional loft storage'
    ],
    basePrice: 2999,
    minSize: '8x8',
    maxSize: '14x40',
    imageUrl: 'https://structures.b-cdn.net/mini-barn.jpg?width=900&height=675&quality=80&format=webp',
    options: [
      {
        id: 'size-upgrade',
        name: 'Size Upgrade',
        description: 'Increase storage space with larger dimensions',
        priceModifier: 500,
        type: 'size'
      },
      {
        id: 'loft',
        name: 'Storage Loft',
        description: 'Additional overhead storage space',
        priceModifier: 300,
        type: 'feature'
      },
      {
        id: 'windows',
        name: 'Additional Windows',
        description: 'Add natural light with extra windows',
        priceModifier: 200,
        type: 'feature'
      }
    ],
    gallery: [
      {
        url: 'https://structures.b-cdn.net/mini-barn-1.jpg?width=900&height=675&quality=80&format=webp',
        alt: 'Mini Barn Front View',
        caption: 'Classic Mini Barn Design'
      },
      {
        url: 'https://structures.b-cdn.net/mini-barn-2.jpg?width=900&height=675&quality=80&format=webp',
        alt: 'Mini Barn Interior',
        caption: 'Spacious Interior Storage'
      }
    ]
  },
  {
    id: 'hi-wall-barn',
    type: 'shed',
    name: 'Hi Wall Barn',
    description: 'Extra height walls provide maximum storage capacity and improved headroom. Perfect for storing tall items and creating workspace.',
    features: [
      'Higher sidewalls for maximum storage',
      'Reinforced door frame',
      'Premium grade lumber construction',
      'Moisture-resistant flooring',
      'Superior ventilation system',
      'Optional workbench package',
      'Customizable door placement',
      'Enhanced storage capabilities'
    ],
    basePrice: 3499,
    minSize: '8x10',
    maxSize: '14x40',
    imageUrl: 'https://structures.b-cdn.net/hi-wall-barn.jpg?width=900&height=675&quality=80&format=webp',
    options: [
      {
        id: 'size-upgrade',
        name: 'Size Upgrade',
        description: 'Increase storage space with larger dimensions',
        priceModifier: 600,
        type: 'size'
      },
      {
        id: 'workbench',
        name: 'Built-in Workbench',
        description: 'Custom workbench with storage',
        priceModifier: 400,
        type: 'feature'
      },
      {
        id: 'electrical',
        name: 'Electrical Package',
        description: 'Pre-wired for electricity',
        priceModifier: 800,
        type: 'feature'
      }
    ],
    gallery: [
      {
        url: 'https://structures.b-cdn.net/hi-wall-barn-1.jpg?width=900&height=675&quality=80&format=webp',
        alt: 'Hi Wall Barn Exterior',
        caption: 'Spacious Hi Wall Design'
      }
    ]
  },
  {
    id: 'quaker',
    type: 'shed',
    name: 'Quaker',
    description: 'Elegant design with distinctive roof overhang and superior craftsmanship. Perfect blend of style and functionality.',
    features: [
      'Signature roof overhang',
      'Premium door hardware',
      'Decorative shutters',
      'Enhanced curb appeal',
      'Superior weather protection',
      'Custom paint options',
      'Optional cupola',
      'Lifetime warranty on hardware'
    ],
    basePrice: 3999,
    minSize: '8x10',
    maxSize: '14x40',
    imageUrl: 'https://structures.b-cdn.net/quaker.jpg?width=900&height=675&quality=80&format=webp',
    options: [
      {
        id: 'cupola',
        name: 'Decorative Cupola',
        description: 'Add classic styling with a cupola',
        priceModifier: 350,
        type: 'feature'
      },
      {
        id: 'flower-boxes',
        name: 'Window Flower Boxes',
        description: 'Add charm with custom flower boxes',
        priceModifier: 200,
        type: 'feature'
      }
    ],
    gallery: [
      {
        url: 'https://structures.b-cdn.net/quaker-1.jpg?width=900&height=675&quality=80&format=webp',
        alt: 'Quaker Style Shed',
        caption: 'Classic Quaker Design'
      }
    ]
  },
  {
    id: 'dutch-barn',
    type: 'shed',
    name: 'Dutch Barn',
    description: 'Maximize storage with gambrel roof design providing spacious loft area. Perfect for both storage and workspace needs.',
    features: [
      'Gambrel roof design',
      'Built-in loft storage',
      'Heavy-duty floor system',
      'Premium siding options',
      'Customizable door placement',
      'Enhanced headroom',
      'Weather-resistant construction',
      'Optional skylights'
    ],
    basePrice: 4299,
    minSize: '10x12',
    maxSize: '14x40',
    imageUrl: 'https://structures.b-cdn.net/dutch-barn.jpg?width=900&height=675&quality=80&format=webp',
    options: [
      {
        id: 'dormer',
        name: 'Dormer Package',
        description: 'Add style and light with dormers',
        priceModifier: 800,
        type: 'feature'
      },
      {
        id: 'ramp',
        name: 'Heavy-Duty Ramp',
        description: 'Easy access for equipment',
        priceModifier: 300,
        type: 'feature'
      }
    ],
    gallery: [
      {
        url: 'https://structures.b-cdn.net/dutch-barn-1.jpg?width=900&height=675&quality=80&format=webp',
        alt: 'Dutch Barn Style',
        caption: 'Spacious Dutch Barn Design'
      }
    ]
  },
  {
    id: 'workshop',
    type: 'shed',
    name: 'Workshop',
    description: 'Purpose-built for projects and hobbies with enhanced lighting and ventilation. Ideal for craftsmen and DIY enthusiasts.',
    features: [
      'Enhanced lighting package',
      'Superior ventilation',
      'Reinforced flooring',
      'Workbench ready design',
      'Tool organization system',
      'Electrical conduit ready',
      'Insulation package available',
      'Heavy-duty door hardware'
    ],
    basePrice: 4999,
    minSize: '10x12',
    maxSize: '16x40',
    imageUrl: 'https://structures.b-cdn.net/workshop.jpg?width=900&height=675&quality=80&format=webp',
    options: [
      {
        id: 'insulation',
        name: 'Full Insulation Package',
        description: 'Year-round comfort',
        priceModifier: 1200,
        type: 'feature'
      },
      {
        id: 'tool-wall',
        name: 'Tool Organization System',
        description: 'Custom tool storage solution',
        priceModifier: 500,
        type: 'feature'
      }
    ],
    gallery: [
      {
        url: 'https://structures.b-cdn.net/workshop-1.jpg?width=900&height=675&quality=80&format=webp',
        alt: 'Workshop Interior',
        caption: 'Professional Workshop Setup'
      }
    ]
  },
  {
    id: 'classic-workshop',
    type: 'shed',
    name: 'Classic Workshop',
    description: 'Traditional styling meets modern functionality. Perfect for creating a dedicated workspace with classic appeal.',
    features: [
      'Traditional design elements',
      'Enhanced door width',
      'Premium window package',
      'Heavy-duty construction',
      'Custom workbench options',
      'Superior ventilation',
      'Moisture resistant flooring',
      'Lifetime warranty'
    ],
    basePrice: 5499,
    minSize: '12x16',
    maxSize: '16x40',
    imageUrl: 'https://structures.b-cdn.net/classic-workshop.jpg?width=900&height=675&quality=80&format=webp',
    options: [
      {
        id: 'premium-windows',
        name: 'Premium Window Package',
        description: 'Additional natural lighting',
        priceModifier: 800,
        type: 'feature'
      },
      {
        id: 'custom-shelving',
        name: 'Custom Shelving System',
        description: 'Built-in storage solution',
        priceModifier: 600,
        type: 'feature'
      }
    ],
    gallery: [
      {
        url: 'https://structures.b-cdn.net/classic-workshop-1.jpg?width=900&height=675&quality=80&format=webp',
        alt: 'Classic Workshop',
        caption: 'Traditional Workshop Design'
      }
    ]
  },
  {
    id: 'classic-quaker',
    type: 'shed',
    name: 'Classic Quaker',
    description: 'Our premium Quaker model with enhanced features and superior finishes. The perfect blend of elegance and durability.',
    features: [
      'Premium trim package',
      'Enhanced roof overhang',
      'Custom window designs',
      'Superior hardware',
      'Decorative accents',
      'Weather-tight construction',
      'Extended warranty',
      'Professional installation'
    ],
    basePrice: 5999,
    minSize: '10x12',
    maxSize: '14x40',
    imageUrl: 'https://structures.b-cdn.net/classic-quaker.jpg?width=900&height=675&quality=80&format=webp',
    options: [
      {
        id: 'transom-windows',
        name: 'Transom Windows',
        description: 'Add elegance with transom windows',
        priceModifier: 900,
        type: 'feature'
      },
      {
        id: 'premium-trim',
        name: 'Premium Trim Package',
        description: 'Enhanced exterior details',
        priceModifier: 700,
        type: 'feature'
      }
    ],
    gallery: [
      {
        url: 'https://structures.b-cdn.net/classic-quaker-1.jpg?width=900&height=675&quality=80&format=webp',
        alt: 'Classic Quaker',
        caption: 'Premium Quaker Design'
      }
    ]
  }
];

export const garageStructures: Structure[] = [
  {
    id: 'workshop-garage',
    type: 'garage',
    name: 'Workshop Garage',
    description: 'Versatile garage space with dedicated workshop area. Perfect for vehicle storage and DIY projects.',
    features: [
      'Reinforced concrete foundation',
      'Heavy-duty floor system',
      'Insulated walls and ceiling',
      'Professional electrical package',
      'Enhanced ventilation system',
      'Custom workbench options',
      'Premium door hardware',
      'Lifetime warranty'
    ],
    basePrice: 15999,
    minSize: '20x20',
    maxSize: '30x40',
    imageUrl: 'https://structures.b-cdn.net/workshop-garage.jpg?width=900&height=675&quality=80&format=webp',
    options: [
      {
        id: 'size-upgrade',
        name: 'Size Upgrade',
        description: 'Increase garage dimensions',
        priceModifier: 2000,
        type: 'size'
      },
      {
        id: 'hvac',
        name: 'HVAC System',
        description: 'Climate control package',
        priceModifier: 3500,
        type: 'feature'
      },
      {
        id: 'workbench',
        name: 'Custom Workbench',
        description: 'Built-in workbench with storage',
        priceModifier: 1200,
        type: 'feature'
      }
    ],
    gallery: [
      {
        url: 'https://structures.b-cdn.net/workshop-garage-1.jpg?width=900&height=675&quality=80&format=webp',
        alt: 'Workshop Garage',
        caption: 'Spacious Workshop Garage'
      }
    ]
  },
  {
    id: 'classic-workshop-garage',
    type: 'garage',
    name: 'Classic Workshop Garage',
    description: 'Premium two-car garage with dedicated workshop space, combining traditional craftsmanship with modern amenities. Perfect for automotive enthusiasts and serious DIYers.',
    features: [
      'Two-car capacity with extended workshop area',
      'Premium post-frame construction',
      'Engineered trusses with enhanced load capacity',
      'Commercial-grade garage doors with openers',
      'Full electrical package with 200-amp service',
      'Insulated walls and ceiling (R-19/R-30)',
      'Epoxy-coated concrete floor',
      'LED lighting package',
      'Heavy-duty workbench system',
      'Custom tool storage solutions',
      'Dedicated air compressor line',
      'Climate control ready'
    ],
    basePrice: 28999,
    minSize: '24x30',
    maxSize: '36x40',
    imageUrl: 'https://structures.b-cdn.net/classic-workshop-garage.jpg?width=900&height=675&quality=80&format=webp',
    options: [
      {
        id: 'hvac-system',
        name: 'Complete HVAC System',
        description: 'Full heating and cooling with programmable thermostat',
        priceModifier: 6500,
        type: 'feature'
      },
      {
        id: 'premium-doors',
        name: 'Premium Garage Door Package',
        description: 'Insulated doors with smart openers and backup power',
        priceModifier: 4200,
        type: 'feature'
      },
      {
        id: 'storage-system',
        name: 'Professional Storage System',
        description: 'Complete wall and ceiling storage solution',
        priceModifier: 3800,
        type: 'feature'
      },
      {
        id: 'air-system',
        name: 'Compressed Air System',
        description: 'Built-in air compressor with multiple outlets',
        priceModifier: 2500,
        type: 'feature'
      },
      {
        id: 'lighting-upgrade',
        name: 'Premium Lighting Package',
        description: 'Additional LED lighting with motion sensors',
        priceModifier: 1800,
        type: 'feature'
      },
      {
        id: 'security',
        name: 'Security Package',
        description: 'Smart security system with cameras and monitoring',
        priceModifier: 2200,
        type: 'feature'
      }
    ],
    gallery: [
      {
        url: 'https://structures.b-cdn.net/classic-workshop-garage-1.jpg?width=900&height=675&quality=80&format=webp',
        alt: 'Classic Workshop Garage',
        caption: 'Premium Workshop Garage Interior'
      },
      {
        url: 'https://structures.b-cdn.net/classic-workshop-garage-2.jpg?width=900&height=675&quality=80&format=webp',
        alt: 'Classic Workshop Garage Storage',
        caption: 'Custom Storage Solutions'
      },
      {
        url: 'https://structures.b-cdn.net/classic-workshop-garage-3.jpg?width=900&height=675&quality=80&format=webp',
        alt: 'Classic Workshop Garage Exterior',
        caption: 'Traditional Exterior Design'
      }
    ]
  },
  {
    id: 'modular-garage',
    type: 'garage',
    name: 'Modular Garage',
    description: 'Quick-build modular design with premium features and flexible configuration options.',
    features: [
      'Modular construction',
      'Quick installation',
      'Customizable layout',
      'Premium materials',
      'Enhanced durability',
      'Weather-resistant design',
      'Professional finish',
      'Standard warranty'
    ],
    basePrice: 14999,
    minSize: '20x20',
    maxSize: '30x40',
    imageUrl: 'https://structures.b-cdn.net/modular-garage.jpg?width=900&height=675&quality=80&format=webp',
    options: [
      {
        id: 'additional-bay',
        name: 'Additional Bay',
        description: 'Extra vehicle storage space',
        priceModifier: 5000,
        type: 'feature'
      },
      {
        id: 'premium-package',
        name: 'Premium Package',
        description: 'Enhanced features and finishes',
        priceModifier: 2500,
        type: 'feature'
      }
    ],
    gallery: [
      {
        url: 'https://structures.b-cdn.net/modular-garage-1.jpg?width=900&height=675&quality=80&format=webp',
        alt: 'Modular Garage',
        caption: 'Modern Modular Garage'
      }
    ]
  },
  {
    id: 'double-wide-classic',
    type: 'garage',
    name: 'Double Wide Classic Garage',
    description: 'Spacious two-car garage with classic styling and modern amenities.',
    features: [
      'Two-car capacity',
      'Classic design elements',
      'Premium construction',
      'Enhanced storage options',
      'Superior ventilation',
      'Professional lighting',
      'Quality hardware',
      'Standard warranty'
    ],
    basePrice: 21999,
    minSize: '24x24',
    maxSize: '30x40',
    imageUrl: 'https://structures.b-cdn.net/double-wide-classic.jpg?width=900&height=675&quality=80&format=webp',
    options: [
      {
        id: 'loft-storage',
        name: 'Loft Storage',
        description: 'Additional overhead storage space',
        priceModifier: 3000,
        type: 'feature'
      },
      {
        id: 'deluxe-doors',
        name: 'Deluxe Door Package',
        description: 'Premium doors with automation',
        priceModifier: 4000,
        type: 'feature'
      }
    ],
    gallery: [
      {
        url: 'https://structures.b-cdn.net/double-wide-classic-1.jpg?width=900&height=675&quality=80&format=webp',
        alt: 'Double Wide Classic Garage',
        caption: 'Spacious Double Wide Garage'
      }
    ]
  },
  {
    id: 'two-story-garage',
    type: 'garage',
    name: 'Two Story Garage',
    description: 'Premium two-story garage with upstairs storage or living space potential.',
    features: [
      'Two-story design',
      'Separate upper level',
      'Enhanced structural support',
      'Premium materials',
      'Professional finish',
      'Custom staircase',
      'Superior insulation',
      'Extended warranty'
    ],
    basePrice: 29999,
    minSize: '24x24',
    maxSize: '36x40',
    imageUrl: 'https://structures.b-cdn.net/two-story-garage.jpg?width=900&height=675&quality=80&format=webp',
    options: [
      {
        id: 'living-space',
        name: 'Living Space Package',
        description: 'Convert upper level to living area',
        priceModifier: 15000,
        type: 'feature'
      },
      {
        id: 'premium-windows',
        name: 'Premium Window Package',
        description: 'Enhanced natural lighting',
        priceModifier: 5000,
        type: 'feature'
      }
    ],
    gallery: [
      {
        url: 'https://structures.b-cdn.net/two-story-garage-1.jpg?width=900&height=675&quality=80&format=webp',
        alt: 'Two Story Garage',
        caption: 'Elegant Two Story Garage'
      }
    ]
  }
];

export const otherStructures: Structure[] = [
  {
    id: 'greenhouse',
    type: 'other',
    name: 'Greenhouse',
    description: 'Custom greenhouse with optimal growing conditions and premium features. Perfect for year-round gardening and plant cultivation.',
    features: [
      'UV-resistant panels',
      'Automated ventilation',
      'Temperature control',
      'Custom shelving systems',
      'Professional irrigation',
      'Enhanced durability',
      'Weather monitoring',
      'Climate control options'
    ],
    basePrice: 8999,
    minSize: '8x12',
    maxSize: '16x40',
    imageUrl: 'https://structures.b-cdn.net/greenhouse.jpg?width=900&height=675&quality=80&format=webp',
    options: [
      {
        id: 'climate-control',
        name: 'Climate Control System',
        description: 'Advanced temperature and humidity management',
        priceModifier: 2500,
        type: 'feature'
      },
      {
        id: 'irrigation',
        name: 'Irrigation System',
        description: 'Automated watering and nutrient delivery',
        priceModifier: 1500,
        type: 'feature'
      },
      {
        id: 'shelving',
        name: 'Premium Shelving',
        description: 'Custom shelving and workbench system',
        priceModifier: 1200,
        type: 'feature'
      }
    ],
    gallery: [
      {
        url: 'https://structures.b-cdn.net/greenhouse-1.jpg?width=900&height=675&quality=80&format=webp',
        alt: 'Custom Greenhouse',
        caption: 'Professional Greenhouse with Climate Control'
      },
      {
        url: 'https://structures.b-cdn.net/greenhouse-2.jpg?width=900&height=675&quality=80&format=webp',
        alt: 'Greenhouse Interior',
        caption: 'Interior View with Custom Shelving'
      }
    ]
  },
  {
    id: 'hunting-blind',
    type: 'other',
    name: 'Hunting Blind',
    description: 'Professional-grade hunting blind with premium features for serious hunters. Designed for comfort and stealth during long hunting sessions.',
    features: [
      'Elevated design',
      'Camouflage finish',
      'Multiple windows',
      'Insulated walls',
      'Silent hinges',
      'Weather resistant',
      'Custom shelving',
      'Non-reflective interior'
    ],
    basePrice: 4999,
    minSize: '4x6',
    maxSize: '8x8',
    imageUrl: 'https://structures.b-cdn.net/hunting-blind.jpg?width=900&height=675&quality=80&format=webp',
    options: [
      {
        id: 'premium-windows',
        name: 'Premium Window Package',
        description: 'Additional viewing angles with silent operation',
        priceModifier: 800,
        type: 'feature'
      },
      {
        id: 'solar-package',
        name: 'Solar Power Package',
        description: 'Basic power system for lighting and devices',
        priceModifier: 1200,
        type: 'feature'
      },
      {
        id: 'comfort-package',
        name: 'Comfort Package',
        description: 'Enhanced seating and storage solutions',
        priceModifier: 600,
        type: 'feature'
      }
    ],
    gallery: [
      {
        url: 'https://structures.b-cdn.net/hunting-blind-1.jpg?width=900&height=675&quality=80&format=webp',
        alt: 'Professional Hunting Blind',
        caption: 'Elevated Hunting Blind with Camouflage Finish'
      }
    ]
  },
  {
    id: 'run-in-shed',
    type: 'other',
    name: 'Run-In Shed',
    description: 'Durable run-in shed providing shelter for horses and livestock. Built with premium materials for long-lasting protection.',
    features: [
      'Open design',
      'Weather protection',
      'Reinforced structure',
      'Premium materials',
      'Kick-proof walls',
      'Enhanced durability',
      'Professional finish',
      'Proper ventilation'
    ],
    basePrice: 6999,
    minSize: '10x12',
    maxSize: '12x36',
    imageUrl: 'https://structures.b-cdn.net/run-in-shed.jpg?width=900&height=675&quality=80&format=webp',
    options: [
      {
        id: 'feed-room',
        name: 'Feed Room Addition',
        description: 'Enclosed storage area for feed and supplies',
        priceModifier: 1500,
        type: 'feature'
      },
      {
        id: 'premium-flooring',
        name: 'Premium Flooring System',
        description: 'Enhanced durability and drainage',
        priceModifier: 1000,
        type: 'feature'
      },
      {
        id: 'extended-roof',
        name: 'Extended Roof Overhang',
        description: 'Additional weather protection',
        priceModifier: 800,
        type: 'feature'
      }
    ],
    gallery: [
      {
        url: 'https://structures.b-cdn.net/run-in-shed-1.jpg?width=900&height=675&quality=80&format=webp',
        alt: 'Run-In Shed',
        caption: 'Professional Run-In Shed for Horses'
      }
    ]
  }
];

export const allStructures: Structure[] = [
  ...shedStructures,
  ...garageStructures,
  ...otherStructures
];

export const getStructureById = (id: string): Structure | undefined => {
  return allStructures.find(structure => structure.id === id);
};