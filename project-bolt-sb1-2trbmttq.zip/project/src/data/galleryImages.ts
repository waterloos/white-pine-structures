import { GalleryImage } from '../types';

// Base URL for images (would typically come from environment variables)
const CLOUDINARY_BASE_URL = 'https://images.pexels.com/photos';

export const galleryImages: GalleryImage[] = [
  {
    id: 'gallery-001',
    url: `${CLOUDINARY_BASE_URL}/259588/pexels-photo-259588.jpeg`,
    alt: 'Classic Red Mini Barn',
    title: 'Classic Red Mini Barn',
    description: 'Traditional styling with modern functionality',
    category: 'shed',
    tags: ['mini-barn', 'red', 'traditional'],
    featured: true,
    metadata: {
      width: 1920,
      height: 1080,
      size: 'large',
      taken: '2024-01-15'
    }
  },
  // Add more images following the same pattern
];

// Helper functions for gallery management
export const getGalleryImagesByCategory = (category: string): GalleryImage[] => {
  return galleryImages.filter(image => image.category === category);
};

export const getGalleryImagesByTag = (tag: string): GalleryImage[] => {
  return galleryImages.filter(image => image.tags.includes(tag));
};

export const getFeaturedGalleryImages = (): GalleryImage[] => {
  return galleryImages.filter(image => image.featured);
};

export const getGalleryImageById = (id: string): GalleryImage | undefined => {
  return galleryImages.find(image => image.id === id);
};