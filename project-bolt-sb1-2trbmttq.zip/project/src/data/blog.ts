import { BlogPost } from '../types';

export const blogPosts: BlogPost[] = [
  {
    id: '1',
    title: 'How to Choose the Perfect Shed Size for Your Needs',
    excerpt: 'A comprehensive guide to determining the right shed size based on your storage needs, property size, and intended use.',
    content: 'Full article content here...',
    author: 'John White',
    date: '2024-03-15',
    readTime: 5,
    category: 'Planning',
    tags: ['sheds', 'planning', 'sizing'],
    imageUrl: 'https://images.pexels.com/photos/259588/pexels-photo-259588.jpeg',
    slug: 'choosing-perfect-shed-size'
  },
  {
    id: '2',
    title: 'Essential Spring Maintenance Tips for Your Outdoor Structure',
    excerpt: 'Keep your shed or garage in top condition with these important spring maintenance tasks and tips.',
    content: 'Full article content here...',
    author: 'Sarah Johnson',
    date: '2024-03-10',
    readTime: 4,
    category: 'Maintenance',
    tags: ['maintenance', 'seasonal', 'tips'],
    imageUrl: 'https://images.pexels.com/photos/273843/pexels-photo-273843.jpeg',
    slug: 'spring-maintenance-tips'
  },
  {
    id: '3',
    title: 'Converting Your Shed into a Home Office',
    excerpt: 'Step-by-step guide to transforming your backyard shed into a productive and comfortable home office space.',
    content: 'Full article content here...',
    author: 'Mike Thompson',
    date: '2024-03-05',
    readTime: 6,
    category: 'DIY',
    tags: ['conversion', 'home-office', 'diy'],
    imageUrl: 'https://images.pexels.com/photos/1094767/pexels-photo-1094767.jpeg',
    slug: 'shed-to-home-office'
  }
];

export const getBlogPostBySlug = (slug: string): BlogPost | undefined => {
  return blogPosts.find(post => post.slug === slug);
};

export const getBlogPostsByCategory = (category: string): BlogPost[] => {
  return category === 'all' 
    ? blogPosts 
    : blogPosts.filter(post => post.category.toLowerCase() === category.toLowerCase());
};

export const getBlogPostsByTag = (tag: string): BlogPost[] => {
  return blogPosts.filter(post => post.tags.includes(tag));
};

export const searchBlogPosts = (searchTerm: string): BlogPost[] => {
  const term = searchTerm.toLowerCase();
  return blogPosts.filter(post => 
    post.title.toLowerCase().includes(term) ||
    post.excerpt.toLowerCase().includes(term) ||
    post.tags.some(tag => tag.toLowerCase().includes(term))
  );
};