export interface ColorOption {
  id: string;
  name: string;
  hex: string;
  category: 'paint' | 'vinyl' | 'trim' | 'shingle' | 'stain' | 'metal';
  available: boolean;
  description?: string;
  popular?: boolean;
}

export interface ColorCategory {
  id: string;
  name: string;
  description: string;
  options: ColorOption[];
}