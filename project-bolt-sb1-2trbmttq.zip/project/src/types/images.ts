export interface ImageLoaderOptions {
  width?: number;
  height?: number;
  quality?: number;
  format?: 'webp' | 'jpeg' | 'png';
  blur?: number;
  dpr?: number;
}

export interface ResponsiveImage {
  src: string;
  srcSet: string;
  sizes: string;
  placeholder: string;
}