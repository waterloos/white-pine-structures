export interface GalleryImage {
  id: string;
  url: string;
  alt: string;
  title: string;
  description: string;
  category: 'shed' | 'garage' | 'other';
  tags: string[];
  featured: boolean;
  metadata: {
    width: number;
    height: number;
    size: 'small' | 'medium' | 'large';
    taken: string;
  };
}

export interface GalleryFilter {
  category?: string;
  tag?: string;
  searchTerm?: string;
  sortBy?: 'newest' | 'oldest' | 'title';
}