// Structure types
export interface Structure {
  id: string;
  type: 'shed' | 'garage' | 'other';
  name: string;
  description: string;
  features: string[];
  basePrice: number;
  minSize: string;
  maxSize: string;
  imageUrl: string;
  options: StructureOption[];
  gallery: {
    url: string;
    alt: string;
    caption?: string;
  }[];
  availableSizes?: string[];
}

export interface StructureOption {
  id: string;
  name: string;
  description: string;
  priceModifier: number | ((basePrice: number) => number);
  type: 'size' | 'feature' | 'material' | 'color';
}

export interface ProposalItem {
  structureId: string;
  options: { [key: string]: string | boolean | number };
  basePrice: number;
  totalPrice: number;
}

export interface Gallery {
  id: string;
  imageUrl: string;
  title: string;
  description: string;
  structureType: string;
  structureName: string;
}

export interface Testimonial {
  id: string;
  customer: string;
  text: string;
  rating: number;
  date: string;
  structureType?: string;
}

export interface StockStructure {
  id: string;
  type: string;
  name: string;
  description: string;
  features: string[];
  basePrice: number;
  minSize: string;
  maxSize: string;
  imageUrl: string;
  options: any[];
  size: string;
  color: string;
  materials: string[];
  additionalFeatures: string[];
  price: number;
  available: boolean;
  location: string;
}